# runes' domain V2: an NR-CORE Projeect.
Realm of the Mad God AS3 client based on version 27.7.X13. 

## Client Features
- [x] Increased Server Stability;
- [x] Remove Excess Code;
- [ ] Finish Runes;
- [ ] Finish Hunts;

## Requirements
- IntelliJ IDEA or similar Flash IDE;
- Flex SDK 4.9.1, or Air SDK 32 Compiler.

## Special Thanks
- Keathiz
- Titan
- Kristis
- Yeti
- RD Support Team [Omanoit, xWass, Paracosm, Hip, Cynica, Stella, Cali]