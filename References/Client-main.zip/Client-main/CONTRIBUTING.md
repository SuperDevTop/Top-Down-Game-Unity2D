# Important tutorials for new developers
- [:link:](https://gitlab.com/MayhemLab/EMR-SERVER/wikis/how-to-manage-projects-with-git) **How to manage projects with git?**
- [:link:](https://gitlab.com/MayhemLab/EMR-SERVER/wikis/useful-git-commands) **Useful git commands**