﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wServer
{
    static class Empty<T>
    {
        public static T[] Array = new T[0];
    }
}
