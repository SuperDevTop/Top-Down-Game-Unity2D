﻿using common;

namespace wServer.networking.packets.incoming
{
    public class Fragments : IncomingMessage
    {
        public int Type { get; set; }
        public override PacketId ID => PacketId.FRAGMENTS;
        public override Packet CreateInstance() { return new Fragments(); }

        protected override void Read(NReader rdr)
        {
            Type = rdr.ReadInt32();
        }

        protected override void Write(NWriter wtr)
        {
            wtr.Write(Type);
        }
    }
}