﻿using common;
using System;

namespace wServer.networking.packets.incoming
{
    public class Guild : IncomingMessage
    {
        public string UpgradeType { get; set; }

        public override PacketId ID => PacketId.GUILD;

        public override Packet CreateInstance() { return new Guild(); }

        protected override void Read(NReader rdr)
        {
            UpgradeType = rdr.ReadUTF();
        }

        protected override void Write(NWriter wtr)
        {
            wtr.WriteUTF(UpgradeType);
        }
    }
}
