﻿using common;

namespace wServer.networking.packets.incoming
{
    public class Escape : IncomingMessage
    {
        public override PacketId ID => PacketId.ESCAPE;
        public override Packet CreateInstance() { return new Escape(); }

        public bool ToRealm { get; set; }

        protected override void Read(NReader rdr) {
            ToRealm = rdr.ReadBoolean();
        }

        protected override void Write(NWriter wtr) { }
    }
}
