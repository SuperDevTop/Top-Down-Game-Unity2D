﻿using common;
using System;

namespace wServer.networking.packets.incoming
{
    public class Forge : IncomingMessage
    {
        public ForgeItem[] Inventory { get; set; }

        public override PacketId ID => PacketId.FORGE;

        public override Packet CreateInstance() { return new Forge(); }

        protected override void Read(NReader rdr)
        {
            Inventory = new ForgeItem[rdr.ReadInt16()];
            for (int a = 0; a < Inventory.Length; a++)
            {
                Inventory[a].ObjectType = rdr.ReadUInt16();
                Inventory[a].SlotID = rdr.ReadInt32();
                Inventory[a].Chosen = rdr.ReadBoolean();
            }
        }

        protected override void Write(NWriter wtr)
        {
            wtr.Write((short)Inventory.Length);
            foreach (var i in Inventory)
            {
                wtr.Write(i.ObjectType);
                wtr.Write(i.SlotID);
                wtr.Write(i.Chosen);
            }
        }
    }
}
