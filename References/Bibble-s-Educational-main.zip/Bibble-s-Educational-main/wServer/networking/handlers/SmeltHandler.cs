﻿using common.resources;
using System.Collections.Generic;
using System.Linq;

using wServer.networking.packets;
using wServer.networking.packets.incoming;

namespace wServer.networking.handlers
{
    class SmeltHandler : PacketHandlerBase<Smelt>
    {
        public override PacketId ID => PacketId.SMELT;


        protected override void HandlePacket(Client client, Smelt packet)
        {
            Handle(client, packet);
        }

        private int GetItemValue(Item item)
        {
            if (item.Ancient)
                return 25000;
            if (item.Legendary)
                return 2500;
            return 250;
        }

        private void Handle(Client client, Smelt packet)
        {
            var selected = new ForgeItem[packet.Inventory.Length];
            if (selected.Length < 1)
            {
                client.Player.SendError("Select atleast one item to smelt.");
                return;
            }

            if (client.Player.Owner == null) return;

            if (!client.Player.Owner.StaticObjects.TryGetValue(packet.InteractedObjId, out var smelter))
            {
                client.Player.SendError("An error occurred, please try again.");
                return;
            }

            var plrInv = client.Player.Inventory;
            var pktInv = packet.Inventory;
            int i;
            for (i = 0; i < pktInv.Length; i++)
            {
                if (plrInv[pktInv[i].SlotID] == null ||
                    pktInv[i].ObjectType != plrInv[pktInv[i].SlotID].ObjectType)
                {
                    client.Player.SendError("An error occurred, please try again.");
                    return;
                }
            }

            var gameData = Program.Resources.GameData;
            var items = new List<KeyValuePair<int, Item>>();
            for (i = 0; i < pktInv.Length; i++)
            {
                selected[i].ObjectType = pktInv[i].ObjectType;
                selected[i].SlotID = pktInv[i].SlotID;
                selected[i].Chosen = pktInv[i].Chosen;
                if (selected[i].Chosen)
                    items.Add(new KeyValuePair<int, Item>(selected[i].SlotID, gameData.Items[selected[i].ObjectType]));
            }

            items = items.Where(x => x.Value.Rare || x.Value.Legendary || x.Value.Ancient).Select(x => x).ToList();
            if (items.Count == 0)
            {
                client.Player.SendError("You must select at least one Rare, Legendary or Immortal item.");
                return;
            }

            var fame = 0;
            for (i = 0; i < items.Count; i++)
            {
                plrInv[items[i].Key] = null;
                fame += GetItemValue(items[i].Value);
            }
            
            client.Player.SendInfo($"Successfully smelted {items.Count} item{(items.Count != 1 ? "s" : "")} into {fame} Fame!");
            client.Player.Manager.Database.UpdateCurrency(client.Account, fame, CurrencyType.Fame)
                .ContinueWith(t => client.Player.CurrentFame = client.Account.Fame);
            if (smelter.InteractionAllowed)
                smelter.InteractionOccurred = true;
        }
    }
}
