﻿using common.resources;
using System.Collections.Generic;
using System;
using wServer.realm.entities;
using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.networking.packets.outgoing;
using wServer.realm;
using log4net;
using System.Collections.Concurrent;

namespace wServer.networking.handlers
{
    class PlayerShootHandler : PacketHandlerBase<PlayerShoot>
    {

        public struct IdsForSync
        {
            public int PlayerId;
            public byte ProjId;

            public override int GetHashCode()
            {
                return new Tuple<int, byte>(PlayerId, ProjId).GetHashCode();
            }
        }

        public override PacketId ID => PacketId.PLAYERSHOOT;
        private static readonly ILog CheatLog = LogManager.GetLogger("CheatLog");
        public static ConcurrentDictionary<IdsForSync, Action<Projectile, RealmTime>> SyncCallbacks = new ConcurrentDictionary<IdsForSync, Action<Projectile, RealmTime>>();
        
        protected override void HandlePacket(Client client, PlayerShoot packet)
        {
            client.Manager.Logic.AddPendingAction(t => Handle(client.Player, packet, t));
            //Handle(client.Player, packet, DummyTime);
        }

        void Handle(Player player, PlayerShoot packet, RealmTime time)
        {
            if (player?.Owner == null) return;

            Item item;

            if (!player.Manager.Resources.GameData.Items.TryGetValue(packet.ContainerType, out item))
                return;

            // if not shooting main weapon do nothing (ability shoot is handled with useItem)
            if (player.Inventory[0] != item)
                return;

            // validate shoot time
            var prjDesc = item.Projectiles[0]; //Assume only one
            if (!player.ValidatePlayerShoot(packet, item, time, packet.AngleVariation, prjDesc))
            {
                // actually dropping this doesn't matter because you'll dc anyway...
                // var drop = prjDesc.AngleVaries ? 2 : 1;
                // player.Client.Random.Drop(drop);
                return;
            }

            // cache where the player shot the shot (not the actual shot location, the actual player location)
            // predictedX/Y is already centered here.
            player.ShotLocation[packet.BulletId] = new KAUtil
            {
                X = player.RealX,
                Y = player.RealY,
                predictedX = Math.Cos(packet.Angle),
                predictedY = Math.Sin(packet.Angle),
                item = item
            };

            // create projectile and show other players
            Projectile prj = player.PlayerShootProjectile(
                packet.BulletId, prjDesc, item.ObjectType,
                packet.Time, packet.StartingPos, packet.Angle);
            player.Owner.EnterWorld(prj);

            IdsForSync sync = new IdsForSync()
            {
                PlayerId = player.Id,
                ProjId = prj.ProjectileId
            };

            if(SyncCallbacks.ContainsKey(sync))
            {
                SyncCallbacks[sync](prj, time);
                Action<Projectile, RealmTime> outVar;
                SyncCallbacks.TryRemove(sync, out outVar);
            }

            if (!player.Manager.Resources.Settings.DisableAlly)
                player.Owner.BroadcastPacketNearby(new AllyShoot()
                {
                    OwnerId = player.Id,
                    Angle = packet.Angle,
                    ContainerType = packet.ContainerType,
                    BulletId = packet.BulletId
                }, player, player);
            player.FameCounter.Shoot(prj);
        }
    }
}