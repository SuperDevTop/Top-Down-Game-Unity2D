﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using common.resources;
using wServer.realm;
using wServer.realm.entities;
using wServer.networking.packets;
using wServer.networking.packets.incoming;

namespace wServer.networking.handlers
{
    class EnemyHitHandler : PacketHandlerBase<EnemyHit>
    {

        public Random random = new Random();
        public override PacketId ID => PacketId.ENEMYHIT;

        private static readonly RealmTime DummyTime = new RealmTime();

        protected override void HandlePacket(Client client, EnemyHit packet)
        {
            Handle(client.Player, DummyTime, packet); 
        }

        void Handle(Player player, RealmTime time, EnemyHit pkt)
        {
            var entity = player?.Owner?.GetEntity(pkt.TargetId);
            double rand = random.NextDouble();

            if (entity?.Owner == null)
                return;
            if (player.HasConditionEffect(ConditionEffects.Hidden))
                return;

            switch (player.AttackRune)
            {
                case 1:
                    if (random.NextDouble() <= 0.008) player.LightningStrike(time);
                    break;
                case 3:
                    if (random.NextDouble() <= 0.016) player.RoguesCloak(time);
                    break;
            }

            player.HandleSteal(player.SupportRune);

            var prj = (player as IProjectileOwner).Projectiles[pkt.BulletId];

            // if not null, it's fine to check for KA b/c will be spawned after first tick
            if (prj != null)
            {
                /* for now, ignore useitem bullets in KA check */
                if (!prj.fromUseItem)
                {
                     // find the location the player shot at (this uses location from Move) 
                     // validate move or ppl can cheat 
                    if (player.ShotLocation.ContainsKey(pkt.BulletId))
                    {
                        if (!player.ValidateEnemyHit(player.ShotLocation[pkt.BulletId], entity, pkt))
                        {
                            Log.InfoFormat("ignoring an enemy hit with id {0}", pkt.BulletId);
                                return;
                        }
                            
                    }
                    else
                    {
                        Log.InfoFormat("Player {0} did not shoot a shot corresponding to this bullet ID. Ignoring this shot.", player.Name);
                        return;
                    }
                }
                
                prj?.ForceHit(entity, time);
            }

            /* else, do the hitreg patch. */
            else {

                var key = new PlayerShootHandler.IdsForSync() { PlayerId = player.Id, ProjId = pkt.BulletId };


                if (PlayerShootHandler.SyncCallbacks.Count > 200)
                    PlayerShootHandler.SyncCallbacks.Clear();

                Action<Projectile, RealmTime> cb = (projectile, newtime) =>
                {
                    projectile.ForceHit(entity, newtime);
                };

                if (PlayerShootHandler.SyncCallbacks.ContainsKey(key))
                    PlayerShootHandler.SyncCallbacks[key] = cb;
                else
                    PlayerShootHandler.SyncCallbacks.TryAdd(key, cb);
            }

            if (entity is Enemy e && e.HP < 0)
                player.ClientKilledEntity.Enqueue(entity);
        }
    }
}
