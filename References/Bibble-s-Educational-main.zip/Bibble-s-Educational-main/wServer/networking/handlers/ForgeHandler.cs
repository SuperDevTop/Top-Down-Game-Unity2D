﻿using common;
using common.resources;

using System;
using System.Collections.Generic;
using System.Linq;

using wServer.networking.packets;
using wServer.networking.packets.incoming;

namespace wServer.networking.handlers
{
    class ForgeHandler : PacketHandlerBase<Forge>
    {
        public override PacketId ID => PacketId.FORGE;

        public struct FHashWrap
        {
            public ushort value;
            public ushort count;

            public override int GetHashCode()
            {
                return Tuple.Create(value, count).GetHashCode();
            }
        }

        private static IDictionary<HashSet<FHashWrap>, ushort> _recipes;

        private static IDictionary<HashSet<FHashWrap>, ushort> recipes { 
            get {
                if(_recipes == null)
                {
                    _recipes = new Dictionary<HashSet<FHashWrap>, ushort>(HashSet<FHashWrap>.CreateSetComparer());
                    _recipes.Add(CreateRecipe(0x5333, 0xba2, 0xba1, 0xba0, 0x541c));
                    _recipes.Add(CreateRecipe(0x5383, 0x5381, 0x5381, 0x541c));
                    _recipes.Add(CreateRecipe(0x5381, 0x537e, 0x537e));
                    _recipes.Add(CreateRecipe(0x537e, 0x537c, 0x537c));
                    _recipes.Add(CreateRecipe(0x537c, 0x537a, 0x537a));
                    _recipes.Add(CreateRecipe(0x537a, 0x5378, 0x5378));
                    _recipes.Add(CreateRecipe(0x5378, 0x5376, 0x5376));
                    _recipes.Add(CreateRecipe(0x5376, 0xc45, 0xc45));
                    _recipes.Add(CreateRecipe(0x5369, 0xc04, 0x503d, 0x541c));
                    _recipes.Add(CreateRecipe(0x535a, 0xc30, 0x503e, 0x541c));
                    _recipes.Add(CreateRecipe(0x5359, 0x529c, 0x5223, 0x541c));
                    _recipes.Add(CreateRecipe(0x5358, 0xc0b, 0x5296, 0x541c));
                    _recipes.Add(CreateRecipe(0x5351, 0x0250, 0x501a, 0x541c));
                    _recipes.Add(CreateRecipe(0x534f, 0xc6d, 0x510e, 0x541c));
                    _recipes.Add(CreateRecipe(0x534e, 0x5233, 0x0257, 0x541c));
                    _recipes.Add(CreateRecipe(0x534c, 0xc07, 0x024d, 0x541c));
                    _recipes.Add(CreateRecipe(0x534a, 0xb41, 0x528a, 0x541c));
                    _recipes.Add(CreateRecipe(0x5349, 0x5276, 0x529e, 0x541c));
                    _recipes.Add(CreateRecipe(0x5348, 0x517b, 0x5307, 0x541c));
                    _recipes.Add(CreateRecipe(0x5332, 0xbac, 0x024f, 0x541c));
                    _recipes.Add(CreateRecipe(0x5331, 0xbad, 0x0253, 0x541c));
                    _recipes.Add(CreateRecipe(0x532f, 0x5293, 0x024e, 0x541c));
                    _recipes.Add(CreateRecipe(0x532e, 0x5297, 0x0252, 0x541c));
                    _recipes.Add(CreateRecipe(0x532d, 0x0255, 0x5287, 0x541c));
                    _recipes.Add(CreateRecipe(0x532b, 0x514b, 0x5221, 0x541c));
                    _recipes.Add(CreateRecipe(0x5329, 0x5281, 0x0254, 0x541c));
                    _recipes.Add(CreateRecipe(0x5327, 0x5303, 0xc0f, 0x541c));
                    _recipes.Add(CreateRecipe(0x5326, 0x0251, 0xbab, 0x541c));
                    _recipes.Add(CreateRecipe(0x5324, 0x5251, 0x5284, 0x541c));
                    _recipes.Add(CreateRecipe(0x5322, 0x5294, 0x5288, 0x541c));
                    _recipes.Add(CreateRecipe(0x531f, 0x507f, 0x5256, 0x541c));
                    _recipes.Add(CreateRecipe(0x531d, 0xcdc, 0x5231, 0x541c));
                    _recipes.Add(CreateRecipe(0x541d, 0x5419, 0x5291, 0x541c));
                    _recipes.Add(CreateRecipe(0x555b, 0x531c, 0x5278, 0x541c));
                    _recipes.Add(CreateRecipe(0x5571, 0x5413, 0x555c, 0x541c));
                    _recipes.Add(CreateRecipe(0x5403, 0x541f, 0x5421));
                    _recipes.Add(CreateRecipe(0x5401, 0x5422, 0x5423));
                    _recipes.Add(CreateRecipe(0x236F, 0xaea, 0xaea));
                    _recipes.Add(CreateRecipe(0x236E, 0xae9, 0xae9));
                    _recipes.Add(CreateRecipe(0x236D, 0xa4c, 0xa4c));
                    _recipes.Add(CreateRecipe(0x236C, 0xa35, 0xa35));
                    _recipes.Add(CreateRecipe(0x236B, 0xa34, 0xa34));
                    _recipes.Add(CreateRecipe(0x236A, 0xa21, 0xa21));
                    _recipes.Add(CreateRecipe(0x2369, 0xa20, 0xa20));
                    _recipes.Add(CreateRecipe(0x2368, 0xa1f, 0xa1f));
                    _recipes.Add(CreateRecipe(0x526f, 0x701, 0x524f));
                    _recipes.Add(CreateRecipe(0x5267, 0x70b, 0x524f));
                    _recipes.Add(CreateRecipe(0x541b, 0x5242, 0x524f));
                }
                return _recipes;
            }
        }

        protected override void HandlePacket(Client client, Forge packet)
        {
            Handle(client, packet);
        }

        private static HashSet<FHashWrap> CreateHashWrapSet(params ushort[] inputs)
        {
            Dictionary<ushort, ushort> w = new Dictionary<ushort, ushort>();
            foreach(ushort a in inputs)
            {
                if(w.ContainsKey(a))
                {
                    ushort c = w[a];
                    c++;
                    w[a] = c;
                } else
                {
                    w[a] = 1;
                }
            }
            return new HashSet<FHashWrap>(w.AsEnumerable().Select( pair => new FHashWrap() { value=pair.Key, count=pair.Value } ).ToList());
        }

        private static KeyValuePair<HashSet<FHashWrap>, ushort> CreateRecipe(ushort output, params ushort[] inputs)
        {
            return new KeyValuePair<HashSet<FHashWrap>, ushort>(CreateHashWrapSet(inputs), output);
        }

        private void Handle(Client client, Forge packet)
        {
            var gameData = Program.Resources.GameData;
            var selected = new ForgeItem[packet.Inventory.Length];
            var list = new List<Item>();

            var plrInv = client.Player.Inventory;
            var pktInv = packet.Inventory;

            if (selected.Length < 2) 
            { 
                client.Player.SendError("Select atleast two items to forge from."); 
                return; 
            }

            for (var i = 0; i < pktInv.Length; i++)
            {
                if (plrInv[pktInv[i].SlotID] == null ||
                    pktInv[i].ObjectType != plrInv[pktInv[i].SlotID].ObjectType)
                {
                    client.Player.SendError("An error occurred, please try again.");
                    return;
                }
            }

            for (var i = 0; i < pktInv.Length; i++)
            {
                selected[i].ObjectType = pktInv[i].ObjectType;
                selected[i].SlotID = pktInv[i].SlotID;
                selected[i].Chosen = pktInv[i].Chosen;
                list.Add(gameData.Items[pktInv[i].ObjectType]);
            }

            var objTypes = CreateHashWrapSet(pktInv.AsEnumerable().Select(a => a.ObjectType).ToArray());
            ushort output = 0;
            recipes.TryGetValue(objTypes, out output);

            if(output != 0)
            {
                for (var i = 0; i < selected.Length; i++)
                {
                    plrInv[selected[i].SlotID] = null;
                }
                plrInv[selected[0].SlotID] = gameData.Items[output];

                client.Player.SaveToCharacter();
                client.Character.FlushAsync();
            } else
            {
                client.Player.SendError("Recipe not found.");
            }
        }
    }
}
