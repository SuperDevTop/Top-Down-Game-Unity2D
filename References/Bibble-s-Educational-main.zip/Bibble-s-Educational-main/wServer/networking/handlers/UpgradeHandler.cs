﻿using wServer.realm.entities;
using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.realm.entities.vendors;

namespace wServer.networking.handlers
{
    class UpgradeHandler : PacketHandlerBase<Upgrade>
    {
        public override PacketId ID => PacketId.UPGRADE;

        protected override void HandlePacket(Client client, Upgrade packet)
        {
            Handle(client.Player, packet.Type);
        }

        void Handle(Player player, string type)
        {
           switch (type)
           {
                case "potions":
                    HandlePotions(player);
                    break;
                default:
                    break;
           }
        }

        void HandlePotions(Player plr)
        {
            var acc = plr.Client.Account;
            int price;

            if (acc.PotionStorageLevel >= 3)
            {
                plr.SendError("Your potion storage is already maxed!");
                return;
            }

            price = 10000;
            if (acc.PotionStorageLevel == 1)
                price = 25000;

            if (acc.Fame < price)
            {
                plr.SendError("You can't afford this upgrade!");
                return;
            }
            else
            {
                acc.Fame -= price;
                acc.PotionStorageLevel++;
                acc.FlushAsync();
                plr.SendInfo("Upgrade completed, please reload to view changes.");
                return;
            }
        }
    }
}
