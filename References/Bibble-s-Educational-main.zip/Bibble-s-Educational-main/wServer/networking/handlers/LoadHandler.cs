﻿using System;
using common.resources;
using log4net;
using wServer.realm.entities;
using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.worlds.logic;
using StackExchange.Redis;

namespace wServer.networking.handlers
{
    class LoadHandler : PacketHandlerBase<Load>
    {
        public override PacketId ID => PacketId.LOAD;

        public static string StoredMD5;
        public static bool TokenNeedsUpdate = true;
        protected new static readonly ILog Log = LogManager.GetLogger(typeof(LoadHandler));
        protected override void HandlePacket(Client client, Load packet)
        {
            Handle(client, packet);
        }
        private void Handle(Client client, Load packet)
        {
            if (client.State != ProtocolState.Handshaked)
                return;

            if (TokenNeedsUpdate)
            {
                // getting this from db all the time might get slow,
                // so let's keep the stored token until it needs to be changed
                StoredMD5 = client.Manager.Database.GetStoredMD5();
                TokenNeedsUpdate = false;
            }
            
            if (StoredMD5 == null || packet.MD5 != StoredMD5)
            {
                Log.InfoFormat($"hash#: {packet.MD5} [{client.Account.Name}, {client.Account.AccountId}]");
                if (client.Account.Rank < 50)
                {
                    return;
                }
                
                if (StoredMD5 != packet.MD5 && client.Account.UpdateToken)
                {
                    client.Manager.Database.StoreMD5(packet.MD5);
                    TokenNeedsUpdate = true;
                }
            }

            client.Character = client.Manager.Database.LoadCharacter(client.Account, packet.CharId);
            if (client.Character == null)
            {
                client.SendFailure("Failed to load character.", Failure.MessageWithDisconnect);
                return;
            }

            if (client.Character.Dead)
                client.SendFailure("Character is dead.", Failure.MessageWithDisconnect); 
            else
            {
                bool saveInventory = !(client.Manager.Worlds[client.TargetWorld] is Test);

                client.Player = new Player(client, saveInventory);
                if (client.Account.MarketToken > 0)
                {
                    var trans = client.Player.Manager.Database.Conn.CreateTransaction();
                    client.Player.Manager.Database.UpdateCurrency(client.Account, client.Account.MarketToken, CurrencyType.Fame, trans)
                        .ContinueWith(t =>
                        {
                            client.Player.CurrentFame = client.Account.Fame;
                        });
                    trans.Execute(CommandFlags.FireAndForget);
                    client.Account.MarketToken = 0;
                }

                client.SendPacket(new CreateSuccess()
                {
                    CharId = client.Character.CharId,
                    ObjectId = client.Manager.Worlds[client.TargetWorld].EnterWorld(client.Player)
                }, PacketPriority.High);

                client.State = ProtocolState.Ready;
                client.Manager.ConMan.ClientConnected(client);
            }
        }
    }
}
