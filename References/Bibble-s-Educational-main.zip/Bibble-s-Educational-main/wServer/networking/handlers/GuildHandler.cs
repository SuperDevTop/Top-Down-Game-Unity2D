using common;
using common.resources;

using System;
using System.Collections.Generic;
using System.Linq;

using wServer.networking.packets;
using wServer.networking.packets.incoming;

namespace wServer.networking.handlers
{
    class GuildHandler : PacketHandlerBase<Guild>
    {
        public override PacketId ID => PacketId.GUILD;

        protected override void HandlePacket(Client client, Guild packet)
        {
            Handle(client, packet);
        }

        private void Handle(Client client, Guild packet)
        {
            var db = client.Player.Manager.Database;
            var chat = client.Player.Manager.Chat;
            var guild = db.GetGuild(client.Account.GuildId);
            var acc = db.GetAccount(client.Account.AccountId);

            int baseLootPrice =  7500;
            int baseMembersPrice = 15000;

            if (client.Account.GuildRank < 30)
            {
                client.Player.SendError("Your guild rank is too low to upgrade anything!");
                return;
            }        

            switch (packet.UpgradeType)
            {
                case "loot":
                    if (guild.LootBoost != 0)
                        baseLootPrice = baseLootPrice * (guild.LootBoost / 2);
                    if (guild.LootBoost >= 50)
                        return;
                    if (guild.Fame >= baseLootPrice)
                    {
                        db.UpdateGuildFame(guild, -baseLootPrice);
                        db.UpdateGuildUpgrades(guild, "loot", 1);
                        client.Account.FlushAsync();
                        chat.GuildAnnounce(client.Account, $"Your loot boost has been upgraded by 1%. [{guild.LootBoost + 1}/50]");
                    }
                    else
                    {
                        return;
                    }
                    break;
                case "members":
                    if (guild.MembersBoost != 0)
                        baseMembersPrice = baseMembersPrice * (guild.MembersBoost / 2);
                    if (guild.MembersBoost >= 25)
                        return;
                    if (guild.Fame >= baseMembersPrice)
                    {
                        db.UpdateGuildFame(guild, -baseMembersPrice);
                        db.UpdateGuildUpgrades(guild, "members", 1);
                        client.Account.FlushAsync();
                        chat.GuildAnnounce(client.Account, $"Your max members count has increased by 1. [{guild.MembersBoost + 1}/25]");
                    }
                    else
                    {
                        return;
                    }
                    break;
            }
        }
    }
}
