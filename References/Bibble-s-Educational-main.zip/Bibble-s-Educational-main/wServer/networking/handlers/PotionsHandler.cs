﻿using System;
using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.realm;

namespace wServer.networking.handlers
{
    class PotionsHandler : PacketHandlerBase<Potions>
    {
        public override PacketId ID => PacketId.POTIONS;

        protected override void HandlePacket(Client client, Potions packet)
        {
            client.Manager.Logic.AddPendingAction(t => Handle(client, packet, t));
        }

        private void Handle(Client client, Potions packet, RealmTime time)
        {
            if (packet.Type < 0 || packet.Type > 10) return;
            
            var player = client.Player;
            var acc = client.Account;
            var potionStorage = acc.PotionStoragePotions;
            var plrStats = player.Manager.Resources.GameData.Classes[player.ObjectType].Stats;
            var multiplier = packet.Type <= 1 ? 5 : 1;
            int amount;
            bool maxed;
            if (packet.Type > 7)
                packet.Type += 3;
            
            if (potionStorage[packet.Type] < 0)
            {
                potionStorage[packet.Type] = 0;
                acc.PotionStoragePotions = potionStorage;
                acc.FlushAsync();
                return;
            }

            if (player.Stats.Base[packet.Type] >= plrStats[packet.Type].MaxValue)
            {
                player.SendInfo("This stat is already maxed!");
                return;
            }

            if (potionStorage[packet.Type] == 0)
            {
                player.SendInfo("You don't have any more potions of this stat!");
                return;
            }

            if (packet.Max)
            {
                amount = player.Stats.Base[packet.Type] + potionStorage[packet.Type] * 1 * multiplier;
                player.Stats.Base[packet.Type] = Math.Min(plrStats[packet.Type].MaxValue, amount);
                potionStorage[packet.Type] = Math.Max(0, (amount - player.Stats.Base[packet.Type]) / multiplier);
                maxed = player.Stats.Base[packet.Type] == plrStats[packet.Type].MaxValue;
                player.SendInfo($"Potions consumed{(maxed ? " and you are now maxed!" : "!")}");
            }
            else
            {
                player.Stats.Base[packet.Type] = Math.Min(plrStats[packet.Type].MaxValue,
                    player.Stats.Base[packet.Type] + multiplier);
                potionStorage[packet.Type] -= 1;
            }

            acc.PotionStoragePotions = potionStorage;
            acc.FlushAsync();
        }
    }
}
