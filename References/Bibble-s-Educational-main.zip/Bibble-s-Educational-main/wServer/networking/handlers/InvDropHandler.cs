﻿using System;
using System.Linq;
using wServer.realm;
using wServer.realm.entities;
using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.networking.packets.outgoing;

namespace wServer.networking.handlers
{
    class InvDropHandler : PacketHandlerBase<InvDrop>
    {
        public override PacketId ID => PacketId.INVDROP;

        protected override void HandlePacket(Client client, InvDrop packet)
        {
            Handle(client.Player, packet.SlotObject);
        }

        private void Handle(Player player, ObjectSlot slot)
        {
            if (player?.Owner == null || player.tradeTarget != null)
                return;

            IContainer con;

            // container isn't always the player's inventory, it's given by the SlotObject's ObjectId
            if (slot.ObjectId != player.Id)
            {
                if (player.Owner.GetEntity(slot.ObjectId) is Player)
                {
                    player.Client.SendPacket(new InvResult() { Result = 1 });
                    return;
                }
                con = player.Owner.GetEntity(slot.ObjectId) as IContainer;
            } 
            else
                con = player as IContainer;

            if (slot.ObjectId == player.Id && player.Stacks.Any(stack => stack.Slot == slot.SlotId))
            {
                player.Client.SendPacket(new InvResult() { Result = 1 });
                return; // don't allow dropping of stacked items
            }
            
            if (con?.Inventory[slot.SlotId] == null)
            {
                //give proper error
                player.Client.SendPacket(new InvResult() { Result = 1 });
                return;
            }
            
            var item = con.Inventory[slot.SlotId];

            // if item is from gift chest, remove from user's gift chest list
            if (con is GiftChest)
            {
                var trans = player.Manager.Database.Conn.CreateTransaction();
                player.Manager.Database.RemoveGift(player.Client.Account, item.ObjectType, trans);
                if (!trans.Execute())
                {
                    player.Client.SendPacket(new InvResult() { Result = 1 });
                    return;
                }
            }

            con.Inventory[slot.SlotId] = null;

            // create new container for item to be placed in
            Container container;
            if (item.Soulbound || item.Tier == -1 || player.Client.Account.Rank >= 50)
            {
                container = new Container(player.Manager, 0x0503, 1000 * 60, true);
                container.BagOwners = new int[] { player.AccountId };
            }
            else
                container = new Container(player.Manager, 0x0500, 1000 * 60, true);

            // init container
            container.Inventory[0] = item;
            container.Move(player.X + 0.5f, player.Y + 0.5f);
            container.SetDefaultSize(80);
            player.Owner.EnterWorld(container);

            // save to character
            player.SaveToCharacter();
            player.Client.Character.FlushAsync();

            // send success
            player.Client.SendPacket(new InvResult() { Result = 0 });
        }
    }
}
