﻿using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.realm;

namespace wServer.networking.handlers
{
    class FragmentsHandler : PacketHandlerBase<Fragments>
    {
        public override PacketId ID => PacketId.FRAGMENTS;

        protected override void HandlePacket(Client client, Fragments packet)
        {
            client.Manager.Logic.AddPendingAction(t => Handle(client, packet, t));
        }

        private void Handle(Client client, Fragments packet, RealmTime time)
        {
            var type = packet.Type;
            if (type > 10) return;
            if (type > 7) 
                type += 3;
            var plr = client.Player;
            var acc = client.Account;
            var fragments = client.Account.MaxFragments;
            int price;
            price = 1500 + (fragments[type] * 1000);
            if (plr.Ascended == 0)
            {
                plr.SendError("You have to be ascended to use this!");
                return;
            }
            if (acc.Fame < price)
            {
                plr.SendError("You don't have enough fame to upgrade this fragment!");
                return;
            }
            if (fragments[type] >= 6)
            {
                plr.SendError("This stat is already maxed!");
                return;
            }

            plr.CurrentFame = acc.Fame -= price;
            fragments[type]++;
            plr.SendInfo($"Upgraded! [{fragments[type]}/6]");
            acc.MaxFragments = fragments;
            acc.FlushAsync();
        }
    }
}
