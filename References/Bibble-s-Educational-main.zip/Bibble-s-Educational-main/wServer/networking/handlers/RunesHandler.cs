﻿using common;
using common.resources;

using System;
using System.Collections.Generic;
using System.Linq;

using wServer.networking.packets;
using wServer.networking.packets.incoming;
using wServer.realm;

namespace wServer.networking.handlers
{
    class RunesHandler : PacketHandlerBase<Runes>
    {
        public override PacketId ID => PacketId.RUNES;

        public string[] attackRune = { "Lightning Strike", "Crown of Enmity", "Rogue's Cloak", "Mundanity", "Boot of Hermes" };

        public string[] supportRune = { "Blood Siphon", "Ethereal Clover", "Élan Vital", "Gemstone of Immunity", "Bud of Life" };

        protected override void HandlePacket(Client client, Runes packet)
        {
            Handle(client, packet);
        }

        private void Handle(Client client, Runes packet)
        {
            var plr = client.Player;
            var acc = client.Account;
            var db = client.Player.Manager.Database;

            int attack = packet.AttackRune;
            int support = packet.SupportRune;

            int[] attackRunes = { acc.LightningStrike, acc.CrownOfEnmity, acc.RoguesCloak, acc.Mundanity, acc.BootOfHermes };
            int[] supportRunes = { acc.BloodSiphon, acc.EtherealClover, acc.ÉlanVital, acc.GemOfImmunity, acc.BudOfLife };

            if (plr.AttackRune != attack)
            { 
                if (attack != 0)
                {
                    if (attackRunes[attack - 1] > 0)
                    {
                        if (plr.AttackRune != 0)
                        {
                            db.UpdateAttackRune(acc, plr.AttackRune, 1);
                        }
                        db.UpdateAttackRune(acc, attack, -1);
                        acc.FlushAsync();

                        plr.AttackRune = attack;
                        plr.InvokeStatChange(StatsType.AttackRune, attack);
                        plr.Stats.ReCalculateValues();
                        plr.SendInfo("Selected: " + attackRune[attack - 1]);
                    }
                    else
                    {
                        if (plr.AttackRune != 0)
                        {
                            db.UpdateAttackRune(acc, plr.AttackRune, 1);
                            acc.FlushAsync();
                        }
                        plr.AttackRune = 0;
                        plr.InvokeStatChange(StatsType.AttackRune, 0);
                        plr.Stats.ReCalculateValues();
                        plr.SendError("You selected a locked attack rune!");
                    }
                }
                else if (plr.AttackRune != 0)
                {
                    db.UpdateAttackRune(acc, plr.AttackRune, 1);
                    acc.FlushAsync();
                    plr.AttackRune = 0;
                    plr.InvokeStatChange(StatsType.AttackRune, 0);
                    plr.Stats.ReCalculateValues();
                    plr.SendInfo("Deselected your attack rune.");
                }
            }

            if (plr.SupportRune != support)
            {
                if (support != 0)
                {
                    if (supportRunes[support - 1] > 0)
                    {
                        if (plr.SupportRune != 0)
                        {
                            db.UpdateSupportRune(acc, plr.SupportRune, 1);
                        }
                        db.UpdateSupportRune(acc, support, -1);
                        acc.FlushAsync();

                        plr.SupportRune = support;
                        plr.InvokeStatChange(StatsType.SupportRune, support);
                        plr.Stats.ReCalculateValues();
                        plr.SendInfo("Selected: " + supportRune[support - 1]);
                    }
                    else
                    {
                        if (plr.SupportRune != 0)
                        {
                            db.UpdateSupportRune(acc, plr.SupportRune, 1);
                            acc.FlushAsync();
                        }
                        plr.SupportRune = 0;
                        plr.InvokeStatChange(StatsType.SupportRune, 0);
                        plr.Stats.ReCalculateValues();
                        plr.SendError("You selected a locked support rune!");
                    }
                }
                else if (plr.SupportRune != 0)
                {
                    db.UpdateSupportRune(acc, plr.SupportRune, 1);
                    acc.FlushAsync();
                    plr.SupportRune = 0;
                    plr.InvokeStatChange(StatsType.SupportRune, 0);
                    plr.Stats.ReCalculateValues();
                    plr.SendInfo("Deselected your support rune.");
                }
            }
        }
    }
}
