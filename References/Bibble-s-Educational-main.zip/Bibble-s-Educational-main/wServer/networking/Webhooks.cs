﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiscordWebhook;

namespace wServer.networking
{
    public class Webhooks
    {
        //make a Webhook object so the server will know where to send the webhook
        public static Webhook banLogWebhook = new Webhook("https://discord.com/api/webhooks/834161329861820476/jaBR3sIyLqHYWh6cLilBhtm00UFXjdCrZaF88dFEObUyOprpL5DeJaOIvHOo8jeEoLUp");
        public static Webhook detahLogWebhook = new Webhook("https://discord.com/api/webhooks/834168322903506965/JKXflc-7y1iqeaKf2-6TWRfawXyJYN6ejDEegayrVHzQ8oiLe7njV2X0zjJG2ZIo8Ad0");
        public static Webhook lootLogWebhook = new Webhook("https://discord.com/api/webhooks/834181545375432795/tOMRtAPclivmi77-DHvYNE8jfnC_EZlEBt1QHQ6JdzmeGeEPUc68GfvPXLzwLAxJMvhF");
        public static Webhook playerCountWebHook = new Webhook("https://discord.com/api/webhooks/842170904346886216/8EigKBbz8r_2u3Q-s0xnQjBoybkS_rykVAUHCsnmllVZP-LmL1U2VWDi94_O6h3BHHDG");
        public static Webhook commandWebHook = new Webhook("https://discord.com/api/webhooks/844307415281172561/VyhzZ8B8M9yA6M1b3x16Vzezda7YrtV5bTwGh-Pdq8TgniPLIFOK9hqipB3sF8mWpFZ8");
        public static void SendToDiscordAsPlayerCount(int count)
        {
            playerCountWebHook.PostData(new WebhookObject()
            {
                username = "Hootie!",
                avatar_url = "https://i.ibb.co/RpN951B/hootie.png",
                content = count.ToString()
            });
        }
        public static void SendToDiscordAsLootLog(string name, string type, string embedsString, int color, string imageURL)
        {
            /*Embed[] embeds =
            {
                    new Embed
                    {
                        thumbnail = new Thumbnail()
                        {
                            url = imageURL
                        },
                        fields = new Field[]
                        {
                            new Field()
                            {
                                name = type+" Loot!",
                                value = embedsString,
                                inline = true
                            }
                        },
                    color = color
                    }
                };
            lootLogWebhook.PostData(new WebhookObject()
            {
                username = name,
                avatar_url = "https://i.ibb.co/RpN951B/hootie.png",
                embeds = embeds
            });*/
        }
        public static void SendToDiscordAsBanLog(string name, string embedsString)
        {
            /* Embed[] embeds =
             {
                     new Embed
                     {
                         title = "",
                         description = embedsString
                     }
                 };
             banLogWebhook.PostData(new WebhookObject()
             {
                 username = name,
                 avatar_url = "https://i.ibb.co/RpN951B/hootie.png",
                 embeds = embeds
             });*/
        }

        public static void SendToDiscordAsCommandLog(string name, string embedsString)
        {
            /*Embed[] embeds =
             {
                     new Embed
                     {
                         title = "",
                         description = embedsString
                     }
                 };
             commandWebHook.PostData(new WebhookObject()
             {
                 username = name,
                 avatar_url = "https://i.ibb.co/RpN951B/hootie.png",
                 embeds = embeds
             });*/
        }

        public static void SendToDiscordAsDeathLog(string name, string embedsString)
        {
            /*Embed[] embeds =
            {
                    new Embed
                    {
                        title = "",
                        description = embedsString
                    }
                };
            detahLogWebhook.PostData(new WebhookObject()
            {
                username = name,
                embeds = embeds
            });*/
        }
    }
}
