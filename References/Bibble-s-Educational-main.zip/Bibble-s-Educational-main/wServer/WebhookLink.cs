﻿using common;
using System.Collections.Generic;
using log4net;
using System.Net.Http;
using System;

/* post to WebhookClient async */
namespace wServer
{
    public class WebhookLink
    {

        static HttpClient client = new HttpClient();
        static readonly ILog Log = LogManager.GetLogger("WebhookLink");

        public static async void SendToWebhookClient(WebhookType t, Dictionary<string, string> data)
        {
            if (Program.Config.serverInfo.address == "127.0.0.1" ||
                Program.Config.serverInfo.address == "localhost")
                return;
            
            try
            {
                data["webhookType"] = t.ToString();
                await client.PostAsync("http://127.0.0.1:5934/", new FormUrlEncodedContent(data));
            }
            catch (Exception e)
            {
                Log.Info("Exception: {0}", e);
            }
        }

    }
}
