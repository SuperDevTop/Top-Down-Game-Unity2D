﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ SnakePit = () => Behav()
            .Init("Stheno the Snake Queen",
            new State(
                new HPScale(25),
                new TransformOnDeath("SthenoDeathAnim"),
                new State("Waiting Player",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new PlayerWithinTransition(8, "Start")
                    ),
                new State("Start",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Hm? you got past the guards?"),
                    new TimedTransition(1000, "Start2")
                    ),
                new State("Start2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Good for you..."),
                    new TimedTransition(1000, "Start3")
                    ),
                new State("Start3",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Not that it matters."),
                    new TimedTransition(1000, "Attack")
                    ),
                new State("Attack",
                    new Wander(0.2),
                    new RingAttack(20, 12, 0, projectileIndex: 0, 35, 35, coolDown: 2500, seeInvis: true),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 36, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 72, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 108, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 144, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 180, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 216, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 252, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 288, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 324, color: 0xff0000, coolDown: 6000),
                    new Grenade(1.5, 115, range: 7, fixedAngle: 360, color: 0xff0000, coolDown: 6000),
                    new Grenade(3, 80, range: 8, color: 0xff0000, coolDown: 2000),
                    new HpLessTransition(0.75, "BleedT")
                    ),
                new State("BleedT",
                    new SetAltTexture(1),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Time to bleed."),
                    new ReturnToSpawn(speed: 2.50),
                    new TimedTransition(1500, "Bleed")
                    ),
                new State("Bleed",
                    new Swirl(1, 4, targeted: false),
                    new ReproduceChildren(3, 0, 4000, "Stheno Pet"),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, predictive: 0.3, coolDown: 1000),
                    new RingAttack(20, 16, 0, projectileIndex: 2, 45, 45, coolDown: 4000, seeInvis: true),
                    new Grenade(2.5, 90, range: 8, effect: ConditionEffectIndex.Bleeding, effectDuration: 1500, color: 0x00ff13, coolDown: 2500),
                    new HpLessTransition(0.50, "SpawnT")
                    ),
                new State("SpawnT",
                    new ReturnToSpawn(speed: 1.00),
                    new SetAltTexture(3),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("*Flute Music*"),
                    new TimedTransition(1500, "Spawn")
                    ),
                new State("Spawn",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new RingAttack(20, 16, 0, projectileIndex: 4, 45, 45, coolDown: 1000, seeInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 30, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 60, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 90, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 120, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 150, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 180, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 210, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 240, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 270, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 300, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 330, coolDown: 500000, tossInvis: true),
                    new TossObject("Stheno Swarm", 3, angle: 360, coolDown: 500000, tossInvis: true),
                    new TimedTransition(3000, "Wait")
                    ),
                new State("Wait",
                    new Swirl(1, 4, targeted: false),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new RingAttack(20, 16, 0, projectileIndex: 4, 45, 45, coolDown: 1000, seeInvis: true),
                    new EntityNotExistsTransition("Stheno Swarm", 60, "BleedT2"),
                    new TimedTransition(20000, "BleedT2")
                    ),
                new State("BleedT2",
                    new ReturnToSpawn(speed: 1.00),
                    new SetAltTexture(1),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("YOU BASTARD!"),
                    new TimedTransition(1500, "Bleed2")
                    ),
                new State("Bleed2",
                    new Swirl(1.5, 4, targeted: false),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, predictive: 0.3, coolDown: 750),
                    new RingAttack(20, 16, 0, projectileIndex: 2, 45, 45, coolDown: 3000, seeInvis: true),
                    new Grenade(2.5, 90, range: 8, effect: ConditionEffectIndex.Bleeding, effectDuration: 1500, color: 0x00ff13, coolDown: 2000),
                    new HpLessTransition(0.35, "SlashT")
                    ),
                new State("SlashT",
                    new SetAltTexture(2),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("How dare you kill all of MY CHILDREN!"),
                    new TimedTransition(1500, "Slash")
                    ),
                new State("Slash",
                    new Follow(1.1, 12, 0),
                    new Grenade(2, 100, range: 0, fixedAngle: 36, color: 0xff0000, coolDown: 1000),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 3, predictive: 0.3, coolDown: 500),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 5, predictive: 0.3, coolDown: 500),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 6, predictive: 0.3, coolDown: 500),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 7, predictive: 0.3, coolDown: 500),
                    new HpLessTransition(0.05, "Death")
                    ),
                new State("Death",
                    new SetAltTexture(4),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("We were just.. taking refuge from oryx…."),
                    new TimedTransition(1500, "Death2")
                    ),
                 new State("Death2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("You humans wouldn’t stop invading…"),
                    new TimedTransition(1500, "Death3")
                    ),
                new State("Death3",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Suicide()
                    )
                ),
                 new Threshold(0.03,
                    new ItemLoot("Wand of the Bulwark", 0.005)
                ),
                new Threshold(0.0001,
                    new ItemLoot("Speed Fragment", 0.05),
                    new ItemLoot("Potion of Speed", 1),
                    new ItemLoot("Potion Tablet", 0.05),
                    new ItemLoot("Book of Poisons", 0.02),
                    new ItemLoot("Slithering Robe", 0.02),
                    new ItemLoot("Snake Pit Key", 0.005),
                    new ItemLoot("Shard of Evolution", 0.013),
                    new TierLoot(9, ItemType.Weapon, 0.2),
                    new TierLoot(10, ItemType.Weapon, 0.1),
                    new TierLoot(10, ItemType.Weapon, 0.07),
                    new TierLoot(8, ItemType.Armor, 0.3),
                    new TierLoot(9, ItemType.Armor, 0.2),
                    new TierLoot(10, ItemType.Armor, 0.1),
                    new TierLoot(11, ItemType.Armor, 0.07)
                )
            )
        .Init("SthenoDeathAnim",
                new State(
                    new DropPortalOnDeath(target: "Realm Portal", probability: 1.0),
                    new State("Waiting",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3100, "Despawn")
                    ),
                    new State("Despawn",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Suicide()
                    )
                )
            )
            .Init("Stheno Swarm",
                new State(
                    new HPScale(25),
                    new State("Protect",
                        new Prioritize(
                            new Protect(0.3, "Stheno the Snake Queen"),
                            new Wander(0.3)
                        ),
                        new Shoot(10, coolDown: new Cooldown(750, 250))
                    ),
                    new State("Despawn",
                        new Suicide()
                    )
                )
            )
            .Init("Stheno Pet",
                new State(
                    new HPScale(25),
                    new State("Protect",
                        new Shoot(25, coolDown: 1000),
                        new State("Protect",
                            new Orbit(1.5, 6, acquireRange: 10, target: "Stheno the Snake Queen"),
                            new TimedTransition(9000, "Die")
                        ),
                        new State("Die",
                            new Suicide()
                        )
                    )
                )
            )
            .Init("Pit Snake",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(1),
                        new Wander(1)
                    ),
                    new Shoot(20, coolDown: 1000)
                )
            )
            .Init("Poison Fanged Snake",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(1),
                        new Wander(1)
                    ),
                    new Shoot(20, coolDown: 1000)
                )
            )
            .Init("Pit Viper",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(1),
                        new Wander(1)
                    ),
                    new Shoot(20, coolDown: 1000)
                )
            )
            .Init("Yellow Python",
                new State(
                    new Prioritize(
                        new Follow(1, 10, 1),
                        new StayCloseToSpawn(1),
                        new Wander(1)
                    ),
                    new Shoot(20, coolDown: 1000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new ItemLoot("Ring of Speed", 0.1),
                new ItemLoot("Ring of Vitality", 0.1)
            )
            .Init("Brown Python",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(1),
                        new Wander(1)
                    ),
                    new Shoot(20, coolDown: 1000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new ItemLoot("Leather Armor", 0.1),
                new ItemLoot("Ring of Wisdom", 0.1)
            )
            .Init("Fire Python",
                new State(
                    new Prioritize(
                        new Follow(1, 10, 1, coolDown: 2000),
                        new Wander(1)
                    ),
                    new Shoot(15, count: 3, shootAngle: 5, coolDown: 1000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new ItemLoot("Fire Bow", 0.1),
                new ItemLoot("Fire Nova Spell", 0.1)
            )
            .Init("Greater Pit Snake",
                new State(
                    new Prioritize(
                        new Follow(1, 10, 5),
                        new Wander(1)
                    ),
                    new Shoot(15, count: 3, shootAngle: 5, coolDown: 1000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new ItemLoot("Glass Sword", 0.1),
                new ItemLoot("Avenger Staff", 0.1),
                new ItemLoot("Wand of Dark Magic", 0.1)
            )
            .Init("Greater Poison Snake",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(2),
                        new Wander(1)
                    ),
                    new Shoot(15, count: 1, coolDown: 1000),
                    new Grenade(1.5, 80, range: 9, effect: ConditionEffectIndex.Bleeding, effectDuration: 1250, color: 0x00ff13, coolDown: 2000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new ItemLoot("Glass Sword", 0.1),
                new ItemLoot("Avenger Staff", 0.1),
                new ItemLoot("Wand of Dark Magic", 0.1)
            )
            .Init("Greater Pit Viper",
                new State(
                    new Prioritize(
                        new Follow(1, 10, 5),
                        new Wander(1)
                    ),
                    new Shoot(15, coolDown: 300)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new Threshold(0.1,
                    new ItemLoot("Ring of Greater Attack", 0.1),
                    new ItemLoot("Ring of Greater Health", 0.1)
                )
            )
            .Init("Armored Pit Snake",
                new State(
                    new Prioritize(
                        new Follow(1, 10, 5),
                        new Wander(1)
                    ),
                    new Shoot(10, 1, fixedAngle: 45, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 90, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 135, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 180, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 225, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 270, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 315, coolDown: 1000),
                    new Shoot(10, 1, fixedAngle: 360, coolDown: 1000)
                ),
                new ItemLoot("Snake Oil", 0.1),
                new Threshold(0.1,
                    new ItemLoot("Ring of Greater Attack", 0.1),
                    new ItemLoot("Ring of Greater Health", 0.1)
                )
            )
            .Init("Snakepit Guard",
                new State(
                    new Prioritize(
                            new StayCloseToSpawn(0.2, 4),
                            new Wander(0.2)
                        ),
                    new State("Phase 1",
                        new Shoot(25, count: 3, shootAngle: 25, projectileIndex: 0, coolDown: new Cooldown(1000, 200)),
                        new Shoot(10, count: 6, projectileIndex: 1, coolDown: 1000),
                        new HpLessTransition(0.6, "Phase 2")
                        ),
                    new State("Phase 2",
                        new RemoveObjectOnDeath("SP Snake Barrier", 50),
                        new Shoot(25, count: 3, shootAngle: 25, projectileIndex: 0, coolDown: new Cooldown(1000, 200)),
                        new Shoot(10, count: 6, projectileIndex: 1, coolDown: 1000),
                        new Shoot(15, count: 3, projectileIndex: 2, coolDown: 2000),
                        new HpLessTransition(0.2, "Death")
                        ),
                    new State("Death",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new RemoveObjectOnDeath("SP Snake Barrier", 50),
                        new Suicide()
                        )
                    ),
                new Threshold(0.02,
                    new ItemLoot("Potion of Dexterity", 1),
                    new ItemLoot("Potion Tablet", 0.25)
                ),
                new Threshold(0.01,
                    new ItemLoot("Snake Skin Armor", 0.1),
                    new ItemLoot("Snake Skin Shield", 0.1),
                    new TierLoot(9, ItemType.Weapon, 0.2),
                    new TierLoot(10, ItemType.Weapon, 0.1),
                    new TierLoot(8, ItemType.Armor, 0.3),
                    new TierLoot(9, ItemType.Armor, 0.2),
                    new TierLoot(10, ItemType.Armor, 0.1)
                )
            )
            .Init("Pit Poison Guard",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.2, 4),
                        new Wander(0.2)
                        ),
                    new State("Phase 1",
                        new Shoot(25, count: 3, shootAngle: 15, projectileIndex: 0, coolDown: new Cooldown(1000, 200)),
                        new Grenade(2, 100, range: 9, effect: ConditionEffectIndex.Bleeding, effectDuration: 1250, color: 0x00ff13, coolDown: 2000),
                        new HpLessTransition(0.6, "Phase 2")
                        ),
                    new State("Phase 2",
                            new RemoveObjectOnDeath("SP Snake Barrier", 50),
                            new Wander(0.2),
                            new Follow(0.2, acquireRange: 10, range: 3),
                            new Shoot(25, count: 3, shootAngle: 15, projectileIndex: 0, coolDown: new Cooldown(1000, 200)),
                            new Grenade(2, 100, range: 9, effect: ConditionEffectIndex.Bleeding, effectDuration: 1250, color: 0x00ff13, coolDown: 2000),
                            new Grenade(2.5, 120, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Bleeding, effectDuration: 1500, color: 0xff0000, coolDown: 4000),
                            new RingAttack(20, 8, 0, projectileIndex: 0, 45, 45, coolDown: 2000, seeInvis: true),
                            new HpLessTransition(0.2, "Death")
                        ),
                    new State("Death",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new RemoveObjectOnDeath("SP Viper Barrier", 50),
                            new Suicide()
                        )
                    ),
                new Threshold(0.02,
                    new ItemLoot("Potion of Speed", 1),
                    new ItemLoot("Potion Tablet", 0.25)
                ),
                new Threshold(0.01,
                    new ItemLoot("Snake Skin Armor", 0.1),
                    new ItemLoot("Snake Skin Shield", 0.1),
                    new TierLoot(9, ItemType.Weapon, 0.2),
                    new TierLoot(10, ItemType.Weapon, 0.1),
                    new TierLoot(8, ItemType.Armor, 0.3),
                    new TierLoot(9, ItemType.Armor, 0.2),
                    new TierLoot(10, ItemType.Armor, 0.1)
                )
            )
            .Init("Snakepit Dart Thrower",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible, true),
                    new State("Idle"),
                    new State("Protect the Guard",
                        new EntityNotExistsTransition("Snakepit Guard", 40, "Idle")
                    )
                )
            )
            .Init("Snakepit Button",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible, true),
                    new State("Idle",
                        new PlayerWithinTransition(0.5, "Order")
                    ),
                    new State("Order",
                        new Order(15, "Snakepit Guard Spawner", "Spawn the Guard"),
                        new SetAltTexture(1),
                        new TimedTransition(0, "I am out")
                    ),
                    new State("I am out")
                )
            )
            .Init("Snakepit Guard Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible, true),
                    new State("Idle"),
                    new State("Spawn the Guard",
                        new Order(15, "Snakepit Dart Thrower", "Protect the Guard"),
                        new Spawn("Snakepit Guard", maxChildren: 1, initialSpawn: 1),
                        new TimedTransition(0, "Idle")
                    )
                )
            )
            .Init("Snake Grate",
                new State(
                    new State("Idle",
                        new EntityNotExistsTransition("Pit Snake", 5, "Spawn Pit Snake"),
                        new EntityNotExistsTransition("Pit Viper", 5, "Spawn Pit Viper")
                    ),
                    new State("Spawn Pit Snake",
                        new Spawn("Pit Snake", 1, 1),
                        new TimedTransition(2000, "Idle")
                    ),
                    new State("Spawn Pit Viper",
                        new Spawn("Pit Viper", 1, 1),
                        new TimedTransition(2000, "Idle")
                    )
                )
            );
    }
}
