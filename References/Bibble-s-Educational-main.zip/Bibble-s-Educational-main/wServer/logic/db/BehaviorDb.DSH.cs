﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ DSH = () => Behav()
            .Init("Deep Space Hunter",
                new State(
                    new HPScale(20),
                    new State("Check",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new PlayerWithinTransition(10, "Waiting")
                        ),
                    new State("Waiting",
                        new Taunt(1.0, "Grr.."),
                        new Flash(0xe01010, 0.2, 25),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TimedTransition(4000, "Attack")
                        ),
                    new State("Attack",
                        new Taunt(1.0, "GRAHH!"),
                        new Wander(0.3),
                        new Shoot(15, count: 11, projectileIndex: 0, shootAngle: 32, fixedAngle: 90, coolDown: 3000),
                        new Shoot(15, count: 3, projectileIndex: 0, predictive: 0.15, shootAngle: 16, coolDown: 1500),
                        new Shoot(15, count: 5, projectileIndex: 1, shootAngle: 4, coolDown: 1000),
                        new HpLessTransition(0.80, "Spears")
                        ),
                    new State("Spears",
                        new SetAltTexture(1),
                        new Taunt(1.0, "GRAHH!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.52),
                        new Shoot(15, count: 1, projectileIndex: 2, predictive: 0.1, coolDown: 1000),
                        new Shoot(15, count: 4, projectileIndex: 2, predictive: 0.1, shootAngle: 24, coolDown: 2000),
                        new TimedTransition(6000, "Quick Attack")
                        ),
                    new State("Quick Attack",
                        new SetAltTexture(3),
                        new Taunt(1.0, "ROOOAR"),
                        new Wander(0.2),
                        new Shoot(15, count: 11, projectileIndex: 0, shootAngle: 32, fixedAngle: 90, coolDown: 2000),
                        new Shoot(15, count: 3, projectileIndex: 0, predictive: 0.15, shootAngle: 16, coolDown: 1000),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 250),
                        new HpLessTransition(0.60, "Beam")
                        ),
                    new State("Beam",
                        new SetAltTexture(2),
                        new Flash(0xe01010, 0.2, 25),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.52),
                        new Shoot(15, count: 3, projectileIndex: 3, shootAngle: 20, coolDown: 200),
                        new HpLessTransition(0.40, "Attack 2"),
                        new TimedTransition(2000, "Fire Beam")
                        ),
                    new State("Fire Beam",
                        new Shoot(15, count: 3, projectileIndex: 4, shootAngle: 20, coolDown: 200),
                        new HpLessTransition(0.40, "Attack 2"),
                        new TimedTransition(2000, "Beam")
                        ),
                    new State("Attack 2",
                        new SetAltTexture(3),
                        new Taunt(1.0, "ROAR"),
                        new Wander(0.3),
                        new Shoot(15, count: 11, projectileIndex: 0, shootAngle: 32, fixedAngle: 90, coolDown: 3000),
                        new Shoot(15, count: 3, projectileIndex: 0, predictive: 0.15, shootAngle: 16, coolDown: 1500),
                        new Shoot(15, count: 5, projectileIndex: 1, shootAngle: 4, coolDown: 1000),
                        new HpLessTransition(0.05, "Death"),
                        new HpLessTransition(0.25, "Spears 2")
                        ),
                    new State("Spears 2",
                        new SetAltTexture(1),
                        new Taunt(1.0, "Grr"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.52),
                        new Shoot(15, count: 1, projectileIndex: 2, predictive: 0.1, coolDown: 1000),
                        new Shoot(15, count: 4, projectileIndex: 2, predictive: 0.1, shootAngle: 24, coolDown: 2000),
                        new HpLessTransition(0.05, "Death"),
                        new TimedTransition(6000, "Quick Attack 2")
                        ),
                    new State("Quick Attack 2",
                        new SetAltTexture(3),
                        new Taunt(1.0, "ROOOAR"),
                        new Wander(0.4),
                        new Shoot(15, count: 11, projectileIndex: 0, shootAngle: 32, fixedAngle: 90, coolDown: 2000),
                        new Shoot(15, count: 3, projectileIndex: 0, predictive: 0.15, shootAngle: 16, coolDown: 1000),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 250),
                        new HpLessTransition(0.05, "Death"),
                        new HpLessTransition(0.20, "Beam 2")
                        ),
                    new State("Beam 2",
                        new SetAltTexture(2),
                        new Flash(0xe01010, 0.2, 25),
                        new ReturnToSpawn(speed: 0.52),
                        new Shoot(15, count: 3, projectileIndex: 3, shootAngle: 20, coolDown: 200),
                        new HpLessTransition(0.05, "Death"),
                        new TimedTransition(2000, "Fire Beam 2")
                        ),
                    new State("Fire Beam 2",
                        new Shoot(15, count: 3, projectileIndex: 4, shootAngle: 20, coolDown: 200),
                        new HpLessTransition(0.05, "Death"),
                        new TimedTransition(2000, "Attack 2")
                        ),
                    new State("Death",
                        new Taunt(1.0, "Grr... You win.."),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TimedTransition(2000, "Death2")
                        ),
                    new State("Death2",
                        new Suicide()
                        )
                    ),
                new Threshold(.005,
                     LootTemplates.BasicDrop()
                     ),
                  new Threshold(.005,
                     LootTemplates.BasicPots()
                     ),
                new Threshold(0.01,
                    new ItemLoot("Hunter's Disk", 0.02),
                    new ItemLoot("Hunter's Blade", 0.02),
                    new ItemLoot("Hunter's Charm", 0.02),
                    new ItemLoot("Boot of Hermes Rune", 0.025)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Helmet of the Hunter", 0.005)
                    )
            );
    }
}
