﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.transitions;

using wServer.realm.entities;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Ability = () => Behav()
            .Init("Test Charge",
                 new State(
                      new State("Idle",
                            new Charge(speed: 1.4, range: 11, coolDown: 100, false, (host, time, entity, state) => {
                                (entity as Enemy).Damage((state as Charge.ChargeState).from, time, 10000, true, new ConditionEffect[] { });
                                host.Owner.LeaveWorld(host);
                            }),
                            new TimedTransition(5000, "die")
                      ),
                 new State("die", new Decay(0))
                 )
            );
    }
}