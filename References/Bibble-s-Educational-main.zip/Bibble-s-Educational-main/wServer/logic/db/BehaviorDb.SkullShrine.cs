﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ SkullShrine = () => Behav()
            .Init("Skull Shrine",
                new State(
                    new HPScale(30),
                    new Shoot(30, 4, 9, coolDown: 1500, predictive: 1), // add prediction after fixing it...
                    new RingAttack(30, 2, 0, projectileIndex: 0, 0.2, 0.2, coolDown: 75),
                    new Reproduce("Blue Flaming Skull", 20, 5, coolDown: 1000)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Orb of Conflict", 0.005),
                    new ItemLoot("Inferno Amulet", 0.005)
                    ),
                new Threshold(0.01,
                    new ItemLoot("Inferno Cane", 0.02),
                    new ItemLoot("Inferno Skull", 0.02)
                    ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.06)
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
            new Threshold(0.005,
                    LootTemplates.BasicPots()
                    )
            )
            .Init("Red Flaming Skull",
                new State(
                    new State("Orbit Skull Shrine",
                        new Prioritize(
                            new Protect(.2, "Skull Shrine", 30, 15, 15),
                            new Wander(.2)
                            ),
                        new EntityNotExistsTransition("Skull Shrine", 40, "Wander")
                        ),
                    new State("Wander",
                        new Wander(.2)
                        ),
                    new Shoot(12, 2, 10, coolDown: 750)
                    )
            )
            .Init("Blue Flaming Skull",
                new State(
                    new State("Orbit Skull Shrine",
                        new Orbit(1.0, 15, 40, "Skull Shrine", .6, 10),
                        new EntityNotExistsTransition("Skull Shrine", 40, "Wander")
                        ),
                    new State("Wander",
                        new Wander(1.0)
                        ),
                    new Shoot(12, 2, 10, coolDown: 750)
                    )
            );
    }
}
