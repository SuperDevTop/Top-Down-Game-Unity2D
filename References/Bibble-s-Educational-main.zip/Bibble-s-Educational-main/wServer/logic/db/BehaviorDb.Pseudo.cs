﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using common.resources;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Psuedo = () => Behav()


        .Init("Duality",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new PlayerWithinTransition(12, "tentacle")
                        ),
                    new State("tentacle",
                        new Wander(0.2),
                        new StayCloseToSpawn(0.4, 3),
                        new Shoot(10, predictive: 1, count: 3, shootAngle: 20, coolDown: 900, projectileIndex: 1),
                        new Shoot(10, fixedAngle: 0, count: 6, shootAngle: 60, coolDownOffset: 0, coolDown: 1800, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 10, count: 6, shootAngle: 60, coolDownOffset: 300, coolDown: 1800, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 20, count: 6, shootAngle: 60, coolDownOffset: 600, coolDown: 1800, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 30, count: 6, shootAngle: 60, coolDownOffset: 900, coolDown: 1800, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 40, count: 6, shootAngle: 60, coolDownOffset: 1200, coolDown: 1800, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 50, count: 6, shootAngle: 60, coolDownOffset: 1500, coolDown: 1800, projectileIndex: 0),
                        new HpLessTransition(0.5, "pause1")
                        ),
                     new State("pause1",
                         new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                         new Taunt("010010111001101100"),
                         new TimedTransition(1500, "pausecont")
                        ),
                     new State("pausecont",
                         new Flash(0xFF0000, 0.5, 3),
                         new TimedTransition(500, "rage")
                         ),
                    new State("rage",
                        new Follow(1.2, 8, 1),
                        new Shoot(10, predictive: 1, count: 5, shootAngle: 10, coolDown: 1000, projectileIndex: 0),
                        new Shoot(10, predictive: 1, count: 5, shootAngle: 10, coolDown: 2000, projectileIndex: 1),
                        new TimedTransition(6000, "pause2")
                        ),
                     new State("pause2",
                         new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                         new Shoot(10, fixedAngle: 0, count: 4, shootAngle: 90, coolDown: 1000, projectileIndex: 1),
                         new Shoot(10, fixedAngle: 22, count: 4, shootAngle: 90, coolDown: 1000, coolDownOffset: 333, projectileIndex: 1),
                         new Shoot(10, fixedAngle: 45, count: 4, shootAngle: 90, coolDown: 100, coolDownOffset: 666, projectileIndex: 1),
                         new TimedTransition(4000, "rage")
                        )
                    ),
            new Threshold(0.005,
                    new ItemLoot("Potion of Attack", 1),
                    new ItemLoot("Potion of Dexterity", 1)
                ),
            new Threshold(0.01,
                    LootTemplates.BasicDrop()
                )
           );

    }
}
