﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
//by GhostMaree
namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ HauntedCemetery = () => Behav()
            //md1 Left Burst
            .Init("Area 1 Controller",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible, perm: true),
                    new State("Start",
                        new PlayerWithinTransition(4, "1")
                    ),
                    new State("1",
                        new TimedTransition(0, "2")
                    ),
                    new State("2",
                        new SetAltTexture(2),
                        new TimedTransition(100, "3")
                    ),
                    new State("3",
                        new SetAltTexture(1),
                        new Taunt(true,
                            "Welcome to my domain. I challenge you, warrior, to defeat my undead hordes and claim your prize...."),
                        new TimedTransition(2000, "4")
                    ),
                    new State("4",
                        new Taunt(true, "Say, 'READY' when you are ready to face your opponents.",
                            "Prepare yourself... Say, 'READY' when you wish the battle to begin!"),
                        new TimedTransition(0, "5")
                    ),
                    new State("5",
                        new PlayerTextTransition("7", "ready"),
                        new SetAltTexture(3, 4, 150, true)
                    ),
                    new State("7",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 1"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 1"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 1"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 1"),
                        new TimedTransition(100, "Check 1")
                    ),
                    new State("Check 1",
                        new SetDisplayName("c::10"),
                        new NoEnemiesWithinTransition(100, "8"),
                        new TimedTransition(10000, "8")
                    ),
                    new State("8",
                        new SetDisplayName(),
                        new SetAltTexture(2, 1, 150),
                        new TimedTransition(300, "10")
                    ),
                    new State("10",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "11")
                    ),
                    new State("11",
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "27")
                    ),
                    new State("27",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 2"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 2"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 2"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 2"),
                        new TimedTransition(100, "Check 2")
                    ),
                    new State("Check 2",
                        new SetDisplayName("c::10"),
                        new NoEnemiesWithinTransition(100, "28"),
                        new TimedTransition(10000, "28")
                    ),
                    new State("28",
                        new SetDisplayName(),
                        new SetAltTexture(2, 1, 150),
                        new TimedTransition(0, "30")
                    ),
                    new State("30",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "31")
                    ),
                    new State("31",
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "47")
                    ),
                    new State("47",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 3"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 3"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 3"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 3"),
                        new TimedTransition(100, "Check 3")
                    ),
                    new State("Check 3",
                        new SetDisplayName("c::10"),
                        new NoEnemiesWithinTransition(100, "48"),
                        new TimedTransition(10000, "48")
                    ),
                    new State("48",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(0, "50")
                    ),
                    new State("50",
                        new Taunt(true, "Boss wave coming in a few seconds!"),
                        new TimedTransition(0, "51")
                    ),
                    new State("51",
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "67")
                    ),
                    new State("67",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 4"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 4"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 4"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 4"),
                        new TimedTransition(100, "Check 4")
                    ),
                    new State("Check 4",
                        new SetDisplayName("c::30"),
                        new NoEnemiesWithinTransition(100, "68"),
                        new TimedTransition(30000, "68")
                    ),
                    new State("68",
                        new SetAltTexture(2),
                        new TimedTransition(0, "69")
                    ),
                    new State("69",
                        new SetAltTexture(1),
                        new TimedTransition(500, "70")
                    ),
                    new State("70",
                        new Taunt(true, "Boss wave coming in a few seconds!"),
                        new TimedTransition(0, "71")
                    ),
                    new State("71",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "87")
                    ),
                    new State("87",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 5"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 5"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 5"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 5"),
                        new TimedTransition(100, "Check 5")
                    ),
                    new State("Check 5",
                        new SetDisplayName("c::30"),
                        new NoEnemiesWithinTransition(100, "Wave 6 Start"),
                        new TimedTransition(30000, "Wave 6 Start")
                    ),
                    new State("Wave 6 Start",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 6 Taunt")
                    ),
                    new State("Wave 6 Taunt",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "Wave 6 anim")
                    ),
                    new State("Wave 6 anim",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 6 Spawn")
                    ),
                    new State("Wave 6 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 6"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 6"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 6"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 6"),
                        new TimedTransition(100, "Wave 6 Check")
                    ),
                    new State("Wave 6 Check",
                        new SetDisplayName("c::10"),
                        new NoEnemiesWithinTransition(100, "Wave 7 Start"),
                        new TimedTransition(10000, "Wave 7 Start")
                    ),
                    new State("Wave 7 Start",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 7 Taunt")
                    ),
                    new State("Wave 7 Taunt",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "Wave 7 anim")
                    ),
                    new State("Wave 7 anim",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 7 Spawn")
                    ),
                    new State("Wave 7 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 7"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 7"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 7"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 7"),
                        new TimedTransition(100, "Wave 7 Check")
                    ),
                    new State("Wave 7 Check",
                        new SetDisplayName("c::10"),
                        new NoEnemiesWithinTransition(100, "Wave 8 Start"),
                        new TimedTransition(10000, "Wave 8 Start")
                    ),
                    new State("Wave 8 Start",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 8 Taunt")
                    ),
                    new State("Wave 8 Taunt",
                        new Taunt(true, "Boss wave coming in a few seconds!"),
                        new TimedTransition(0, "Wave 8 anim")
                    ),
                    new State("Wave 8 anim",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 8 Spawn")
                    ),
                    new State("Wave 8 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 8"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 8"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 8"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 8"),
                        new TimedTransition(100, "Wave 8 Check")
                    ),
                    new State("Wave 8 Check",
                        new SetDisplayName("c::30"),
                        new NoEnemiesWithinTransition(100, "Wave 9 Start"),
                        new TimedTransition(30000, "Wave 9 Start")
                    ),
                    new State("Wave 9 Start",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 9 Taunt")
                    ),
                    new State("Wave 9 Taunt",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "Wave 9 anim")
                    ),
                    new State("Wave 9 anim",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 9 Spawn")
                    ),
                    new State("Wave 9 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 9"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 9"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 9"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 9"),
                        new TimedTransition(100, "Wave 9 Check")
                    ),
                    new State("Wave 9 Check",
                        new SetDisplayName("c::15"),
                        new NoEnemiesWithinTransition(100, "Wave 10 Start"),
                        new TimedTransition(15000, "Wave 10 Start")
                    ),
                    new State("Wave 10 Start",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 10 Taunt")
                    ),
                    new State("Wave 10 Taunt",
                        new Taunt(true, "Next wave coming in a few seconds!"),
                        new TimedTransition(0, "Wave 10 anim")
                    ),
                    new State("Wave 10 anim",
                        new SetDisplayName(),
                        new SetAltTexture(3, 4, 150, true),
                        new TimedTransition(3000, "Wave 10 Spawn")
                    ),
                    new State("Wave 10 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 10"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 10"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 10"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 10"),
                        new TimedTransition(100, "Wave 10 Check")
                    ),
                    new State("Wave 10 Check",
                        new NoEnemiesWithinTransition(100, "Wave 11 Spawn")
                    ),
                    new State("Wave 11 Spawn",
                        new SetAltTexture(0),
                        new OrderOnce(100, "Arena South Gate Spawner", "Stage 11"),
                        new OrderOnce(100, "Arena West Gate Spawner", "Stage 11"),
                        new OrderOnce(100, "Arena East Gate Spawner", "Stage 11"),
                        new OrderOnce(100, "Arena North Gate Spawner", "Stage 11")
                    ),
                    new State("Morph",
                        new Transform("Ghost of Skuld")
                    )
                )
            )
            .Init("Arena South Gate Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("Leech"
                    ),
                    new State("Stage 1",
                        new Spawn("Arena Skeleton", maxChildren: 2)
                    ),
                    new State("Stage 2",
                        new Spawn("Arena Skeleton", maxChildren: 2)
                    ),
                    new State("Stage 3",
                        new Spawn("Troll 1", maxChildren: 1)
                    ),
                    new State("Stage 4"
                    ),
                    new State("Stage 5"
                    ),
                    new State("Stage 6",
                        new Spawn("Arena Risen Brawler", maxChildren: 1),
                        new Spawn("Arena Risen Archer", maxChildren: 1)
                    ),
                    new State("Stage 7",
                        new Spawn("Arena Risen Warrior", maxChildren: 2)
                    ),
                    new State("Stage 8"
                    ),
                    new State("Stage 9",
                        new Spawn("Zombie Hulk", maxChildren: 1)
                    ),
                    new State("Stage 10",
                        new Spawn("Werewolf", maxChildren: 1),
                        new Spawn("Zombie Hulk", maxChildren: 2)
                    ),
                    new State("Stage 11",
                        new Decay(100)
                    )
                )
            )
            .Init("Arena East Gate Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("Leech"
                    ),
                    new State("Stage 1",
                        new Spawn("Arena Skeleton", maxChildren: 1)
                    ),
                    new State("Stage 2",
                        new Spawn("Arena Skeleton", maxChildren: 2)
                    ),
                    new State("Stage 3",
                        new Spawn("Arena Ghost 1", maxChildren: 1),
                        new Spawn("Troll 2", maxChildren: 1)
                    ),
                    new State("Stage 4"
                    ),
                    new State("Stage 5"
                    ),
                    new State("Stage 6",
                        new Spawn("Arena Risen Brawler", maxChildren: 2)
                    ),
                    new State("Stage 7",
                        new Spawn("Arena Risen Mage", maxChildren: 1)
                    ),
                    new State("Stage 8"
                    ),
                    new State("Stage 9",
                        new Spawn("Classic Ghost", maxChildren: 2)
                    ),
                    new State("Stage 10",
                        new Spawn("Classic Ghost", maxChildren: 3)
                    ),
                    new State("Stage 11",
                        new Decay(100)
                    )
                )
            )
            .Init("Arena West Gate Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("Leech"
                    ),
                    new State("Stage 1",
                        new Spawn("Arena Skeleton", maxChildren: 1)
                    ),
                    new State("Stage 2",
                        new Spawn("Arena Skeleton", maxChildren: 2)
                    ),
                    new State("Stage 3",
                        new Spawn("Arena Ghost 2", maxChildren: 1),
                        new Spawn("Troll 2", maxChildren: 1)
                    ),
                    new State("Stage 4"
                    ),
                    new State("Stage 5"
                    ),
                    new State("Stage 6",
                        new Spawn("Arena Risen Archer", maxChildren: 1)
                    ),
                    new State("Stage 7",
                        new Spawn("Arena Risen Warrior", maxChildren: 1)
                    ),
                    new State("Stage 8"
                    ),
                    new State("Stage 9",
                        new Spawn("Classic Ghost", maxChildren: 3)
                    ),
                    new State("Stage 10",
                        new Spawn("Classic Ghost", maxChildren: 2)
                    ),
                    new State("Stage 11",
                        new Decay(100)
                    )
                )
            )
            .Init("Arena North Gate Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("Leech"
                    ),
                    new State("Stage 1",
                        new Spawn("Arena Skeleton", maxChildren: 1)
                    ),
                    new State("Stage 2",
                        new Spawn("Troll 1", maxChildren: 1)
                    ),
                    new State("Stage 3",
                        new Spawn("Arena Possessed Girl", maxChildren: 1)
                    ),
                    new State("Stage 4",
                        new Spawn("Troll 3", maxChildren: 1)
                    ),
                    new State("Stage 5",
                        new Spawn("Arena Ghost Bride", maxChildren: 1)
                    ),
                    new State("Stage 6",
                        new Spawn("Arena Risen Archer", maxChildren: 1)
                    ),
                    new State("Stage 7",
                        new Spawn("Arena Risen Archer", maxChildren: 2)
                    ),
                    new State("Stage 8",
                        new Spawn("Arena Grave Caretaker", maxChildren: 1)
                    ),
                    new State("Stage 9",
                        new Spawn("Zombie Hulk", maxChildren: 1)
                    ),
                    new State("Stage 10",
                        new Spawn("Werewolf", maxChildren: 1),
                        new Spawn("Zombie Hulk", maxChildren: 2)
                    ),
                    new State("Stage 11",
                        new OrderOnce(100, "Area 1 Controller", "Morph"),
                        new Decay(100)
                    )
                )
            )
            .Init("Arena Skeleton",
                new State(
                    new Prioritize(
                        new Follow(speed: 0.5, acquireRange: 8, range: 2, duration: 2000, coolDown: 3500),
                        new Wander(speed: 0.5)
                    ),
                    new Shoot(radius: 8, count: 1, projectileIndex: 0, coolDown: 800)
                )
            )
            .Init("Troll 1",
                new State(
                    new HPScale(35),
                    new Prioritize(
                        new Charge(speed: 1.1, range: 8, coolDown: 3000),
                        new Follow(speed: 0.5, acquireRange: 15, range: 2, duration: 4000, coolDown: 2000)
                    ),
                    new Shoot(radius: 5, count: 1, projectileIndex: 0, coolDown: 1000)
                )
            )
            .Init("Troll 2",
                new State(
                    new HPScale(35),
                    new Orbit(speed: 0.5, radius: 5, acquireRange: 10, target: null),
                    new Prioritize(
                        new Follow(speed: 1.1, acquireRange: 15, range: 6, duration: 4000, coolDown: 5000)
                    ),
                    new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 1, coolDown: 1600),
                    new Grenade(radius: 3, range: 6, damage: 85, coolDown: 2000)
                )
            )
            .Init("Troll 3",
                new State(
                    new HPScale(35),
                    new State("Ini",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ConditionalEffect(ConditionEffectIndex.StunImmune),
                        new ConditionalEffect(ConditionEffectIndex.SlowedImmune),
                        new ConditionalEffect(ConditionEffectIndex.ParalyzeImmune),
                        new State("Check1",
                            new EntityExistsTransition(target: "Area 1 Controller", dist: 999, targetState: "2")
                        ),
                        new State("2",
                            new MoveTo(speed: 0.9f, x: 21f, y: 21f)
                        ),
                        new Taunt("This forest will be your tomb!"),
                        new TossObject(child: "Arena Mushroom", range: 7, coolDown: 3000, throwEffect: true),
                        new TimedTransition(time: 2000, targetState: "Normal")
                    ),
                    new State("Normal",
                        new Prioritize(
                            new Wander(speed: 0.3)
                        ),
                        new Follow(speed: 0.6, acquireRange: 10, range: 3, duration: 5000, coolDown: 5500),
                        new Shoot(radius: 8, count: 1, projectileIndex: 0, coolDown: 1000),
                        new Shoot(radius: 24, count: 6, shootAngle: 60, projectileIndex: 1, fixedAngle: 30,
                            coolDown: 2000),
                        new TossObject(child: "Arena Mushroom", range: 7, coolDown: 3000, throwEffect: true),
                        new HpLessTransition(threshold: 0.7, targetState: "Summon")
                    ),
                    new State("Summon",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("I call upon the aid of warriors past! Smite these trespassers!"),
                        new Spawn(children: "Arena Skeleton", maxChildren: 5, coolDown: 4000),
                        new Shoot(radius: 24, count: 6, shootAngle: 60, projectileIndex: 1, fixedAngle: 0,
                            coolDown: 1500),
                        new Shoot(radius: 24, count: 6, shootAngle: 60, projectileIndex: 1, fixedAngle: 30,
                            coolDown: 1500),
                        new TossObject(child: "Arena Mushroom", range: 7, coolDown: 3000, throwEffect: true),
                        new EntitiesNotExistsTransition(99, "Enrage", "Arena Skeleton")
                    ),
                    new State("Enrage",
                        new Flash(color: 0xFFFFFF, flashPeriod: 0.1, flashRepeats: 15),
                        new ChangeSize(rate: 1, target: 200),
                        new Follow(speed: 1.1, acquireRange: 10, range: 3, duration: 5000, coolDown: 5500),
                        new Charge(speed: 1.3, range: 7, coolDown: 3000),
                        new Shoot(radius: 24, count: 6, shootAngle: 60, projectileIndex: 1, fixedAngle: 0,
                            coolDown: 900),
                        new TossObject(child: "Arena Mushroom", range: 7, coolDown: 1500, throwEffect: true),
                        new TimedTransition(time: 15000, targetState: "Normal 2")
                    ),
                    new State("Normal 2",
                        new Wander(speed: 0.3),
                        new ChangeSize(rate: 1, target: 150),
                        new Follow(speed: 1.1, acquireRange: 10, range: 3, duration: 5000, coolDown: 5500),
                        new TossObject(child: "Arena Mushroom", range: 7, coolDown: 3000, throwEffect: true),
                        new Shoot(radius: 8, count: 1, projectileIndex: 0, coolDown: 1000),
                        new HpLessTransition(threshold: 0.4, targetState: "Summon")
                    )
                ),
                new Threshold(0.01,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.01,
                    new ItemLoot("Speed Fragment", 0.005),
                    new ItemLoot("Wisdom Fragment", 0.005),
                    new ItemLoot("Potion of Speed", 0.8),
                    new ItemLoot("Potion of Wisdom", 0.8),
                    new ItemLoot("Potion Tablet", .5),
                    new ItemLoot("Undead Necklace", 0.02)
                )
            )
            .Init("Arena Mushroom",
                new State(
                    new State("Ini",
                        new PlayerWithinTransition(dist: 3, targetState: "A1", seeInvis: true)
                    ),
                    new State("A1",
                        new TimedTransition(time: 750, targetState: "A2")
                    ),
                    new State("A2",
                        new SetAltTexture(1),
                        new TimedTransition(time: 750, targetState: "A3")
                    ),
                    new State("A3",
                        new SetAltTexture(2),
                        new TimedTransition(time: 1000, targetState: "Explode")
                    ),
                    new State("Explode",
                        new Flash(color: 0xFFFFFF, flashPeriod: 0.1, flashRepeats: 30),
                        new TimedTransition(time: 3000, targetState: "Suicide")
                    ),
                    new State("Suicide",
                        new Shoot(radius: 24, count: 6, shootAngle: 60, fixedAngle: 30),
                        new Suicide()
                    )
                )
            );

    }
}
