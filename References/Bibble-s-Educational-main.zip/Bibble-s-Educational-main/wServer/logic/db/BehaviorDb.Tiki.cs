﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Tiki = () => Behav()
        .Init("King Totem",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new PlayerWithinTransition(20, "begin")
                        ),
                    new State("begin",
                        new Shoot(10, fixedAngle: 0, count: 6, shootAngle: 60, coolDownOffset: 200, coolDown: 1000, projectileIndex: 0),
                        new Shoot(10, fixedAngle: 20, count: 6, shootAngle: 60, coolDownOffset: 400, coolDown: 1000, projectileIndex: 0),
                        new Shoot(10, count: 4, shootAngle: 15, coolDown: 750, projectileIndex: 2),
                        new HpLessTransition(0.5, "up")
                        ),
                    new State("up",
                        new Shoot(10, fixedAngle: 0, count: 6, shootAngle: 60, coolDown: 750, projectileIndex: 0),
                        new Shoot(10, count: 6, shootAngle: 20, coolDown: 1000, projectileIndex: 1),
                        new HpLessTransition(0.25, "rage")
                        ),
                     new State("rage",
                         new Shoot(10, fixedAngle: 0, count: 12, shootAngle: 30, coolDown: 750, projectileIndex: 0),
                        new Shoot(10, count: 6, shootAngle: 25, coolDown: 1000, projectileIndex: 2),
                        new Shoot(10, count: 3, shootAngle: 15, coolDown: 1500, projectileIndex: 1)
                        )
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.03,
                    new ItemLoot("Longbow of The Island", 0.005),
                    new ItemLoot("Tropical Javelin", 0.005)
                ),
            new Threshold(0.01,
                    new ItemLoot("Attack Fragment", 0.1),
                    new ItemLoot("Tiki's Torch", 0.02),
                    new ItemLoot("Tiki Key", 0.0015),
                    new ItemLoot("Tropical Tonic", 0.02),
                    new ItemLoot("Potion of Attack", 1),
                    new ItemLoot("Potion Tablet", 0.05)
                )
            )
        .Init("TK Green Totem",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(20, "blink")
                        ),
                     new State("blink",
                         new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(5000, "begin")
                        ),
                    new State("begin",
                        new Shoot(10, count: 3, shootAngle: 25, coolDown: 1000, projectileIndex: 2),
                        new Shoot(10, count: 20, shootAngle: 18, coolDown: 1500, projectileIndex: 0),
                        new HpLessTransition(0.5, "up")
                        ),
                    new State("up",
                        new Shoot(10, count: 5, shootAngle: 25, coolDown: 750, projectileIndex: 1),
                        new Shoot(10, count: 8, shootAngle: 45, coolDown: 1275, projectileIndex: 2),
                        new HpLessTransition(0.25, "rage")
                        ),
                     new State("rage",
                         new Shoot(10, count: 20, shootAngle: 18, coolDown: 750, projectileIndex: 0),
                         new Shoot(10, count: 3, shootAngle: 25, coolDown: 500, projectileIndex: 2)
                        )
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.03,
                    new ItemLoot("Longbow of The Island", 0.00167),
                    new ItemLoot("Tropical Javelin", 0.00167)
                ),
            new Threshold(0.005,
                    new ItemLoot("Wisdom Fragment", 0.1),
                    new ItemLoot("Indigenous Falchion", 0.00666666667),
                    new ItemLoot("Tiki Key", 0.0015),
                    new ItemLoot("Jungle's Shiv", 0.00666666667),
                    new ItemLoot("Ceremonial Shroud", 0.00666666667),
                    new ItemLoot("Potion of Wisdom", 1),
                    new ItemLoot("Potion Tablet", 0.05)
                )
            )
        .Init("TK Yellow Totem",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(20, "begin")
                        ),
                    new State("begin",
                        new Shoot(10, count: 7, shootAngle: 25, coolDown: 1000, projectileIndex: 1),
                        new Grenade(10, 100, coolDown: 1500, color: 0xff9090),
                        new HpLessTransition(0.5, "up")
                        ),
                    new State("up",
                        new Shoot(10, count: 8, shootAngle: 45, coolDown: 1000, projectileIndex: 0),
                        new Shoot(10, count: 7, shootAngle: 10, coolDown: 1250, projectileIndex: 1),
                        new HpLessTransition(0.25, "rage")
                        ),
                     new State("rage",
                         new Shoot(10, count: 20, shootAngle: 18, coolDown: 750, projectileIndex: 0),
                         new Shoot(10, count: 3, shootAngle: 15, coolDown: 1250, projectileIndex: 1)
                        )
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.03,
                    new ItemLoot("Longbow of The Island", 0.00167),
                    new ItemLoot("Tropical Javelin", 0.00167)
                ),
            new Threshold(0.005,
                    new ItemLoot("Dexterity Fragment", 0.1),
                    new ItemLoot("Indigenous Falchion", 0.00666666667),
                    new ItemLoot("Jungle's Shiv", 0.00666666667),
                    new ItemLoot("Tiki Key", 0.0015),
                    new ItemLoot("Ceremonial Shroud", 0.00666666667),
                    new ItemLoot("Potion of Dexterity", 1),
                    new ItemLoot("Potion Tablet", 0.05)
                )
            )
        .Init("TK Minion Yellow",
                new State(
                    new State("attack",
                        new Orbit(1.0, 3, acquireRange: 10, target: "TK Mini Yellow"),
                        new Shoot(10, count: 2, shootAngle: 7, coolDown: 1500, projectileIndex: 0)
                        )
                    )
            )
        .Init("TK Minion Green",
                new State(
                    new State("attack",
                        new Orbit(1.0, 3, acquireRange: 10, target: "TK Mini Green"),
                        new Shoot(10, count: 3, shootAngle: 5, coolDown: 2000, projectileIndex: 0)
                        )
                    )
            )
        .Init("TK Wandering Spirit",
                new State(
                    new State("attack",
                        new Wander(0.4),
                        new RingAttack(30, 12, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 1500),
                        new HpLessTransition(0.50, "wait")
                        ),
                    new State("wait",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TimedTransition(3000, "attack2")
                        ),
                    new State("attack2",
                        new Follow(1.0, 12, 0),
                        new RingAttack(30, 12, 0, projectileIndex: 0, 0.2, 0.2, coolDown: 250)
                        )
                    )
            )
        .Init("TK Minion Blue",
                new State(
                    new State("attack",
                        new Orbit(1.0, 3, acquireRange: 10, target: "TK Mini Blue"),
                        new Shoot(10, count: 1, shootAngle: 0, coolDown: 2500, projectileIndex: 0)
                        )
                    )
            )
            .Init("TK Mini Yellow",
                new State(
                    new State("wait",
                        new PlayerWithinTransition(10, "active")
                        ),
                    new State("active",
                        new TimedTransition(1500, "attack")
                        ),
                    new State("attack",
                        new Grenade(2.0, 150, range: 8, color: 0xff0000, coolDown: 2000)
                        )
                    )
            )
        .Init("TK TRoom",
                new State(
                    new HPScale(30),
                    new State("wait",
                        new Grenade(4.0, 300, range: 12, color: 0xff0000, coolDown: 3000)
                        )
                   ),
            new Threshold(0.01,
                    new ItemLoot("Tiki's Torch", 0.00666666667),
                    new ItemLoot("Tropical Tonic", 0.00666666667),
                    new ItemLoot("Tropical Javelin", 0.00167),
                    new ItemLoot("Longbow of The Island", 0.00167),
                    new ItemLoot("Tiki Key", 0.0015),
                    new ItemLoot("Indigenous Falchion", 0.00666666667),
                    new ItemLoot("Jungle's Shiv", 0.00666666667),
                    new ItemLoot("Ceremonial Shroud", 0.00666666667),
                    new ItemLoot("Potion of Attack", 0.5),
                    new ItemLoot("Potion of Wisdom", 0.5),
                    new ItemLoot("Potion of Dexterity", 0.5),
                    new TierLoot(10, ItemType.Weapon, 0.1),
                    new TierLoot(11, ItemType.Weapon, 0.1),
                    new TierLoot(9, ItemType.Armor, 0.1),
                    new TierLoot(10, ItemType.Armor, 0.1),
                    new TierLoot(11, ItemType.Armor, 0.1)
                )
            )
        .Init("TK Mini Green",
                new State(
                    new State("wait",
                        new PlayerWithinTransition(10, "active")
                        ),
                    new State("active",
                        new TimedTransition(1500, "attack")
                        ),
                    new State("attack",
                        new Shoot(10, count: 1, shootAngle: 0, coolDown: 2000, projectileIndex: 0)
                        )
                    )
            )
        .Init("TK Mini Blue",
                new State(
                    new State("wait",
                        new PlayerWithinTransition(10, "active")
                        ),
                    new State("active",
                        new TimedTransition(1500, "attack")
                        ),
                    new State("attack",
                        new RingAttack(20, 4, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 100, seeInvis: true),
                        new TimedTransition(2000, "wait")
                        ),
                    new State("wait",
                        new TimedTransition(3000, "attack")
                        )
                    )
            );
    }
}
