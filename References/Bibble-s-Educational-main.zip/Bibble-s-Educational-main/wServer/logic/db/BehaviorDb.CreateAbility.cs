﻿using common.resources;
using System.Runtime.CompilerServices;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using wServer.realm.entities;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ CreateAbils = () => Behav()
        .Init("Flower Blossom Heal",
             new State(
                  new State("Idle",
                      new HealPlayer(4, 500, 12),
                      new TimedTransition(5000, "die")
                  ),
             new State("die", new Decay(0))
             )
        )
        .Init("Seaweed Banner",
             new State(
                  new State("Idle",
                      new Grenade(4, 0, range: 0, fixedAngle: 0, effect: ConditionEffectIndex.Energized, effectDuration: 1200, color: 0x1cbcdc, coolDown: 1000),
                      new Grenade(4, 0, range: 0, fixedAngle: 0, effect: ConditionEffectIndex.Healing, effectDuration: 1200, color: 0x1cbcdc, coolDown: 1000),
                      new TimedTransition(4000, "die")
                  ),
             new State("die", new Decay(0))
             )
        )
        .Init("Oryx War Banner",
             new State(
                  new State("Idle",
                      new Grenade(4, 0, range: 0, fixedAngle: 0, effect: ConditionEffectIndex.Berserk, effectDuration: 1200, color: 0x952323, coolDown: 1000),
                      new TimedTransition(5000, "die")
                  ),
             new State("die", new Decay(0))
             )
        )
        .Init("Health Orbit",
            new State(
                new State("Idle",
                    new HealPlayer(4, 500, 50),
                    new Orbit(4.0, 5.0),
                    new TimedTransition(5000, "die")
                    ),
                new State("die", new Decay(0))
                )
            )
        .Init("Mini Rogue",
            new State(
                new State("Idle",
                    new Charge(coolDown: new Cooldown(300, 0), targetPlayers: false, callback: (host, time, player, state) =>
                    {
                        Enemy enem = player as Enemy;
                        Player p = host.GetPlayerOwner();
                        if (p == null) return;
                        enem.Damage(p, time, 100 * (((p.Stats[2] + p.Stats[5]) / 2) / 10), true);
                    }),
                    new TimedTransition(5000, "die")
                    ),
                new State("die", new Decay(0))
        ));

        private _ JerryCharge = () => Behav()
        .Init("Jerry Ally Minion",
             new State(
                  new State("Idle",
                      new Charge(coolDown: new Cooldown(300, 0), targetPlayers: false, callback: (host, time, player, state) =>
                      {

                          Enemy enem = player as Enemy;
                          Player p = host.GetPlayerOwner();
                          if (p == null) return;
                          enem.Damage(p, time, 500, true);
                          host.Move(p.Position);

                      }),
                      new TimedTransition(5000, "die")
                  ),
             new State("die", new Decay(0))
             )
        );
    }
}