﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Aztec = () => Behav()

        .Init("Gaia",
            new State(
                new HPScale(30),
                new State("Exist",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(8, "Dialogue I")
                    ),
                new State("Dialogue I",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Hmm? Humans found their way into my hideout?"),
                    new TimedTransition(2500, "Dialogue II")
                    ),
                new State("Dialogue II",
                    new Wander(0.2),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Time to squash some ants.."),
                    new Flash(0xff0000, 0.5f, 1),
                    new TimedTransition(2500, "Intro")
                    ),
                new State("Intro",
                    new ReturnToSpawn(1, 0),
                    new RemoveConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Shoot(10, 3, 15, 2, coolDown: 2000),
                    new Shoot(10, 1, 0, 1,  coolDown: 2000),
                    new Shoot(10, 4, 90, 0, 0, coolDown: 1000),
                    new Shoot(10, 4, 90, 0, 9, coolDown: 1000, coolDownOffset: 100),
                    new Shoot(10, 4, 90, 0, 18, coolDown: 1000, coolDownOffset: 200),
                    new Shoot(10, 4, 90, 0, 27, coolDown: 1000, coolDownOffset: 300),
                    new Shoot(10, 4, 90, 0, 36, coolDown: 1000, coolDownOffset: 400),
                    new Shoot(10, 4, 90, 0, 45, coolDown: 1000, coolDownOffset: 500),
                    new Shoot(10, 4, 90, 0, 54, coolDown: 1000, coolDownOffset: 600),
                    new Shoot(10, 4, 90, 0, 63, coolDown: 1000, coolDownOffset: 700),
                    new Shoot(10, 4, 90, 0, 72, coolDown: 1000, coolDownOffset: 800),
                    new Shoot(10, 4, 90, 0, 81, coolDown: 1000, coolDownOffset: 900),
                    new HpLessTransition(0.66, "Dialogue III")
                    ),
                new State("Dialogue III",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Enough going easy, Let's see how you fare when I start moving!"),
                    new TimedTransition(2000, "Provoked")
                    ),
                new State("Provoked",
                    new Follow(1, 10, 0.5, 0, 0),
                    new RemoveConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Shoot(10, 1, 0, 1, coolDown: 2000),
                    new Shoot(10, 2, 15, 1, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(10, 3, 20, 1, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(10, 4, 15, 2, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(10, 9, 40, 0, 0, coolDown: 4000),
                    new Shoot(10, 9, 40, 0, 20, coolDown: 4000, coolDownOffset: 200),
                    new HpLessTransition(0.33, "Dialogue IV")
                    ),
                new State("Dialogue IV",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new ReturnToSpawn(1.5, 0),
                    new Taunt("Calm down you barbarians!"),
                    new TimedTransition(3000, "Dialogue V")
                    ),
                new State("Dialogue V",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Let's make a deal, I give you some treasure, and you leave my hideout."),
                    new TimedTransition(3000, "Dialogue VI")
                    ),
                new State("Dialogue VI",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Just give me a second. Alright, and..."),
                    new TimedTransition(2000, "Decoy")
                    ),
                new State("Decoy",
                    new Wander(0.3),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Spawn("Aztec Quest Chest", 1, 1),
                    new Taunt("There!"),
                    new TimedTransition(500, "Hold")
                    ),
                new State("Hold",
                    new Wander(0.3),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new EntityNotExistsTransition("Aztec Quest Chest", 15, "Fucked")
                    ),
                new State("Fucked",
                    new ChangeSize(20, 160),
                    new Follow(1, 10, 2, 0, 0),
                    new Flash(0xff0000, 1f, 2),
                    new Taunt("DIE!"),
                    new Shoot(10, 2, 8, 0, coolDown: 200),
                    new Shoot(10, 10, 36, 2, coolDown: 2000)
                    )
                ),
                new Threshold(0.001,
                    LootTemplates.StrongerDrop()
                    ),
                    new Threshold(0.0001,
                        new ItemLoot("Attack Fragment", 0.1),
                        new ItemLoot("Wisdom Fragment", 0.1),
                        new ItemLoot("Greater Potion of Attack", 1),
                        new ItemLoot("Greater Potion of Wisdom", 1),
                        new ItemLoot("Potion Tablet", 1),
                        new ItemLoot("Tiki Key", 0.008),
                        new ItemLoot("Leafly Hide", 0.02),
                        new ItemLoot("Totem's Resonance", 0.02),
                        new ItemLoot("Ring of Roots", 0.02),
                        new ItemLoot("Shard of Divinity", 0.0025),
                        new ItemLoot("Support Fragment", 0.25)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Lively Sapling", 0.02),
                    new ItemLoot("Call of the Jungle", 0.005),
                    new ItemLoot("Tribesman's Wield", 0.005),
                    new ItemLoot("Greater Potion of Life", 0.5),
                    new ItemLoot("Greater Potion of Mana", 0.5)
                    )
            )

        .Init("Aztec Quest Chest",
            new State(
                new HPScale(30),
                new State("Shield",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable, false, 3000),
                    new HpLessTransition(0.1, "Fucked")
                    ),
                new State("Fucked",
                    new Spawn("Aztec Tribe General", 2, 2),
                    new Spawn("Aztec Orangutan", 2, 2),
                    new Decay(250)
                    )
                )
            )

        .Init("Aztec Tribe General",
            new State(
                new State("Offense",
                    new Follow(0.2, 10, 2, 0, 0),
                    new Shoot(10, 2, 45, 0, coolDown: 5000, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 3, explodeAngle: 120),
                    new Shoot(10, 2, 0, 1, coolDown: 2000),
                    new Shoot(10, 2, 0, 1, coolDown: 2000, coolDownOffset: 300)
                    // new TimedTransition(~ ~, "Charge") maybe..?
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            )

        .Init("Aztec Tribe Mage",
            new State(
                new State("Offense",
                    new Follow(0.1, 10, 2, 0, 0),
                    new Shoot(10, 2, 0, 1, coolDown: 2000),
                    new Shoot(10, 2, 0, 1, coolDown: 2000, coolDownOffset: 333),
                    new Shoot(10, 2, 0, 1, coolDown: 2000, coolDownOffset: 666),
                    new TimedTransition(6000, "Shield")
                    ),
                new State("Shield",
                    new Wander(0.2),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable, false, 5000),
                    new Shoot(10, 10, 36, 0, coolDown: 2500),
                    new TimedTransition(5000, "Offense")
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.05)
                    )
            )

        .Init("Aztec Tribe Sorcerer",
            new State(
                new State("Offense",
                    new Follow(0.3, 10, 2, 0, 0),
                    new Shoot(10, 2, 0, 0, coolDown: 2000),
                    new Shoot(10, 2, 0, 0, coolDown: 2000, coolDownOffset: 333),
                    new Shoot(10, 2, 0, 0, coolDown: 2000, coolDownOffset: 666),
                    new TimedTransition(4000, "Vulnerable")
                    ),
                new State("Vulnerable",
                    new Wander(0.2),
                    new Shoot(10, 5, 15, 1, coolDown: 1500),
                    new TimedTransition(4500, "Offense")
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.05)
                    )
            )

        .Init("Aztec Orangutan",
            new State(
                new State("Charge",
                    new Follow(1, 10, 2, 0, 0),
                    new Shoot(10, 1, 0, 0, coolDown: 2000),
                    new Shoot(10, 5, 12, 1, coolDown: 2000, coolDownOffset: 300)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            )

        .Init("Aztec Piranha Plant",
            new State(
                new State("Offense",
                    new Shoot(10, 12, 30, 0, 0, coolDown: 2000),
                    new Shoot(10, 12, 30, 0, 0, coolDown: 2000, coolDownOffset: 300),
                    new TimedTransition(4000, "Charge")
                    ),
                new State("Charge",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable, false, 3000),
                    new Flash(0xff0000, 1, 2),
                    new TimedTransition(3000, "Offense")
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.05)
                    )
            )

        .Init("Aztec Jungle Snake",
            new State(
                new State("Lurk",
                    new Wander(0.3),
                    new ConditionalEffect(ConditionEffectIndex.Armored, false, 3000),
                    new TimedTransition(3000, "Charge")
                    ),
                new State("Charge",
                    new Follow(0.8, 10, 2, 0, 0),
                    new Flash(0xff0000, 1, 2),
                    new Shoot(10, 3, 15, 0, coolDown: 1500),
                    new TimedTransition(4500, "Lurk")
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.05)
                    )
            )

        .Init("Aztec Turret",
            new State(
                new State("Offense",
                    new Shoot(10, 2, 5, 0, coolDown: 3000),
                    new Shoot(10, 3, 15, 1, coolDown: 3000, coolDownOffset: 1000),
                    new TimedTransition(5000, "Shield")
                    ),
                new State("Shield",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable, false, 5000),
                    new Flash(0x00ff00, 1, 2),
                    new TimedTransition(5000, "Offense")
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            );

    }
}
