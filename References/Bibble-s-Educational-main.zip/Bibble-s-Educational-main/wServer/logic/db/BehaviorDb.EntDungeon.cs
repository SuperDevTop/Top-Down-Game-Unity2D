﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ EntDungeon = () => Behav()
            .Init("Ent Purple Flower",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3, range: 4),
                        new Wander(0.2)
                    ),
                    new Shoot(15, count: 12, shootAngle: 30, fixedAngle: 0, rotateAngle: 45, projectileIndex: 0, coolDown: 3000),
                    new Shoot(15, count: 12, shootAngle: 30, fixedAngle: 45, rotateAngle: 45, projectileIndex: 0, coolDown: 3000, coolDownOffset: 600),
                    new Shoot(15, count: 12, shootAngle: 30, fixedAngle: 90, rotateAngle: 45, projectileIndex: 0, coolDown: 3000, coolDownOffset: 1200)
                )
            )
        .Init("Ent Light Flower",
                new State(
                    new State("Walk",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Follow(0.6, 14, 0),
                        new TimedTransition(5000, "Fire")
                    ),
                    new State("Fire",
                        new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, coolDown: 200),
                        new TimedTransition(1900, "Hittable")
                    ),
                    new State("Hittable",
                        new ConditionalEffect(ConditionEffectIndex.ArmorBroken),
                        new TimedTransition(2500, "Walk")
                    )
                )
            )
        .Init("Ent Skinny Ent",
                new State(
                    new State("Normal",
                        new Follow(0.4, 14, 0),
                        new RingAttack(20, 2, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 180, seeInvis: true),
                        new TimedTransition(4000, "Big")
                    ),
                    new State("Big",
                        new Shoot(15, count: 5, shootAngle: 9, fixedAngle: 0, rotateAngle: 45, projectileIndex: 0, coolDown: 1900),
                        new Shoot(15, count: 5, shootAngle: 9, fixedAngle: 90, rotateAngle: 45, projectileIndex: 0, coolDown: 1900),
                        new Shoot(15, count: 5, shootAngle: 9, fixedAngle: 180, rotateAngle: 45, projectileIndex: 0, coolDown: 1900),
                        new Shoot(15, count: 5, shootAngle: 9, fixedAngle: 270, rotateAngle: 45, projectileIndex: 0, coolDown: 1900),
                        new TimedTransition(4000, "Normal")
                    )
                )
            )
        .Init("Ent Little Ent",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.25, range: 6),
                        new Wander(0.15)
                    ),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 1200),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 1200, coolDownOffset: 150),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 1200, coolDownOffset: 300)
                )
            );
    }
}
