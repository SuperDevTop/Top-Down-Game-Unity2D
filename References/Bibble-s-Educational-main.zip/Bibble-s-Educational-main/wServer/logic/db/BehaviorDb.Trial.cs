﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.transitions;
using wServer.logic.loot;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Trial = () => Behav()
            .Init("Artifical Lifeform",
                new State(
                    new AllowFragmentsOnDeath(),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(6, "Wait1")
                        ),
                    new State("Wait1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(45, "Trials Invis Barrier", "Transform"),
                        new TimedTransition(2500, "Talk1")
                        ),
                    new State("Talk1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Activate Hero Testing Mode."),
                        new TimedTransition(3500, "Talk2")
                        ),
                    new State("Talk2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Phase One Start."),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Quiet, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new TimedTransition(4500, "attack")
                        ),
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(30, 8, 0, projectileIndex: 0, 0.35, 0.35, coolDown: 300, seeInvis: true),
                        new RingAttack(30, 16, 0, projectileIndex: 2, 0.35, 0.35, coolDown: 1500, seeInvis: true),
                        new Shoot(15, count: 3, shootAngle: 8, coolDown: 500, projectileIndex: 1),
                        new Grenade(2.0, 325, range: 14, effect: ConditionEffectIndex.Confused, effectDuration: 1000, color: 0xffee59, coolDown: 3000),
                        new TimedTransition(25000, "Transition1")
                        ),
                    new State("Transition1",
                        new Taunt("Attack me now hero."),
                        new HealPlayer(20, 1000),
                        new HpLessTransition(0.80, "Talk3")
                        ),
                    new State("Talk3",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Phase Two Start."),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Quiet, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new TimedTransition(4500, "attack2")
                        ),
                    new State("attack2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(30, 3, 0, projectileIndex: 2, 0.25, 0.25, coolDown: 70, seeInvis: true),
                        new RingAttack(30, 6, 0, projectileIndex: 1, 0.40, 0.40, coolDown: 500, seeInvis: true),
                        new Shoot(15, count: 3, shootAngle: 8, coolDown: 400, projectileIndex: 0),
                        new Shoot(15, count: 8, shootAngle: 45, projectileIndex: 3, coolDown: 4500, hasExplodingShots: true, explodeShotIndex: 4, explodeCount: 8, explodeAngle: 45),
                        new TimedTransition(25000, "Transition2")
                        ),
                    new State("Transition2",
                        new Taunt("Attack me now hero."),
                        new HealPlayer(20, 1000),
                        new HpLessTransition(0.60, "Talk4")
                        ),
                    new State("Talk4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Phase Three Start."),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Quiet, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new TimedTransition(4500, "attack3")
                        ),
                    new State("attack3",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(30, 3, 0, projectileIndex: 2, 0.20, 0.20, coolDown: 70, seeInvis: true),
                        new RingAttack(30, 3, 0, projectileIndex: 2, -0.25, -0.25, coolDown: 70, seeInvis: true),
                        new RingAttack(30, 6, 0, projectileIndex: 1, 0.40, 0.40, coolDown: 750, seeInvis: true),
                        new Grenade(1.0, 150, range: 14, color: 0xffee59, coolDown: 350),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 3, coolDown: 1000, hasExplodingShots: true, explodeShotIndex: 4, explodeCount: 8, explodeAngle: 45),
                        new TimedTransition(25000, "Transition3")
                        ),
                    new State("Transition3",
                        new Taunt("Attack me now hero."),
                        new HealPlayer(20, 1000),
                        new HpLessTransition(0.40, "Talk5")
                        ),
                    new State("Talk5",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Phase Four Start."),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Quiet, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new TimedTransition(4500, "attack4")
                        ),
                    new State("attack4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(45, "Trial Tower", "Phase 4"),
                        new RingAttack(30, 8, 0, projectileIndex: 1, 0.14, 0.14, coolDown: 150, seeInvis: true),
                        new RingAttack(30, 16, 0, projectileIndex: 2, 0.35, 0.35, coolDown: 1500, seeInvis: true),
                        new RingAttack(20, 12, 0, projectileIndex: 5, 0.20, 0.2, coolDown: 5000, seeInvis: true),
                        new TimedTransition(25000, "Transition4")
                        ),
                    new State("Transition4",
                        new Taunt("Attack me now hero."),
                        new HealPlayer(20, 1000),
                        new HpLessTransition(0.20, "Talk6")
                        ),
                    new State("Talk6",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Phase Five Start."),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Sick, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new Grenade(25, 0, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Quiet, effectDuration: 31000, color: 0xc7ff00, coolDown: 5000),
                        new TimedTransition(4500, "attack5")
                        ),
                    new State("attack5",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(45, "Trial Tower", "Phase 5"),
                        new RingAttack(30, 3, 0, projectileIndex: 0, 0.80, 0.80, coolDown: 95, seeInvis: true),
                        new RingAttack(30, 4, 0, projectileIndex: 1, 1.20, 1.20, coolDown: 95, seeInvis: true),
                        new RingAttack(30, 5, 0, projectileIndex: 2, 1.60, 1.60, coolDown: 95, seeInvis: true),
                        new Shoot(15, count: 8, shootAngle: 45, projectileIndex: 3, coolDown: 4500, hasExplodingShots: true, explodeShotIndex: 0, explodeCount: 6, explodeAngle: 90),
                        new TimedTransition(25000, "Transition5")
                        ),
                    new State("Transition5",
                        new Taunt("Finish me off hero.")
                        )
                    ),
                new Threshold(0.01,
                        new ItemLoot("Lightning Strike Rune", 0.1)
                    )
                )
            .Init("Trials Invis Barrier",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TransformOnDeath("Trials Marble Wall"),
                        new Suicide()
                        )
                    )
                )
            .Init("Trial Tower",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                    new State("Phase 4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 1000, projectileIndex: 0)
                        ),
                    new State("Phase 5",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(3.5, 300, range: 0, fixedAngle: 36, color: 0xffee59, coolDown: 750)
                        )
                    )
                )
            .Init("Neius Hologram",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new State("idle",
                    new PlayerWithinTransition(4, "Greet")
                    ),
                new State("Greet",
                    new Taunt("Hello Hero!"),
                    new PlayerTextTransition("Skip", "skip"),
                    new TimedTransition(3500, "Talk")
                    ),
                new State("Talk",
                    new Taunt("I am Neius, the sixth god of light! Or well, a hologram of him."),
                    new PlayerTextTransition("Skip", "skip"),
                    new TimedTransition(6000, "Talk2")
                    ),
                new State("Talk2",
                    new Taunt("I made this area to test heroes, you know, to truly see if they are worthy of achieving the next level of strength!"),
                    new PlayerTextTransition("Skip", "skip"),
                    new TimedTransition(7000, "Talk3")
                    ),
                new State("Talk3",
                    new Taunt("Anyways, good luck hero! Oh, and remember, you can't die here, it's just a simulated environment."),
                    new PlayerTextTransition("Skip", "skip"),
                    new TimedTransition(6000, "DestroyWalls")
                    ),
                new State("Skip",
                    new Taunt("I see, you don't need information cause you've already passed this initial test."),
                    new TimedTransition(6000, "DestroyWalls")
                    ),
                new State("DestroyWalls",
                    new RemoveObjectOnDeath("Trials Marble Wall 2", 25),
                    new TransformOnDeath("Trials Invis Barrier"),
                    new Suicide()
                    )
                )
            );
    }
}