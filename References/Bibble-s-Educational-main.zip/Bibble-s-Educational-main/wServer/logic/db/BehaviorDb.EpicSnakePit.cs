﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ EpicSnakePit = () => Behav()
            .Init("Basilisk Warrior",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.2)
                    ),
                    new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 2500)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            )
        .Init("Basilisk Hatchling",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new RingAttack(30, 8, 0, projectileIndex: 0, 0, 0, coolDown: 4000)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.02)
                    )
            )
        .Init("Berserker Snakeling",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new Shoot(10, 1, 0, coolDown: 2000, projectileIndex: 0)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.02)
                    )
            )
        .Init("Mutated Serpent",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new Shoot(10, 1, 0, coolDown: 3000, projectileIndex: 0),
                    new Grenade(3, 125, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x3e5433, coolDown: 1500)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            )
        .Init("Winged Serpent",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.2)
                    ),
                    new State("attack",
                        new Shoot(10, 4, 90, coolDown: 3000, projectileIndex: 0),
                        new Shoot(10, 8, 15, coolDown: 2000, projectileIndex: 1)
                        )
                    ),
            new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            )
        .Init("The Hydra",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(12, "wait1")
                        ),
                    new State("wait1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("ROARRRRR"),
                        new TimedTransition(4000, "poisonstart")
                        ),
                    new State("poisonstart",
                        new Grenade(1.5, 150, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 1500, color: 0x66d01a, coolDown: 2000),
                        new RingAttack(30, 12, 0, projectileIndex: 1, 5, 25, coolDown: 2000),
                        new RingAttack(30, 14, 0, projectileIndex: 2, 10, 50, coolDown: 2500),
                        new RingAttack(30, 2, 0, projectileIndex: 0, 0.15, 0, coolDown: 200),
                        new RingAttack(30, 2, 0, projectileIndex: 0, 0.15, 10, coolDown: 200),
                        new RingAttack(30, 2, 0, projectileIndex: 0, 0.15, 20, coolDown: 200),
                        new HpLessTransition(0.82, "poisongrenade1")
                        ),
                    new State("poisongrenade1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 2, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade2")
                        ),
                    new State("poisongrenade2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 3, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade3")
                        ),
                    new State("poisongrenade3",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 4, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade4")
                        ),
                    new State("poisongrenade4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 5, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade5")
                        ),
                    new State("poisongrenade5",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 6, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade6")
                        ),
                    new State("poisongrenade6",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 7, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade7")
                        ),
                    new State("poisongrenade7",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 8, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade8")
                        ),
                    new State("poisongrenade8",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 9, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade9")
                        ),
                    new State("poisongrenade9",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 10, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(250, "poisongrenade10")
                        ),
                    new State("poisongrenade10",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 0, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 30, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 60, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 90, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 120, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 150, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 180, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 210, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 240, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 270, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 300, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 330, color: 0x66d01a, coolDown: 2000),
                        new Grenade(1.5, 200, range: 11, fixedAngle: 360, color: 0x66d01a, coolDown: 2000),
                        new TimedTransition(1000, "fire1")
                        ),
                    new State("fire1",
                        new SetAltTexture(1),
                        new TossObject("Hydra Poison Head", 5, angle: 0, coolDown: 900000, throwEffect: true),
                        new RingAttack(30, 1, 0, projectileIndex: 12, 0.25, 0, coolDown: 250),
                        new RingAttack(30, 1, 0, projectileIndex: 13, 0.25, 0, coolDown: 250),
                        new RingAttack(30, 1, 0, projectileIndex: 14, 0.25, 0, coolDown: 250),
                        new RingAttack(30, 1, 0, projectileIndex: 15, 0.25, 0, coolDown: 250),
                        new RingAttack(30, 1, 0, projectileIndex: 16, 0.25, 0, coolDown: 250),
                        new Shoot(15, count: 1, coolDown: 5000, projectileIndex: 3),
                        new Shoot(15, count: 2, shootAngle: 10, coolDown: 5000, projectileIndex: 4),
                        new Shoot(15, count: 2, shootAngle: 20, coolDown: 5000, projectileIndex: 5),
                        new Shoot(15, count: 2, shootAngle: 30, coolDown: 5000, projectileIndex: 6),
                        new Shoot(15, count: 2, shootAngle: 40, coolDown: 5000, projectileIndex: 7),
                        new Shoot(15, count: 2, shootAngle: 50, coolDown: 5000, projectileIndex: 8),
                        new Shoot(15, count: 2, shootAngle: 60, coolDown: 5000, projectileIndex: 9),
                        new Shoot(15, count: 2, shootAngle: 70, coolDown: 5000, projectileIndex: 10),
                        new Shoot(15, count: 2, shootAngle: 80, coolDown: 5000, projectileIndex: 11),
                        new HpLessTransition(0.56, "wind1")
                        ),
                    new State("wind1",
                        new SetAltTexture(2),
                        new TossObject("Hydra Fire Head", 5, angle: 180, coolDown: 900000, throwEffect: true),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 21, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 18, explodeCount: 8, explodeAngle: 45),
                        new RingAttack(30, 4, 0, projectileIndex: 17, 0.20, 0, coolDown: 200),
                        new HpLessTransition(0.25, "final")
                        ),
                    new State("final",
                        new SetAltTexture(3),
                        new TossObject("Hydra Wind Head", 5, angle: 90, coolDown: 900000, throwEffect: true),
                        new RingAttack(30, 2, 0, projectileIndex: 19, 0.15, 0, coolDown: 200),
                        new RingAttack(30, 2, 0, projectileIndex: 20, 0.25, 0, coolDown: 200),
                        new Grenade(2, 200, range: 10, color: 0x3e5433, coolDown: 4000)
                        )
                  ),
                new Threshold(0.001,
                    LootTemplates.StrongerDrop()
                    ),
                    new Threshold(0.0001,
                        new ItemLoot("Speed Fragment", 0.1),
                        new ItemLoot("Dexterity Fragment", 0.1),
                        new ItemLoot("Shard of Divinity", 0.0025),
                        new ItemLoot("Greater Potion of Dexterity", 1),
                        new ItemLoot("Greater Potion of Speed", 1),
                        new ItemLoot("Potion Tablet", 1),
                        new ItemLoot("Wand of the Bulwark", 0.005),
                        new ItemLoot("Book of Poisons", 0.02),
                        new ItemLoot("Slithering Robe", 0.02),
                        new ItemLoot("Snake Pit Key", 0.008),
                        new ItemLoot("Scalemail", 0.02),
                        new ItemLoot("Support Fragment", 0.25),
                        new ItemLoot("Slithering Ring", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Hydra's Tonic", 0.005),
                    new ItemLoot("Toxin Dagger", 0.005),
                    new ItemLoot("Greater Potion of Life", 0.5),
                    new ItemLoot("Greater Potion of Mana", 0.5)
                    )
            )
        .Init("Hydra Poison Head",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                        new Orbit(0.6, 4, 18, "The Hydra")
                    ),
                    new State("Basic",
                        new Grenade(1.5, 125, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 1000, color: 0x66d01a, coolDown: 1000),
                        new Shoot(15, count: 3, shootAngle: 5, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                        new EntityNotExistsTransition("The Hydra", 100, "decay")
                    ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                )
            )
        .Init("Hydra Fire Head",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                        new Orbit(0.8, 6, 18, "The Hydra")
                    ),
                    new State("Basic",
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 5000, projectileIndex: 0),
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 5000, projectileIndex: 1),
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 5000, projectileIndex: 2),
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 5000, projectileIndex: 3),
                        new Shoot(15, count: 1, shootAngle: 0, coolDown: 5000, projectileIndex: 4),
                        new EntityNotExistsTransition("The Hydra", 100, "decay")
                    ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                )
            )
        .Init("Hydra Wind Head",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                        new Orbit(1.2, 8, 18, "The Hydra")
                    ),
                    new State("Basic",
                        new RingAttack(30, 8, 0, projectileIndex: 0, 0.25, 0, coolDown: 8000),
                        new EntityNotExistsTransition("The Hydra", 100, "decay")
                    ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                )
            )
        .Init("Evolved Crossbow Trap L",
                new State(
                    new State("shoot",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Shoot(10, 1, 0, coolDown: 1500, fixedAngle: 180, projectileIndex: 0)
                        )
                    )
            )
        .Init("Evolved Crossbow Trap R",
                new State(
                    new State("shoot",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Shoot(10, 1, 0, coolDown: 1500, fixedAngle: 0, projectileIndex: 0)
                        )
                    )
            );
    }
}
