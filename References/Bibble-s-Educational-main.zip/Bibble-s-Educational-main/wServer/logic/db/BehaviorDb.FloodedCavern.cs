﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ FloodedCavern = () => Behav()
            .Init("Tropical Fish",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Orbit(0.2, 1, target: "Flooded Cavern Coral", acquireRange: 10, speedVariance: 0, radiusVariance: 0)
                )
            )
            .Init("Algae Worm",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new StayCloseToSpawn(0.3, range: 2),
                    new Wander(0.1)
                )
            )
            .Init("Cave Axolotl",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new StayCloseToSpawn(0.3, range: 2),
                    new Wander(0.1)
                )
            )
            .Init("Blue Depths Jellyfish",
                new State(
                    new RingAttack(20, 6, 0, projectileIndex: 0, 2.5, 2.5, coolDown: 1500),
                    new StayBack(1.2, 4),
                    new StayCloseToSpawn(0.3, range: 3),
                    new Wander(0.1)
                )
            )
            .Init("Green Depths Jellyfish",
                new State(
                    new RingAttack(20, 5, 0, projectileIndex: 0, 4.8, 4.8, coolDown: 1200),
                    new StayCloseToSpawn(0.4, range: 3),
                    new Wander(0.3)
                )
            )
            .Init("Pink Depths Jellyfish",
                new State(
                    new Shoot(12, count: 3, shootAngle: 11, projectileIndex: 0, coolDown: 900),
                    new Follow(1.0, 8, 1),
                    new StayCloseToSpawn(0.3, range: 6),
                    new Wander(0.1)
                )
            )
            .Init("Deep Shoaler Leader",
                new State(
                    new State("follow",
                        new Follow(1.3, 8, 0),
                        new TimedTransition(3000, "backup")
                        ),
                    new State("backup",
                        new StayBack(1.6, 7),
                        new TimedTransition(3000, "follow")
                        )
                )
            )
            .Init("Sleeping Octavius",
                new State(
                    new HPScale(25),
                    new State("waiting",
                        new HpLessTransition(0.99, "transform")
                        ),
                    new State("transform",
                        new Transform("Octavius, Octopus Overlord")
                        )
                )
            )
            .Init("Octavius, Octopus Overlord",
                new State(
                    new HPScale(25),
                    new State("awoken",
                        new Taunt("Brlrlp?!"),
                        new Order(45, "Octavius Tentacle Spawner", "transform"),
                        new Shoot(12, count: 2, shootAngle: 60, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 450),
                        new Shoot(12, count: 3, shootAngle: 50, projectileIndex: 0, coolDown: 1700),
                        new Shoot(12, count: 6, shootAngle: 30, projectileIndex: 0, coolDown: 2200),
                        new HpLessTransition(0.66, "sideways")
                        ),
                    new State("sideways",
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 0, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 0, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 0, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 90, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 90, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 90, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 180, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 180, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 180, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 270, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 270, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 270, projectileIndex: 3, coolDown: 4000),
                        new HpLessTransition(0.33, "rotate"),
                        new TimedTransition(3000, "corners")
                        ),
                    new State("corners",
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 45, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 45, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 45, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 135, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 135, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 135, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 225, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 225, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 225, projectileIndex: 3, coolDown: 4000),
                        new Shoot(12, count: 8, shootAngle: 9, fixedAngle: 315, projectileIndex: 1, coolDown: 4000),
                        new Shoot(12, count: 6, shootAngle: 9, fixedAngle: 315, projectileIndex: 2, coolDown: 4000),
                        new Shoot(12, count: 4, shootAngle: 9, fixedAngle: 315, projectileIndex: 3, coolDown: 4000),
                        new HpLessTransition(0.33, "rotate"),
                        new TimedTransition(3000, "sideways")
                        ),
                    new State("rotate",
                        new Taunt("Glorp."),
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Shoot(12, count: 2, shootAngle: 60, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 450),
                        new RingAttack(20, 2, 0, projectileIndex: 3, 0.10, 0.10, coolDown: 200, seeInvis: true),
                        new HpLessTransition(0.05, "final")
                        ),
                    new State("final",
                        new Taunt("Plrp..!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Flash(0xff0000, 0.2, 9999),
                        new Shoot(12, count: 6, shootAngle: 12, projectileIndex: 4, coolDown: 1000),
                        new Shoot(12, count: 4, shootAngle: 90, fixedAngle: 0, projectileIndex: 6, coolDown: 5000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new EntityNotExistsTransition("Octavius Tentacle", 15, "die")
                        ),
                    new State("die",
                        new TransformOnDeath("Octavius Die"),
                        new RemoveObjectOnDeath("Flooded Cavern Wall Fake", 150),
                        new Suicide()
                        )
                ),
                new Threshold(0.00001,
                    new ItemLoot("Sea King's Circlet", 0.02),
                    new ItemLoot("Inky Gland", 0.02),
                    new ItemLoot("Wisdom Fragment", 0.05),
                    new ItemLoot("Potion of Wisdom", 1),
                    new ItemLoot("Potion Tablet", 0.05),
                    new ItemLoot("Flooded Key", 0.005),
                    new TierLoot(10, ItemType.Weapon, 0.14),
                    new TierLoot(11, ItemType.Weapon, 0.08),
                    new TierLoot(4, ItemType.Ability, 0.12),
                    new TierLoot(5, ItemType.Ability, 0.04),
                    new TierLoot(4, ItemType.Ring, 0.14),
                    new TierLoot(5, ItemType.Ring, 0.06),
                    new TierLoot(11, ItemType.Armor, 0.1),
                    new TierLoot(12, ItemType.Armor, 0.07),
                    new ItemLoot("Shard of Evolution", 0.013)
                    ),
                new Threshold(0.03,
                    new ItemLoot("The Big Catch", 0.005)
                )
            )
            .Init("Octavius Die",
                new State(
                    new State("Alive",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(2500, "Dead")
                        ),
                    new State("Dead",
                        new GroundTransform("Flooded Caverns Ground", 5),
                        new Suicide()
                        )
                )
            )
            .Init("Octavius Tentacle",
                new State(
                    new HPScale(25),
                    new State("Alive",
                        new Shoot(8, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 2000),
                        new Shoot(8, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 2000),
                        new Shoot(8, count: 1, shootAngle: 0, projectileIndex: 2, coolDown: 2000),
                        new Shoot(8, count: 1, shootAngle: 0, projectileIndex: 3, coolDown: 2000),
                        new Shoot(8, count: 1, shootAngle: 0, projectileIndex: 4, coolDown: 2000)
                        )
                )
            )
            .Init("Octavius Tentacle Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("waiting",
                        new Wander(0.3)
                        ),
                    new State("transform",
                        new Transform("Octavius Tentacle")
                        )
                )
            )
            .Init("Flooded Cavern Treasure",
            new State("idle",
                new ConditionalEffect(ConditionEffectIndex.ParalyzeImmune)
            ),
            new Threshold(0.01,
                new TierLoot(2, ItemType.Ability, 0.12),
                new TierLoot(3, ItemType.Ability, 0.08),
                new TierLoot(3, ItemType.Ring, 0.1),
                new TierLoot(7, ItemType.Weapon, 0.12),
                new TierLoot(8, ItemType.Weapon, 0.05),
                new TierLoot(8, ItemType.Armor, 0.11),
                new TierLoot(9, ItemType.Armor, 0.04),
                new ItemLoot("Magic Potion", 0.4),
                new ItemLoot("Health Potion", 0.6)
                )
            )
            .Init("Deep Shoaler",
                new State(
                    new RingAttack(20, 1, 0, projectileIndex: 0, 4.8, 4.8, coolDown: 100),
                    new State("leaderalive",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Orbit(0.5, 1, target: "Deep Shoaler Leader", acquireRange: 24, speedVariance: 2.0, radiusVariance: 3),
                        new Charge(speed: 3.5, range: 10, coolDown: 4000),
                        new EntityNotExistsTransition("Deep Shoaler Leader", 24, "leaderdead")
                        ),
                    new State("leaderdead",
                        new Follow(0.6, 8, 1),
                        new Wander(1.1)
                        )
                )
            )
            .Init("Dreadnaut",
                new State(
                    new RingAttack(20, 1, 0, projectileIndex: 0, 4.8, 4.8, coolDown: 100),
                    new State("follow",
                        new Follow(1.7, 8, 0),
                        new Shoot(12, count: 4, shootAngle: 340, projectileIndex: 1, coolDown: 1000),
                        new TimedTransition(3000, "backup")
                        ),
                    new State("backup",
                        new StayBack(1.4, 5),
                        new Shoot(12, count: 4, shootAngle: 11, projectileIndex: 1, coolDown: 1200),
                        new TimedTransition(3000, "follow")
                        )
                )
            )
            .Init("Prideful Diver",
                new State(
                    new HPScale(25),
                    new State("attack1",
                        new StayCloseToSpawn(0.3, range: 4),
                        new Shoot(12, count: 3, shootAngle: 7, projectileIndex: 0, coolDown: 3000),
                        new Shoot(12, count: 3, shootAngle: 7, angleOffset: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Shoot(12, count: 3, shootAngle: 7, angleOffset: -45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Wander(0.25)
                        )
                )
            )
            .Init("Abyssal Angler Idle",
                new State(
                    new State("Idle",
                        new PlayerWithinTransition(6, "Transform")
                        ),
                    new State("Transform",
                        new Transform("Abyssal Angler Rise")
                        )
                )
            )
            .Init("Abyssal Angler Rise",
                new State(
                    new State("Idle",
                        new TimedTransition(1500, "Transform")
                        ),
                    new State("Transform",
                        new Transform("Abyssal Angler")
                        )
                )
            )
            .Init("Abyssal Angler",
                new State(
                    new State("Phase1",
                        new Follow(0.6, 8, 0),
                        new Shoot(12, count: 3, shootAngle: 17, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 4, shootAngle: 39, projectileIndex: 1, coolDown: 2000),
                        new HpLessTransition(0.75, "Phase2")
                        ),
                    new State("Phase2",
                        new Follow(0.6, 8, 0),
                        new RingAttack(20, 8, 0, projectileIndex: 2, 4.8, 4.8, coolDown: 10000),
                        new Shoot(12, count: 3, shootAngle: 17, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 4, shootAngle: 39, projectileIndex: 1, coolDown: 2000),
                        new HpLessTransition(0.50, "Phase3")
                        ),
                    new State("Phase3",
                        new Follow(0.6, 8, 0),
                        new RingAttack(20, 8, 0, projectileIndex: 2, 4.8, 4.8, coolDown: 10000),
                        new Shoot(12, count: 3, shootAngle: 17, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 4, shootAngle: 39, projectileIndex: 1, coolDown: 2000),
                        new HpLessTransition(0.25, "Phase4")
                        ),
                    new State("Phase4",
                        new Follow(0.6, 8, 0),
                        new RingAttack(20, 8, 0, projectileIndex: 2, 4.8, 4.8, coolDown: 10000),
                        new Shoot(12, count: 3, shootAngle: 17, projectileIndex: 0, coolDown: 1000),
                        new Shoot(12, count: 4, shootAngle: 39, projectileIndex: 1, coolDown: 2000)
                        )
                )
            )
            .Init("Sky Skimmer",
                new State(
                    new DropPortalOnDeath("Flooded Portal", .4),
                    new Prioritize(
                        new StayCloseToSpawn(0.3, range:5),
                        new Wander(0.25)
                    ),
                    new Shoot(12, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 1500),
                    new State("AttackL",
                        new Shoot(12, count: 5, shootAngle: 9, projectileIndex: 1, fixedAngle: 90, coolDown: 2400),
                        new Shoot(12, count: 5, shootAngle: 9, projectileIndex: 1, fixedAngle: 270, coolDown: 2400),
                        new TimedTransition(2400, "AttackR")
                        ),
                    new State("AttackR",
                        new Shoot(12, count: 5, shootAngle: 9, projectileIndex: 1, fixedAngle: 0, coolDown: 2400),
                        new Shoot(12, count: 5, shootAngle: 9, projectileIndex: 1, fixedAngle: 180, coolDown: 2400),
                        new TimedTransition(2400, "AttackL")
                        )
                    ),
                new Threshold(0.01,
                    LootTemplates.MountainDrop()
                    )
            );
    }
}
