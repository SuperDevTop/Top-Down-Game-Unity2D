﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.transitions;
using wServer.logic.loot;
//by GhostMaree
namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ HauntedCemeteryGates = () => Behav()
                .Init("Arena Ghost 1",
                    new State(
                        new Prioritize(
                            new Orbit(speed: 0.5, radius: 2.8, acquireRange: 10, target: null),
                            new Charge(speed: 0.8, range: 11, coolDown: 2000)
                        ),
                        new Wander(speed: 0.6),
                        new Shoot(radius: 5.5, count: 1, projectileIndex: 0, coolDown: 1000)
                    )
                 )
                .Init("Arena Ghost 2",
                    new State(
                        new State("Ini",
                            new SetAltTexture(0),
                            new Prioritize(
                                new Wander(speed: 0.3),
                                new Charge(speed: 2.6, range: 12, coolDown: 2000),
                                new StayBack(speed: 0.8, distance: 4, entity: null)
                            ),
                            new Shoot(radius: 5, count: 3, shootAngle: 20, projectileIndex: 0, coolDown: 1000),
                            new TimedTransition(time: 2000, targetState: "Disappear")
                        ),
                        new State("Disappear",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new SetAltTexture(1, 2, 300, true),
                            new Wander(speed: 0.5),
                            new TimedTransition(time: 1500, targetState: "Ini")
                            )
                        )
                )
                .Init("Arena Possessed Girl",
                    new State(
                        new Prioritize(
                            new Follow(speed: 0.5, acquireRange: 15, range: 3, duration: 5000, coolDown: 3000),
                            new Wander(speed: 0.3)
                            ),
                        new Shoot(radius: 24, count: 8, shootAngle: 45, projectileIndex: 0, fixedAngle: 22.5, coolDown: 600)
                    )
                )
                .Init("Arena Ghost Bride",
                    new State(
                        new HPScale(35),
                        new State("Ini",
                            new Prioritize(
                                new Wander(speed: 0.3),
                                new Follow(speed: 0.6, acquireRange: 8, range: 3, duration: 3000, coolDown: 4000),
                                new StayBack(speed: 0.4, distance: 4, entity: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 0.9, coolDown: 3000),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 0, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 180, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 90, coolDown: 1500, coolDownOffset: 300),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 270, coolDown: 1500, coolDownOffset: 300),
                            new HpLessTransition(threshold: 0.75, targetState: "ActivateBigDemon")
                        ),
                        new State("ActivateBigDemon",
                            new SetAltTexture(1),
                            new OrderOnce(range: 100, children: "Arena Statue Left", targetState: "Active"),
                            new EntityNotExistsTransition(target: "Arena Statue Left", dist: 100, targetState: "Attack1"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                        new State("Attack1",
                            new SetAltTexture(0),
                            new Prioritize(
                                new Wander(speed: 0.3),
                                new Follow(speed: 0.6, acquireRange: 8, range: 3, duration: 3000, coolDown: 4000),
                                new StayBack(speed: 0.4, distance: 4, entity: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 0.9, coolDown: 3000),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 0, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 180, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 90, coolDown: 1500, coolDownOffset: 300),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 270, coolDown: 1500, coolDownOffset: 300),
                            new HpLessTransition(threshold: 0.5, targetState: "ActivateWerewolf")
                        ),
                        new State("ActivateWerewolf",
                            new SetAltTexture(1),
                            new OrderOnce(range: 100, children: "Arena Statue Right", targetState: "Active"),
                            new EntityNotExistsTransition(target: "Arena Statue Right", dist: 100, targetState: "Attack2"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                        new State("Attack2",
                            new SetAltTexture(0),
                            new Prioritize(
                                new Wander(speed: 0.3),
                                new Follow(speed: 0.6, acquireRange: 8, range: 3, duration: 3000, coolDown: 4000),
                                new StayBack(speed: 0.4, distance: 4, entity: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 0.9, coolDown: 3000),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 0, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 180, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 90, coolDown: 1500, coolDownOffset: 300),
                            new Shoot(radius: 8, count: 2, shootAngle: 30, projectileIndex: 1, fixedAngle: 270, coolDown: 1500, coolDownOffset: 300)
                        )
                    ),
                    new Threshold(0.01,
                        new ItemLoot("Speed Fragment", 0.05),
                        new ItemLoot("Wisdom Fragment", 0.05),
                        new ItemLoot("Potion of Speed", 0.3, 3),
                        new ItemLoot("Potion of Wisdom", 0.3),
                        new ItemLoot("Potion Tablet", .05),
                        new ItemLoot("Spectral Ring of Horrors", 0.02),
                        new ItemLoot("Rugged Kaftan", 0.02)
                    )
                )
                .Init("Arena Statue Right",
                    new State(
                        new HPScale(35),
                        new State("Ini",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new SetAltTexture(1)
                        ),
                        new State("Active",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(time: 0,targetState: "Active_fix")
                        ),
                        new State("Active_fix",
                            new SetAltTexture(0),
                            new Prioritize(
                                new Follow(speed: 0.7, acquireRange: 10, range: 2, duration: 6000, coolDown: 3000),
                                new Orbit(speed: 0.6, radius: 3, acquireRange: 10, target: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 1, coolDown: 700),
                            new Shoot(radius: 9, count: 2, shootAngle: 35, projectileIndex: 1, predictive: 1, coolDown: 1500, coolDownOffset: 0),
                            new HpLessTransition(threshold: 0.75, targetState: "Phase2")
                        ),
                        new State("Phase2",
                            new Prioritize(
                                new Follow(speed: 0.7, acquireRange: 10, range: 2, duration: 6000, coolDown: 3000),
                                new Orbit(speed: 0.6, radius: 3, acquireRange: 10, target: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 1, coolDown: 700),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 35, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 70, coolDown: 1500, coolDownOffset: 200),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 105, coolDown: 1500, coolDownOffset: 400),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 140, coolDown: 1500, coolDownOffset: 600),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 175, coolDown: 1500, coolDownOffset: 800),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 210, coolDown: 1500, coolDownOffset: 1000),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 245, coolDown: 1500, coolDownOffset: 1200),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 280, coolDown: 1500, coolDownOffset: 1400),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 315, coolDown: 1500, coolDownOffset: 1600),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 359, coolDown: 1500, coolDownOffset: 1800),
                            new HpLessTransition(threshold: 0.5, targetState: "Active2")
                        ),
                        new State("Active2",
                            new SetAltTexture(0),
                            new Prioritize(
                                new Follow(speed: 0.7, acquireRange: 10, range: 2, duration: 6000, coolDown: 3000),
                                new Orbit(speed: 0.6, radius: 3, acquireRange: 10, target: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 1, coolDown: 700),
                            new Shoot(radius: 9, count: 2, shootAngle: 35, projectileIndex: 1, predictive: 1, coolDown: 1500, coolDownOffset: 0),
                            new HpLessTransition(threshold: 0.25, targetState: "Phase4")
                        ),
                        new State("Phase4",
                            new Prioritize(
                                new Follow(speed: 0.7, acquireRange: 10, range: 2, duration: 6000, coolDown: 3000),
                                new Orbit(speed: 0.6, radius: 3, acquireRange: 10, target: null)
                            ),
                            new Shoot(radius: 8, count: 1, projectileIndex: 0, predictive: 1, coolDown: 700),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 35, coolDown: 1500, coolDownOffset: 0),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 70, coolDown: 1500, coolDownOffset: 200),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 105, coolDown: 1500, coolDownOffset: 400),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 140, coolDown: 1500, coolDownOffset: 600),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 175, coolDown: 1500, coolDownOffset: 800),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 210, coolDown: 1500, coolDownOffset: 1000),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 245, coolDown: 1500, coolDownOffset: 1200),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 280, coolDown: 1500, coolDownOffset: 1400),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 315, coolDown: 1500, coolDownOffset: 1600),
                            new Shoot(radius: 9, count: 1, projectileIndex: 1, fixedAngle: 359, coolDown: 1500, coolDownOffset: 1800)
                        )
                    )
                )
                .Init("Arena Statue Left",
                    new State(
                        new HPScale(35),
                        new State("Ini",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new SetAltTexture(1)
                        ),
                        new State("Active",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(time: 0, targetState: "Active_fix")
                        ),
                        new State("Active_fix",
                            new SetAltTexture(0),
                            new ChangeSize(rate: 1, target: 200),
                            new Prioritize(
                                new Follow(speed: 0.7, acquireRange: 10, range: 2, duration: 6000, coolDown: 3000),
                                new Orbit(speed: 0.6, radius: 3, acquireRange: 10, target: null)
                            ),
                            new Shoot(radius: 9, count: 2, shootAngle: 35, projectileIndex: 0, predictive: 0.7, coolDown: 1000),
                            new PlayerWithinTransition(dist: 1, targetState: "SpiralBlast", seeInvis: true),
                            new TimedTransition(time: 2000, targetState: "SpiralBlast")
                        ),
                        new State("SpiralBlast",
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 0, coolDown: 10000, coolDownOffset: 0),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 45, coolDown: 10000, coolDownOffset: 100),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 90, coolDown: 10000, coolDownOffset: 200),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 135, coolDown: 10000, coolDownOffset: 300),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 180, coolDown: 10000, coolDownOffset: 400),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 225, coolDown: 10000, coolDownOffset: 500),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 270, coolDown: 10000, coolDownOffset: 600),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 315, coolDown: 10000, coolDownOffset: 700),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 0, coolDown: 10000, coolDownOffset: 800),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 45, coolDown: 10000, coolDownOffset: 900),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 90, coolDown: 10000, coolDownOffset: 1000),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 135, coolDown: 10000, coolDownOffset: 1100),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 180, coolDown: 10000, coolDownOffset: 1200),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 225, coolDown: 10000, coolDownOffset: 1300),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 270, coolDown: 10000, coolDownOffset: 1400),
                            new Shoot(radius: 24, count: 1, projectileIndex: 0, fixedAngle: 315, coolDown: 10000, coolDownOffset: 1500),
                            new TimedTransition(time: 1800, targetState: "Active")
                        )
                    )
                )
            ;
    }
}
