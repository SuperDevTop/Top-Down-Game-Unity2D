﻿#region

using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

#endregion

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Oryx = () => Behav()
            .Init("Oryx the Mad God 2",
                new State(
                    new HPScale(35),
                    new State("CheckPlayer",
                        new PlayerWithinTransition(15, "Wait", false)
                        ),
                    new State("Wait",
                        new Wander(0.05),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable, false, 20000),
                        new Shoot(25, projectileIndex: 0, count: 8, shootAngle: 45, coolDown: 1500, coolDownOffset: 1500),
                        new Shoot(25, projectileIndex: 1, count: 3, shootAngle: 10, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 2, count: 3, shootAngle: 10, predictive: 0.2, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 3, count: 2, shootAngle: 10, predictive: 0.4, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 4, count: 3, shootAngle: 10, predictive: 0.6, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 5, count: 2, shootAngle: 10, predictive: 0.8, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 6, count: 3, shootAngle: 10, predictive: 1, coolDown: 1000, coolDownOffset: 1000),
                        new TimedTransition(20000, "Attack")
                        ),
                    new State("Attack",
                        new Wander(.05),
                        new Shoot(25, projectileIndex: 0, count: 8, shootAngle: 45, coolDown: 1500, coolDownOffset: 1500),
                        new Shoot(25, projectileIndex: 1, count: 3, shootAngle: 10, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 2, count: 3, shootAngle: 10, predictive: 0.2, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 3, count: 2, shootAngle: 10, predictive: 0.4, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 4, count: 3, shootAngle: 10, predictive: 0.6, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 5, count: 2, shootAngle: 10, predictive: 0.8, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 6, count: 3, shootAngle: 10, predictive: 1, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Taunt(1, 6000, "Puny mortals! My {HP} HP will annihilate you!"),
                        new Spawn("Henchman of Oryx", 5, coolDown: 5000),
                        new HpLessTransition(.2, "prepareRage")
                    ),
                    new State("prepareRage",
                        new Follow(.1, 15, 3),
                        new Taunt("Can't... keep... henchmen... alive... anymore! ARGHHH!!!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(25, 30, fixedAngle: 0, projectileIndex: 7, coolDown: 4000, coolDownOffset: 4000),
                        new Shoot(25, 30, fixedAngle: 30, projectileIndex: 8, coolDown: 4000, coolDownOffset: 4000),
                        new TimedTransition(20000, "rage")
                    ),
                    new State("rage",
                        new Follow(.1, 15, 3),
                        new Shoot(25, 30, projectileIndex: 7, coolDown: 90000001, coolDownOffset: 8000),
                        new Shoot(25, 30, projectileIndex: 8, coolDown: 90000001, coolDownOffset: 8500),
                        new Shoot(25, projectileIndex: 0, count: 8, shootAngle: 45, coolDown: 1500, coolDownOffset: 1500),
                        new Shoot(25, projectileIndex: 1, count: 3, shootAngle: 10, coolDown: 1000, coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 2, count: 3, shootAngle: 10, predictive: 0.2, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 3, count: 2, shootAngle: 10, predictive: 0.4, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 4, count: 3, shootAngle: 10, predictive: 0.6, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 5, count: 2, shootAngle: 10, predictive: 0.8, coolDown: 1000,
                            coolDownOffset: 1000),
                        new Shoot(25, projectileIndex: 6, count: 3, shootAngle: 10, predictive: 1, coolDown: 1000,
                            coolDownOffset: 1000),
                        new TossObject("Monstrosity Scarab", 7, 0, coolDown: 1000),
                        new Taunt(1, 6000, "Puny mortals! My {HP} HP will annihilate you!")
                    )
                ),
                new Threshold(0.003, // 3 percent threshold
                    new ItemLoot("Potion of Vitality", 0.5),
                    new ItemLoot("Potion of Attack", 0.5),
                    new ItemLoot("Potion of Wisdom", 0.5),
                    new ItemLoot("Potion of Defense", 0.5),
                    new ItemLoot("Potion of Speed", 0.5),
                    new ItemLoot("Shard of Evolution", 0.020),
                    new ItemLoot("Potion of Dexterity", 0.05),
                    new ItemLoot("Potion of Life", 1),
                    new ItemLoot("Potion of Mana", 1)
                ),
                new Threshold(0.002,// 2 percent threshold
                    new ItemLoot("Potion of Attack", 1),
                    new ItemLoot("Potion of Defense", 1),
                    new ItemLoot("Potion of Wisdom", 0.5)
                ),
                new Threshold(0.001,// 1 percent
                    new TierLoot(13, ItemType.Weapon, 0.05),
                    new TierLoot(13, ItemType.Weapon, 0.05),
                    new TierLoot(13, ItemType.Weapon, 0.05),
                    new TierLoot(6, ItemType.Ability, 0.06),
                    new TierLoot(6, ItemType.Ability, 0.06),
                    new TierLoot(13, ItemType.Armor, 0.06),
                    new TierLoot(13, ItemType.Armor, 0.06),
                    new TierLoot(13, ItemType.Armor, 0.06),
                    new TierLoot(6, ItemType.Ring, 0.07)
                )
            )
        .Init("Oryx the Mad God 3",
                new State(
                    new HPScale(20),
                    new State("CheckPlayer",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new PlayerWithinTransition(15, "Wait1", true)
                        ),
                    new State("Wait1",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("You thought that you finished me in the wine seller!"),
                        new TimedTransition(4000, "Wait2")
                        ),
                    new State("Wait2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Welcome to my domain!"),
                        new TimedTransition(3000, "Wait3")
                        ),
                    new State("Wait3",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Here I can finally fight you with my full power!"),
                        new TimedTransition(4000, "Flame1")
                        ),
                    new State("Flame1",
                        new ReproduceChildren(2, 0, 3000, "Oryx 3 Immolater"),
                        new RingAttack(20, 16, 0, projectileIndex: 1, 25, 0, coolDown: 4000),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 0, shootAngle: 6, coolDown: 2000),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 45, shootAngle: 6, coolDown: 2100),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 90, shootAngle: 6, coolDown: 2200),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 135, shootAngle: 6, coolDown: 2300),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 180, shootAngle: 6, coolDown: 2400),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 225, shootAngle: 6, coolDown: 2500),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 270, shootAngle: 6, coolDown: 2600),
                        new Shoot(15, count: 5, projectileIndex: 0, fixedAngle: 315, shootAngle: 6, coolDown: 2700),
                        new TimedTransition(10000, "Ice1")
                        ),
                     new State("Ice1",
                        new ReproduceChildren(1, 0, 4000, "Oryx 3 Snowball"),
                        new RingAttack(20, 14, 0, projectileIndex: 2, 45, 45, coolDown: 4000),
                        new RingAttack(20, 16, 0, projectileIndex: 3, 45, 45, coolDown: 4100),
                        new Shoot(15, count: 1, projectileIndex: 4, shootAngle: 0, coolDown: 2500),
                        new Shoot(15, count: 2, projectileIndex: 5, shootAngle: 15, coolDown: 2500),
                        new Shoot(15, count: 2, projectileIndex: 6, shootAngle: 30, coolDown: 2500),
                        new Shoot(15, count: 2, projectileIndex: 7, shootAngle: 45, coolDown: 2500),
                        new Shoot(15, count: 2, projectileIndex: 8, shootAngle: 60, coolDown: 2500),
                        new Shoot(15, count: 2, projectileIndex: 9, shootAngle: 75, coolDown: 2500),
                        new TimedTransition(10000, "Wind1")
                        ),
                     new State("Wind1",
                        new RingAttack(20, 1, 0, projectileIndex: 11, 0.2, 0.2, coolDown: 70, seeInvis: true),
                        new Shoot(15, count: 5, projectileIndex: 10, shootAngle: 20, coolDown: 1900),
                        new TimedTransition(4000, "WindT1")
                        ),
                     new State("WindT1",
                        new RingAttack(20, 4, 0, projectileIndex: 12, 0.2, 0.2, coolDown: 150, seeInvis: true),
                        new TimedTransition(6000, "Flame1")
                    )
                ),
                new Threshold(0.03,
                    new ItemLoot("Shard of Evolution", 0.02),
                    new ItemLoot("Greater Potion of Vitality", 0.5),
                    new ItemLoot("Greater Potion of Attack", 0.5),
                    new ItemLoot("Greater Potion of Wisdom", 0.5),
                    new ItemLoot("Greater Potion of Defense", 0.5),
                    new ItemLoot("Greater Potion of Speed", 0.5),
                    new ItemLoot("Greater Potion of Dexterity", 0.5),
                    new ItemLoot("Greater Potion of Life", 0.4),
                    new ItemLoot("Greater Potion of Mana", 0.4)
                ),
                new Threshold(0.02,
                    new ItemLoot("Potion of Vitality", 0.8),
                    new ItemLoot("Potion of Attack", 0.8),
                    new ItemLoot("Potion of Wisdom", 0.8),
                    new ItemLoot("Potion of Defense", 0.8),
                    new ItemLoot("Potion of Speed", 0.8),
                    new ItemLoot("Potion of Dexterity", 0.8),
                    new ItemLoot("Potion of Life", 0.7),
                    new ItemLoot("Potion of Mana", 0.7)
                ),
                new Threshold(0.01,
                    new ItemLoot("Potion of Vitality", 0.4),
                    new ItemLoot("Potion of Attack", 0.4),
                    new ItemLoot("Potion of Wisdom", 0.4),
                    new ItemLoot("Potion of Defense", 0.4),
                    new ItemLoot("Potion of Speed", 0.4),
                    new ItemLoot("Potion of Dexterity", 0.4),
                    new TierLoot(14, ItemType.Weapon, 0.25),
                    new TierLoot(6, ItemType.Ability, 0.25),
                    new TierLoot(15, ItemType.Armor, 0.25),
                    new TierLoot(6, ItemType.Ring, 0.25)
                )
            )
        .Init("Oryx 3 Immolater",
                new State(
                    new State("active",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Follow(1.3, 13, 0),
                        new PlayerWithinTransition(3, "blink")
                    ),
                    new State("blink",
                        new Flash(0xbdbdbd, 0.2, 9999),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Follow(1.3, 13, 0),
                        new TimedTransition(1000, "explode")
                    ),
                    new State("explode",
                        new RingAttack(20, 16, 0, projectileIndex: 0, 2, 2),
                        new Suicide()
                    )
                )
            )
        .Init("Oryx 3 Snowball",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new Prioritize(
                            new Orbit(1.0, 8, target: "Oryx the Mad God 3", acquireRange: 10, speedVariance: 0, radiusVariance: 0)
                                ),
                        new State("attack",
                            new RingAttack(20, 8, 0, projectileIndex: 0, 45, 45, coolDown: 4000),
                            new HpLessTransition(0.15, "ExplodeT"),
                            new TimedTransition(15000, "ExplodeT")
                            ),
                        new State("ExplodeT",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Flash(0xe60b0b, 0.1, 999999),
                            new TimedTransition(1000, "Shoot")
                            ),
                        new State("Shoot",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new RingAttack(20, 12, 0, projectileIndex: 1, 45, 45, coolDown: 400),
                            new TimedTransition(500, "Explode")
                            ),
                        new State("Explode",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Suicide()
                            )
                        )
                    )
        .Init("Oryx God of Conquest",
                new State(
                    new HPScale(25),
                    new State("Activate",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(8, "idle")
                    ),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new ReproduceChildren(1, 1, 5000, "Oryx Conquest Dialog"),
                        new TimedTransition(1500, "Awaken 1")
                    ),
                    new State("Awaken 1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Awaken 1"),
                        new TimedTransition(2500, "Awaken 2")    
                    ),    
                    new State("Awaken 2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Awaken 2"),
                        new TimedTransition(2500, "Awaken 3")    
                    ),    
                    new State("Awaken 3",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Awaken 3"),
                        new TimedTransition(3200, "Awaken 4")    
                    ),    
                    new State("Awaken 4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Awaken 4"),
                        new Order(45, "Oryx Invis Barrier", "Transform"),
                        new TimedTransition(2500, "Attack")
                    ),    
                    new State("Attack",
                        new Grenade(4, 150, range: 15, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 5000, color: 0xff0000, coolDown: 5000),
                        new Shoot(15, count: 2, shootAngle: 0, projectileIndex: 0, coolDown: 1200),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 200),
                        new Shoot(15, count: 3, shootAngle: 8, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 600),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 90, rotateAngle: 45, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 90, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 200),
                        new Shoot(15, count: 3, shootAngle: 8, fixedAngle: 90, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 90, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 600),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 180, rotateAngle: 45, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 180, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 200),
                        new Shoot(15, count: 3, shootAngle: 8, fixedAngle: 180, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 180, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 600),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 270, rotateAngle: 45, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 270, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 200),
                        new Shoot(15, count: 3, shootAngle: 8, fixedAngle: 270, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 400),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 270, rotateAngle: 45, projectileIndex: 1, coolDown: 3000, coolDownOffset: 600),
                        new HpLessTransition(0.75, "Before Fire")
                    ),
                    new State("Before Fire",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Before Fire"),
                        new TimedTransition(2500, "Black Fire")
                    ),
                    new State("Black Fire",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Black Fire"),
                        new RingAttack(20, 3, 0, projectileIndex: 2, 0.15, 0.0, coolDown: 130, seeInvis: true),
                        new RingAttack(20, 3, 0, projectileIndex: 2, 0.15, 6.0, coolDown: 130, seeInvis: true),
                        new RingAttack(20, 3, 0, projectileIndex: 2, 0.15, 12.0, coolDown: 130, seeInvis: true),
                        new Shoot(15, count: 4, shootAngle: 10, projectileIndex: 3, coolDown: 500),
                        new TimedTransition(15000, "Before Swords")
                    ),
                    new State("Before Swords",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Conquest Dialog", "Before Swords"),
                        new TimedTransition(2500, "Swords")
                    ),
                    new State("Swords",
                        new Follow(1.25, 14, 0),
                        new Shoot(15, count: 3, shootAngle: 7, projectileIndex: 4, coolDown: 550),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 5, coolDown: 1800),
                        new RingAttack(20, 14, 0, projectileIndex: 4, 0.10, 0.10, coolDown: 1750, seeInvis: true),
                        new HpLessTransition(0.50, "Return Portals")
                    ),
                    new State("Return Portals",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new ReturnToSpawn(speed: 1.40),
                        new TimedTransition(2000, "Before Portals")
                    ),
                    new State("Before Portals",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(1),
                        new Order(30, "Oryx Lava Controller", "Lava"),
                        new Order(30, "Oryx Conquest Dialog", "Before Portals"),
                        new TimedTransition(2500, "Portals")
                    ),
                    new State("Portals",
                        new TossObject("Oryx Dark Portal", 11, angle: 0, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 40, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 80, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 120, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 160, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 200, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 240, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 280, coolDown: 500000, throwEffect: true),
                        new TossObject("Oryx Dark Portal", 11, angle: 320, coolDown: 500000, throwEffect: true),
                        new RingAttack(20, 6, 0, projectileIndex: 6, -0.25, 0.0, coolDown: 600, seeInvis: true),
                        new HpLessTransition(0.25, "Before Rage")
                    ),
                    new State("Before Rage",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Order(30, "Oryx Dark Portal", "Destroy"),
                        new Order(30, "Oryx Conquest Dialog", "Before Rage"),
                        new TimedTransition(2500, "Rage")
                    ),
                    new State("Rage",
                        new Follow(1.15, 14, 0),
                        new Shoot(15, count: 4, shootAngle: 7, projectileIndex: 4, coolDown: 500),
                        new RingAttack(20, 14, 0, projectileIndex: 4, 0.10, 0.10, coolDown: 1800, seeInvis: true),
                        new RingAttack(20, 4, 0, projectileIndex: 6, 0.25, 0.0, coolDown: 900, seeInvis: true),
                        new Grenade(2.0, 100, range: 15, effect: ConditionEffectIndex.Blind, effectDuration: 1000, color: 0xff0000, coolDown: 2000)
                    )
                ),
                new Threshold(0.001,
                    LootTemplates.OryxOneDrop()
                    ),
                new Threshold(0.005,
                    new ItemLoot("Darksteel Lootbox", 0.1)
                    ),
                new Threshold(0.005,
                    new ItemLoot("Life Fragment", 0.05),
                    new ItemLoot("Mana Fragment", 0.05),
                    new ItemLoot("Attack Fragment", 0.05),
                    new ItemLoot("Defense Fragment", 0.05),
                    new ItemLoot("Speed Fragment", 0.05),
                    new ItemLoot("Dexterity Fragment", 0.05),
                    new ItemLoot("Vitality Fragment", 0.05),
                    new ItemLoot("Wisdom Fragment", 0.05),
                    new ItemLoot("Critical Hit Fragment", 0.05),
                    new ItemLoot("Critical Damage Fragment", 0.05)
                    ),
                new Threshold(0.01,
                    new ItemLoot("Blade of Conquest", 0.005),
                    new ItemLoot("Cape of Arrogance", 0.005),
                    new ItemLoot("Lost Blade of the Realms", 0.02),
                    new ItemLoot("Traitor's Badge", 0.02),
                    new ItemLoot("Sinful Safeguard", 0.005),
                    new ItemLoot("Armor of Blades", 0.02),
                    new ItemLoot("Gauntlet of Fury", 0.005),
                    new ItemLoot("Shard of Divinity", 0.0025),
                    new ItemLoot("The Titan Slayer", 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000001)
                    )
            )
        .Init("Oryx Conquest Dialog",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                            new Orbit(0.01, 0.1, target: "Oryx God of Conquest", acquireRange: 25, speedVariance: 0, radiusVariance: 0)
                                ),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.ParalyzeImmune)
                    ),
                    new State("Awaken 1",
                        new Taunt("Oh? The Heroes?")
                    ),
                    new State("Awaken 2",
                        new Taunt("You're too late.")
                    ),
                    new State("Awaken 3",
                        new Taunt("Sadly, this realm is already mine.")
                    ),
                    new State("Awaken 4",
                        new Taunt("Now begone.")
                    ),
                    new State("Before Fire",
                        new Taunt("Flame Wall.")
                    ),
                    new State("Black Fire",
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 900),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 900, coolDownOffset: 200),
                        new Shoot(15, count: 3, shootAngle: 8, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 900, coolDownOffset: 400),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 1, coolDown: 900, coolDownOffset: 600)
                    ),
                    new State("Before Swords",
                        new Taunt("Foolish Worms!")
                    ),
                    new State("Before Portals",
                        new Taunt("*Arcane Chant*")
                    ),
                    new State("Before Rage",
                        new Taunt("YOU ANTS THINK YOU CAN DEFEAT A GOD")
                    )
                )
            )
        .Init("Oryx Dark Portal",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                            new Orbit(0.08, 11, target: "Oryx God of Conquest", acquireRange: 25, speedVariance: 0, radiusVariance: 0)
                                ),
                    new State("Exist",
                        new Shoot(15, count: 4, shootAngle: 90, fixedAngle: 0, rotateAngle: 45, projectileIndex: 0, coolDown: 1000)
                    ),
                    new State("Destroy",
                        new Suicide()
                    )
                )
            )
        .Init("Oryx Lava Controller",
                new State(
                    new State("Exist",
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                    ),
                    new State("Lava",
                        new GroundTransform("Hot Lava", 1),
                        new Decay()
                    )
                )
            )
        .Init("Oryx Invis Barrier",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TransformOnDeath("Oryx Brick Wall"),
                        new Suicide()
                        )
                    )
                )
        .Init("JanusC",
                new State(
                    new HPScale(25),
                    new State("active",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(9, "wait1")
                    ),
                    new State("wait1",
                        new Taunt("FINALLY, SOMEONE WE CAN RIP APART"),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "wait2")
                    ),
                    new State("wait2",
                        new Taunt("please go away.."),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "wait3")
                    ),
                    new State("wait3",
                        new Taunt("COME CLOSER"),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "wait4")
                    ),
                    new State("wait4",
                        new Taunt("i don't wanna kill anymore.."),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "wait5")
                    ),
                    new State("wait5",
                        new Taunt("TIME TO DISAPPEAR"),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "attack1")
                    ),
                    new State("attack1",
                        new Taunt("please die quickly.."),
                        new RingAttack(20, 16, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new Shoot(10, count: 9, shootAngle: 10, projectileIndex: 1, fixedAngle: 0, coolDown: 300),
                        new Shoot(10, count: 9, shootAngle: 10, projectileIndex: 0, fixedAngle: 180, coolDown: 300),
                        new HpLessTransition(0.75, "rotate"),
                        new TimedTransition(8000, "attack1.1")
                    ),
                    new State("attack1.1",
                        new RingAttack(20, 20, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new Shoot(10, count: 1, shootAngle: 0, projectileIndex: 3, coolDown: 4000),
                        new HpLessTransition(0.75, "rotate"),
                        new TimedTransition(4500, "attack2")
                    ),
                    new State("attack2",
                        new Taunt("SUFFER!"),
                        new RingAttack(20, 18, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new Shoot(10, count: 9, shootAngle: 10, projectileIndex: 0, fixedAngle: 90, coolDown: 300),
                        new Shoot(10, count: 9, shootAngle: 10, projectileIndex: 1, fixedAngle: 270, coolDown: 300),
                        new HpLessTransition(0.75, "rotate"),
                        new TimedTransition(8000, "attack2.1")
                    ),
                    new State("attack2.1",
                        new RingAttack(20, 20, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new Shoot(10, count: 1, shootAngle: 0, projectileIndex: 3, coolDown: 4000),
                        new HpLessTransition(0.75, "rotate"),
                        new TimedTransition(4500, "attack1")
                    ),
                    new State("rotate",
                        new Taunt("DESTROY!!"),
                        new RingAttack(20, 1, 0, projectileIndex: 2, 0.60, 0, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 0, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 5, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 10, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 90, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 95, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 100, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 180, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 185, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.10, 190, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 270, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 275, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.10, 280, coolDown: 100, seeInvis: true),
                        new HpLessTransition(0.50, "spawn1"),
                        new TimedTransition(8000, "rotate1.1")
                    ),
                    new State("rotate1.1",
                        new RingAttack(20, 1, 0, projectileIndex: 2, 0.60, 0, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 20, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new HpLessTransition(0.50, "spawn1"),
                        new TimedTransition(5000, "rotate2")
                    ),
                    new State("rotate2",
                        new Taunt("please.. don't dodge this"),
                        new RingAttack(20, 20, 0, projectileIndex: 2, 2, 2, coolDown: 3500),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 0, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 5, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 10, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 180, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 185, coolDown: 100, seeInvis: true),
                        new RingAttack(20, 1, 0, projectileIndex: 3, 0.15, 190, coolDown: 100, seeInvis: true),
                        new HpLessTransition(0.50, "spawn1"),
                        new TimedTransition(6000, "rotate2.1")
                    ),
                    new State("rotate2.1",
                        new RingAttack(20, 20, 0, projectileIndex: 2, 2, 2, coolDown: 1000),
                        new HpLessTransition(0.50, "spawn1"),
                        new TimedTransition(1500, "rotate")
                    ),
                    new State("spawn1",
                        new Taunt("goodbye.. he want's me to get serious.."),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "spawn2")
                    ),
                    new State("spawn2",
                        new TossObject("Skull of Despair", 5, angle: 45, coolDown: 500000, throwEffect: true),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "spawn3")
                    ),
                    new State("spawn3",
                        new TossObject("Skull of Anger", 5, angle: 135, coolDown: 500000, throwEffect: true),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "spawn4")
                    ),
                    new State("spawn4",
                        new TossObject("Skull of Despair", 5, angle: 225, coolDown: 500000, throwEffect: true),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "spawn5")
                    ),
                    new State("spawn5",
                        new TossObject("Skull of Anger", 5, angle: 315, coolDown: 500000, throwEffect: true),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(4000, "activate")
                    ),
                    new State("activate",
                        new Taunt("DIE ALREADY YOU LITTLE ANTS"),
                        new Order(30, "Skull of Despair", "attack"),
                        new Order(30, "Skull of Anger", "attack"),
                        new RingAttack(20, 18, 0, projectileIndex: 2, 2, 2, coolDown: 6000),
                        new HpLessTransition(0.25, "final")
                    ),
                    new State("final",
                        new Order(30, "Skull of Despair", "fasterattack"),
                        new Order(30, "Skull of Anger", "fasterattack"),
                        new RingAttack(20, 24, 0, projectileIndex: 2, 2, 2, coolDown: 5000),
                        new HpLessTransition(0.05, "death")
                    ),
                    new State("death",
                        new Order(30, "Skull of Despair", "decay"),
                        new Order(30, "Skull of Anger", "decay"),
                        new RemoveObjectOnDeath("Cthu Gate", 25),
                        new Suicide()
                        )
                    ),
                new Threshold(0.001,
                    LootTemplates.StrongerDrop()
                    ),
                    new Threshold(0.0001,
                        new ItemLoot("Defense Fragment", 0.05),
                        new ItemLoot("Wisdom Fragment", 0.05),
                        new ItemLoot("Potion Tablet", 0.5),
                        new ItemLoot("Potion of Defense", 1),
                        new ItemLoot("Potion of Wisdom", 1)
                    ),
                new Threshold(0.005,
                    new ItemLoot("Havoc Circlet", 0.02),
                    new ItemLoot("Arbalest of Ichor", 0.02),
                    new ItemLoot("Darksteel Lootbox", 0.1)
                    ),
                new Threshold(0.02,
                    new ItemLoot("Turmoil's Jaws", 0.005),
                    new ItemLoot("Lifeblood Spectrum", 0.005),
                    new ItemLoot("Potion of Life", 0.8),
                    new ItemLoot("Potion of Mana", 0.8),
                    new ItemLoot("Potion of Critical Hit", 0.4),
                    new ItemLoot("Potion of Critical Damage", 0.8)
                    )
                )
            .Init("Mercenary of Oryx",
                new State(
                    new ScaleHP(1200, 0, true, 15, 1),
                    new State("Spikes",
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Follow(0.4, 14, 0),
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 5, 0, projectileIndex: 0, 0.50, 0.50, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 4, 0, projectileIndex: 0, 0.75, 0.75, coolDown: 750, seeInvis: true),
                        new TimedTransition(4000, "Slash")
                    ),
                    new State("Slash",
                        new Follow(1.0, 14, 0),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 500),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 2, coolDown: 500),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 3, coolDown: 500),
                        new TimedTransition(4000, "Spikes")
                    )
                )
            )
            .Init("Fallen Assassin",
                new State(
                    new ScaleHP(900, 0, true, 15, 1),
                    new State("Waiting",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(10, "attack")
                    ),
                    new State("attack",
                        new Follow(0.7, 14, 0),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 1000),
                        new Grenade(3.5, 100, range: 10, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 2500, color: 0x403d3d, coolDown: 3000)
                    )
                )
            )
            .Init("Corrupted Knight",
                new State(
                    new ScaleHP(1100, 0, true, 15, 1),
                    new State("Waiting",
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Follow(0.7, 14, 0),
                        new Shoot(15, count: 4, shootAngle: 90, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(3000, "Jump")
                    ),
                    new State("Jump",
                        new Follow(1.2, 14, 0),
                        new Shoot(15, count: 5, shootAngle: 6, projectileIndex: 0, coolDown: 1750),
                        new TimedTransition(4000, "Waiting")
                    )
                )
            )
            .Init("Stinging Insect of Oryx",
                new State(
                    new ScaleHP(1050, 0, true, 15, 1),
                    new State("Attack",
                        new ReproduceChildren(6, 0, 600, "Maggot of Oryx"),
                        new StayCloseToSpawn(0.3, range: 2),
                        new Wander(0.1),
                        new Shoot(15, count: 3, shootAngle: 13, projectileIndex: 0, coolDown: 1600)
                    )
                )
            )
            .Init("Insect God Minion",
                new State(
                    new ScaleHP(500, 0, true, 15, 1),
                    new State("Attack",
                        new Orbit(0.5, 2, target: "The Insect God", acquireRange: 24, speedVariance: 1.0, radiusVariance: 2),
                        new Shoot(15, count: 2, shootAngle: 17, projectileIndex: 0, coolDown: 1000)
                    )
                )
            )
            .Init("Maggot of Oryx",
                new State(
                    new ScaleHP(250, 0, true, 15, 1),
                    new State("Attack",
                        new Orbit(0.5, 2, target: "Stinging Insect of Oryx", acquireRange: 24, speedVariance: 1.0, radiusVariance: 2),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 300)
                    )
                )
            )
            .Init("Maggot of Insect God",
                new State(
                    new ScaleHP(250, 0, true, 15, 1),
                    new State("Attack",
                        new Follow(0.4, 10, 0),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 300)
                    )
                )
            )
            .Init("Corrupted Warrior",
                new State(
                    new ScaleHP(1000, 0, true, 15, 1),
                    new State("Attack",
                        new Follow(0.8, 10, 0),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 750),
                        new Shoot(15, count: 2, shootAngle: 10, projectileIndex: 0, coolDown: 750),
                        new TimedTransition(5000, "Jump")
                    ),
                    new State("Jump",
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Charge(speed: 3, range: 16, coolDown: 750),
                        new Shoot(15, count: 12, shootAngle: 30, projectileIndex: 2, coolDown: 1500),
                        new TimedTransition(3000, "Attack")
                    )
                )
            )
            .Init("Corrupted Archer",
                new State(
                    new ScaleHP(850, 0, true, 15, 1),
                    new State("Attack",
                        new Follow(0.7, 10, 0),
                        new Shoot(15, count: 2, shootAngle: 6, projectileIndex: 0, coolDown: 500),
                        new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 0, coolDown: 600),
                        new Shoot(15, count: 4, shootAngle: 10, projectileIndex: 0, coolDown: 700),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 2500)
                    )
                )
            )
            .Init("Corrupted Mage",
                new State(
                    new ScaleHP(790, 0, true, 15, 1),
                    new State("Attack",
                        new StayCloseToSpawn(0.3, range: 2),
                        new Wander(0.1),
                        new ReproduceChildren(99, 0, 4000, "Corrupted Mage Bomb"),
                        new Shoot(15, count: 2, shootAngle: 0, projectileIndex: 0, coolDown: 700)
                    )
                )
            )
            .Init("Corrupted Mage Bomb",
                new State(
                    new State("Charge",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Follow(1.6, 15, 0),
                        new Shoot(15, count: 2, shootAngle: 0, projectileIndex: 0, coolDown: 900),
                        new TimedTransition(2000, "Explode")
                    ),
                    new State("Explode",
                        new RingAttack(20, 8, 0, projectileIndex: 0, 2, 2),
                        new Suicide()
                    )
                )
            )
            .Init("Herotrap of Oryx",
                new State(
                    new State("Waiting",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(30, 2, 0, projectileIndex: 0, 0.80, 0.80, coolDown: 90, seeInvis: true),
                        new RingAttack(30, 2, 0, projectileIndex: 0, 0.70, 0.70, coolDown: 90, seeInvis: true)
                    )
                )
            )
            .Init("The Insect God",
                new State(
                    new HPScale(25),
                    new State("Activate",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(7, "Start")
                    ),
                    new State("Start",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new StayCloseToSpawn(0.3, range: 3),
                        new Wander(0.1),
                        new ReproduceChildren(6, 0, 1000, "Insect God Minion"),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 1500),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 1500),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 2, coolDown: 1500),
                        new TimedTransition(12000, "Back")
                    ),
                    new State("Back",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new ReturnToSpawn(speed: 1.40),
                        new TimedTransition(3000, "Wings")
                    ),
                    new State("Wings",
                        new RingAttack(20, 2, 0, projectileIndex: 3, 0.8, 0.8, coolDown: 100, seeInvis: true),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 1500),
                        new HpLessTransition(0.80, "Eggs")
                    ),
                    new State("Eggs",
                        new Shoot(15, count: 2, shootAngle: 24, projectileIndex: 4, coolDown: 5500, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 0, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 30, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 60, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 90, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 120, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 150, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 180, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 210, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 240, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 270, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 300, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 330, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 9, fixedAngle: 360, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 4200),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 0, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 30, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 60, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 90, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 120, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 150, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 180, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 210, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 240, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 270, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 300, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 330, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new Grenade(2.0, 200, range: 3, fixedAngle: 360, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x66d01a, coolDown: 6500),
                        new HpLessTransition(0.60, "Maggots")
                    ),
                    new State("Maggots",
                        new ReproduceChildren(7, 0, 1500, "Maggot of Insect God"),
                        new Shoot(15, count: 8, shootAngle: 45, projectileIndex: 4, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new Grenade(2.5, 200, range: 9, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0xff0000, coolDown: 5000),
                        new HpLessTransition(0.40, "Acid")
                    ),
                    new State("Acid",
                        new Shoot(15, count: 4, shootAngle: 16, projectileIndex: 5, coolDown: 1000),
                        new Shoot(15, count: 3, shootAngle: 9, fixedAngle: 0, rotateAngle: 45, projectileIndex: 3, coolDown: 2500),
                        new Shoot(15, count: 3, shootAngle: 9, fixedAngle: 90, rotateAngle: 45, projectileIndex: 3, coolDown: 2500),
                        new Shoot(15, count: 3, shootAngle: 9, fixedAngle: 180, rotateAngle: 45, projectileIndex: 3, coolDown: 2500),
                        new Shoot(15, count: 3, shootAngle: 9, fixedAngle: 270, rotateAngle: 45, projectileIndex: 3, coolDown: 2500),
                        new HpLessTransition(0.20, "Final")
                    ),
                    new State("Final",
                        new RemoveObjectOnDeath("Cthu Gate", 20),
                        new Shoot(15, count: 4, shootAngle: 16, projectileIndex: 5, coolDown: 1000),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 0, rotateAngle: 45, projectileIndex: 4, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 90, rotateAngle: 45, projectileIndex: 4, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 180, rotateAngle: 45, projectileIndex: 4, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45),
                        new Shoot(15, count: 1, shootAngle: 0, fixedAngle: 270, rotateAngle: 45, projectileIndex: 4, coolDown: 6000, hasExplodingShots: true, explodeShotIndex: 5, explodeCount: 8, explodeAngle: 45)
                    )
                ),
                new Threshold(0.001,
                    LootTemplates.StrongerDrop()
                    ),
                    new Threshold(0.0001,
                        new ItemLoot("Attack Fragment", 0.05),
                        new ItemLoot("Speed Fragment", 0.05),
                        new ItemLoot("Potion Tablet", 0.5),
                        new ItemLoot("Potion of Speed", 1),
                        new ItemLoot("Potion of Attack", 1),
                        new ItemLoot("Darksteel Lootbox", 0.1)
                    ),
                new Threshold(0.005,
                    new ItemLoot("Winged Dermis", 0.02),
                    new ItemLoot("Abhorrent Shiv", 0.02)
                    ),
                new Threshold(0.02,
                    new ItemLoot("Arrows of Demise", 0.005),
                    new ItemLoot("Potion of Life", 0.75),
                    new ItemLoot("Potion of Mana", 0.75),
                    new ItemLoot("Potion of Critical Hit", 0.375),
                    new ItemLoot("Potion of Critical Damage", 0.75)
                    )
            )
            .Init("Skull of Despair",
                new State(
                    new State("ready",
                        new Taunt("*sobs*"),
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 150, seeInvis: true)
                        ),
                    new State("fasterattack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.35, 0.35, coolDown: 100, seeInvis: true)
                        ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                    )
                )
            .Init("Skull of Anger",
                new State(
                    new State("ready",
                        new Taunt("HEHE"),
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        ),
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 150, seeInvis: true)
                        ),
                    new State("fasterattack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.35, 0.35, coolDown: 100, seeInvis: true)
                        ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                    )
                )
            .Init("Oryx the Mad God 1",
                new State(
                    new DropPortalOnDeath("Wine Cellar Portal", 100, timeout: 120),
                    new HpLessTransition(.2, "rage"),
                    new State("Slow",
                        new Taunt("Fools! I still have {HP} hitpoints!"),
                        new Spawn("Minion of Oryx", 5, 0, 350000),
                        new Reproduce("Minion of Oryx", 10, 5, 1500),
                        new Shoot(25, 4, 10, 4, coolDown: 1000),
                        new TimedTransition(20000, "Dance 1")
                        ),
                    new State("Dance 1",
                        new Flash(0xf389E13, 0.5, 60),
                        new Taunt("BE SILENT!!!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(50, 8, projectileIndex: 6, coolDown: 700, coolDownOffset: 200),
                        new TossObject("Ring Element", 9, 24, 320000),
                        new TossObject("Ring Element", 9, 48, 320000),
                        new TossObject("Ring Element", 9, 72, 320000),
                        new TossObject("Ring Element", 9, 96, 320000),
                        new TossObject("Ring Element", 9, 120, 320000),
                        new TossObject("Ring Element", 9, 144, 320000),
                        new TossObject("Ring Element", 9, 168, 320000),
                        new TossObject("Ring Element", 9, 192, 320000),
                        new TossObject("Ring Element", 9, 216, 320000),
                        new TossObject("Ring Element", 9, 240, 320000),
                        new TossObject("Ring Element", 9, 264, 320000),
                        new TossObject("Ring Element", 9, 288, 320000),
                        new TossObject("Ring Element", 9, 312, 320000),
                        new TossObject("Ring Element", 9, 336, 320000),
                        new TossObject("Ring Element", 9, 360, 320000),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        //new Grenade(radius: 4, damage: 150, fixedAngle: new Random().Next(0, 359), range: 5, coolDown: 2000),
                        //new Grenade(radius: 4, damage: 150, fixedAngle: new Random().Next(0, 359), range: 5, coolDown: 2000),
                        //new Grenade(radius: 4, damage: 150, fixedAngle: new Random().Next(0, 359), range: 5, coolDown: 2000),
                        new TimedTransition(25000, "artifacts")
                        ),
                    new State("artifacts",
                        new Taunt("My Artifacts will protect me!"),
                        new Flash(0xf389E13, 0.5, 60),
                        new Shoot(50, 3, projectileIndex: 9, coolDown: 1500, coolDownOffset: 200),
                        new Shoot(50, 10, projectileIndex: 8, coolDown: 2000, coolDownOffset: 200),
                        new Shoot(50, 10, projectileIndex: 7, coolDown: 500, coolDownOffset: 200),

                        //Inner Elements
                        new TossObject("Guardian Element 1", 1, 0, 90000001, 1000),
                        new TossObject("Guardian Element 1", 1, 90, 90000001, 1000),
                        new TossObject("Guardian Element 1", 1, 180, 90000001, 1000),
                        new TossObject("Guardian Element 1", 1, 270, 90000001, 1000),
                        new TossObject("Guardian Element 2", 9, 0, 90000001, 1000),
                        new TossObject("Guardian Element 2", 9, 90, 90000001, 1000),
                        new TossObject("Guardian Element 2", 9, 180, 90000001, 1000),
                        new TossObject("Guardian Element 2", 9, 270, 90000001, 1000),
                        new TimedTransition(25000, "gaze")
                        ),

        #region gaze
                    new State("gaze",
                        new Taunt("All who looks upon my face shall die."),
                        new Shoot(count: 2, coolDown: 1000, projectileIndex: 1, radius: 7, shootAngle: 10,
                            coolDownOffset: 800),
                        new TimedTransition(10000, "Dance 2")
        #endregion gaze

                        ),

        #region Dance 2
                    new State("Dance 2",
                        new Flash(0xf389E13, 0.5, 60),
                        new Taunt("Time for more dancing!"),
                        new Shoot(50, 8, projectileIndex: 6, coolDown: 700, coolDownOffset: 200),
                        new TossObject("Ring Element", 9, 24, 320000),
                        new TossObject("Ring Element", 9, 48, 320000),
                        new TossObject("Ring Element", 9, 72, 320000),
                        new TossObject("Ring Element", 9, 96, 320000),
                        new TossObject("Ring Element", 9, 120, 320000),
                        new TossObject("Ring Element", 9, 144, 320000),
                        new TossObject("Ring Element", 9, 168, 320000),
                        new TossObject("Ring Element", 9, 192, 320000),
                        new TossObject("Ring Element", 9, 216, 320000),
                        new TossObject("Ring Element", 9, 240, 320000),
                        new TossObject("Ring Element", 9, 264, 320000),
                        new TossObject("Ring Element", 9, 288, 320000),
                        new TossObject("Ring Element", 9, 312, 320000),
                        new TossObject("Ring Element", 9, 336, 320000),
                        new TossObject("Ring Element", 9, 360, 320000),
                        new TimedTransition(1000, "Dance2, 1")
                        ),
                    new State("Dance2, 1",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(0, projectileIndex: 8, count: 4, shootAngle: 90, fixedAngle: 0, coolDown: 170),
                        new TimedTransition(200, "Dance2, 2")
                        ),
                    new State("Dance2, 2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(0, projectileIndex: 8, count: 4, shootAngle: 90, fixedAngle: 30, coolDown: 170),
                        new TimedTransition(200, "Dance2, 3")
                        ),
                    new State("Dance2, 3",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(0, projectileIndex: 8, count: 4, shootAngle: 90, fixedAngle: 15, coolDown: 170),
                        new TimedTransition(200, "Dance2, 4")
                        ),
                    new State("Dance2, 4",
                        new Shoot(0, projectileIndex: 8, count: 4, shootAngle: 90, fixedAngle: 45, coolDown: 170),
                        new TimedTransition(200, "Dance2, 1")
                        ),

        #endregion Dance 2
                    new State("rage",
                        new ChangeSize(10, 200),
                        new Taunt(.3, "I HAVE HAD ENOUGH OF YOU!!!",
                            "ENOUGH!!!",
                            "DIE!!!"),
                        new Spawn("Minion of Oryx", 10, 0, 350000),
                        new Reproduce("Minion of Oryx", 10, 5, 1500),
                        new Shoot(count: 2, coolDown: 1500, projectileIndex: 1, radius: 7, shootAngle: 10,
                            coolDownOffset: 2000),
                        new Shoot(count: 5, coolDown: 1500, projectileIndex: 16, radius: 7, shootAngle: 10,
                            coolDownOffset: 2000),
                        new Follow(0.85, range: 1, coolDown: 0),
                        new Flash(0xfFF0000, 0.5, 9000001)
                        )
                    ),
                new Threshold(0.002,
                    new ItemLoot("Potion of Attack", 0.8),
                    new ItemLoot("Potion of Defense", 0.8),
                    new ItemLoot("Potion of Speed", 0.7),
                    new ItemLoot("Potion of Dexterity", 0.7),
                    new ItemLoot("Potion of Wisdom", 0.6),
                    new ItemLoot("Potion of Vitality", 0.6),
                    new ItemLoot("Potion of Life", 0.4),
                    new ItemLoot("Potion of Mana", 0.4)
                ),
                new Threshold(0.001,
                    new TierLoot(10, ItemType.Weapon, 0.07),
                    new TierLoot(11, ItemType.Weapon, 0.06),
                    new TierLoot(5, ItemType.Ability, 0.07),
                    new TierLoot(11, ItemType.Armor, 0.07),
                    new TierLoot(5, ItemType.Ring, 0.06)
                )
            )
            .Init("Ring Element",
                new State(
                    new State(
                        new Shoot(50, 12, projectileIndex: 0, coolDown: 700, coolDownOffset: 200),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TimedTransition(20000, "Despawn")
                        ),
                    new State("Despawn", //new Decay(time:0)
                        new Suicide()
                        )
                    )
            )
            .Init("Minion of Oryx",
                new State(
                    new Wander(0.4),
                    new Shoot(3, 3, 10, 0, coolDown: 1000),
                    new Shoot(3, 3, projectileIndex: 1, shootAngle: 10, coolDown: 1000)
                    ),
                new TierLoot(7, ItemType.Weapon, 0.2),
                new ItemLoot("Magic Potion", 0.03)
            )
            .Init("Guardian Element 1",
                new State(
                    new State(
                        new Orbit(1, 1, target: "Oryx the Mad God 1", radiusVariance: 0),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(25, 3, 10, 0, coolDown: 1000),
                        new TimedTransition(10000, "Grow")
                        ),
                    new State("Grow",
                        new ChangeSize(100, 200),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Orbit(1, 1, target: "Oryx the Mad God 1", radiusVariance: 0),
                        new Shoot(3, 1, 10, 0, coolDown: 700),
                        new TimedTransition(10000, "Despawn")
                        ),
                    new State("Despawn",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Orbit(1, 1, target: "Oryx the Mad God 1", radiusVariance: 0),
                        new ChangeSize(100, 100),
                        new Suicide()
                        )
                    )
            )
            .Init("Guardian Element 2",
                new State(
                    new State(
                        new Orbit(1.3, 9, target: "Oryx the Mad God 1", radiusVariance: 0),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(25, 3, 10, 0, coolDown: 1000),
                        new TimedTransition(20000, "Despawn")
                        ),
                    new State("Despawn", new Suicide()
                        )
                    )
            )
        .Init("Henchman of Oryx",
                new State(
                    new State("Attack",
                        new Prioritize(
                            new Orbit(.2, 2, target: "Oryx the Mad God 2", radiusVariance: 1),
                            new Wander(.3)
                            ),
                    new Shoot(15, predictive: 1, coolDown: 2500),
                    new Shoot(10, count: 3, shootAngle: 10, projectileIndex: 1, coolDown: 2500),
                    new Spawn("Vintner of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    //  new Spawn("Bile of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Aberrant of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Monstrosity of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Abomination of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000)
                            ),
                    new State("Suicide",
                        new Decay(0)
                             )
                            )
                            )
            .Init("Monstrosity of Oryx",
                new State(
                    new State("Wait", new PlayerWithinTransition(15, "Attack")),
                    new State("Attack",
                        new TimedTransition(10000, "Wait"),
                    new Prioritize(
                        new Orbit(.1, 6, target: "Oryx the Mad God 2", radiusVariance: 3),
                        new Follow(.1, acquireRange: 15),
                        new Wander(.2)
                        ),
                     new TossObject("Monstrosity Scarab", coolDown: 10000, range: 1, angle: 0, coolDownOffset: 1000)
                     )
                     ))
            .Init("Monstrosity Scarab",
                new State(
                    new State("Attack",
                    new State("Charge",
                        new Prioritize(
                            new Charge(range: 25, coolDown: 1000),
                            new Wander(.3)
                            ),
                        new PlayerWithinTransition(1, "Boom")
                        ),
                    new State("Boom",
                        new Shoot(1, count: 16, shootAngle: 360 / 16, fixedAngle: 0),
                        new Decay(0)
                       )
                       )
                       )
                       )
            .Init("Vintner of Oryx",
                new State(
                    new State("Attack",
                        new Prioritize(
                            new Protect(1, "Oryx the Mad God 2", protectionRange: 4, reprotectRange: 3),
                            new Charge(speed: 1, range: 15, coolDown: 2000),
                            new Protect(1, "Henchman of Oryx"),
                            new StayBack(1, 15),
                            new Wander(1)
                        ),
                        new Shoot(10, coolDown: 250)
                        )
                        ))
         .Init("Aberrant of Oryx",
            new State(
                new Prioritize(
                    new Protect(.2, "Oryx the Mad God 2"),
                    new Wander(.7)
                    ),
                new State("Wait", new PlayerWithinTransition(15, "Attack")),
                new State("Attack",
                new TimedTransition(10000, "Wait"),
                new State("Randomize",
                    new TimedTransition(100, "Toss1", randomized: true),
                    new TimedTransition(100, "Toss2", randomized: true),
                    new TimedTransition(100, "Toss3", randomized: true),
                    new TimedTransition(100, "Toss4", randomized: true),
                    new TimedTransition(100, "Toss5", randomized: true),
                    new TimedTransition(100, "Toss6", randomized: true),
                    new TimedTransition(100, "Toss7", randomized: true),
                    new TimedTransition(100, "Toss8", randomized: true)
                   ),
                new State("Toss1",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 0),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss2",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 45),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss3",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 90),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss4",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 135),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss5",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 180),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss6",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 225),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss7",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 270),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss8",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 315),
                    new TimedTransition(4900, "Randomize")
                    ))
                    ))
        .Init("Aberrant Blaster",
            new State(
                new State("Wait",
                    new PlayerWithinTransition(3, "Boom")
                    ),
                new State("Boom",
                    new Shoot(10, count: 5, shootAngle: 7),
                    new Decay(0)
                    )
                    )
                    )
        .Init("Bile of Oryx",
            new State(
                new Prioritize(
                    new Protect(.4, "Oryx the Mad God 2", protectionRange: 5, reprotectRange: 4),
                    new Wander(.5)
                    )//,
                     //new Spawn("Purple Goo", maxChildren: 20, initialSpawn: 0, coolDown: 1000)
                )
                )
        .Init("Abomination of Oryx",
            new State(
                new State("Shoot",
                    new Shoot(1, 3, shootAngle: 5, projectileIndex: 0),
                    new Shoot(1, 5, shootAngle: 5, projectileIndex: 1),
                    new Shoot(1, 7, shootAngle: 5, projectileIndex: 2),
                    new Shoot(1, 5, shootAngle: 5, projectileIndex: 3),
                    new Shoot(1, 3, shootAngle: 5, projectileIndex: 4),
                    new TimedTransition(1000, "Wait")
                    ),
                new State("Wait",
                    new PlayerWithinTransition(2, "Shoot")),
                new Prioritize(
                    new Charge(3, 10, 3000),
                    new Wander(.5))
                    )
                    );
    }
}
