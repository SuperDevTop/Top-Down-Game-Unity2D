using wServer.logic.behaviors;
using wServer.logic.transitions;
using wServer.logic.loot;
using common.resources;
//by ???, GhostMaree
namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ WoodlandLabyrinth = () => Behav()
        .Init("Murderous Megamoth",
             new State(
                 new HPScale(15),
                 new Prioritize(
                     new Follow(2.5, 10),
                     new Wander(0.2)
                 ),
                 new Reproduce("Mini Larva", coolDown: 500, densityMax: 6, densityRadius: 4),
                 new Shoot(25, projectileIndex: 0, count: 2, shootAngle: 10, coolDown: 500, coolDownOffset: 500),
                 new Shoot(25, projectileIndex: 1, count: 1, shootAngle: 0, coolDown: 500, coolDownOffset: 500)
             ),
             new Threshold(0.0001,
                 new ItemLoot("Vitality Fragment", 0.05),
                 new ItemLoot("Attack Fragment", 0.05),
                 new ItemLoot("Life Fragment", 0.05),
                 new ItemLoot("Potion of Vitality", 1),
                 new ItemLoot("Potion of Attack", 1),
                 new ItemLoot("Potion Tablet", 1),
                 new ItemLoot("Potion of Life", 0.5),
                 new ItemLoot("Shard of Evolution", 0.013),
                 new ItemLoot("Woodland Labyrinth Key", 0.008),
                 new ItemLoot("Photosynthetic Hide", 0.007),
                 new ItemLoot("Flower Circlet", 0.007),
                 new ItemLoot("Bud of Life Rune", 0.025)
             ),
             new Threshold(0.03,
                 new ItemLoot("Leaf Bow", 0.005),
                 new ItemLoot("Blossom Trapper", 0.005)
             )
         )
        .Init("Mini Larva",
            new State(
                new Wander(0.1),
                new Protect(1, "Murderous Megamoth", 100, 5, 5),
                new Shoot(10, count: 4, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2)
            )
         )
        .Init("Epic Mama Megamoth",
            new State(
                new HPScale(15),
                new TransformOnDeath("Murderous Megamoth"),
                new State("idle",
                    new HpLessTransition(.3, "change"),
                    new Prioritize(
                        new Follow(2.0, 10),
                        new Wander(0.2)
                    ),
                    new Reproduce("Woodland Mini Megamoth", coolDown: 500, densityMax: 8, densityRadius: 5),
                    new Shoot(25, projectileIndex: 0, count: 3, shootAngle: 10, coolDown: 400)
                ),
                new State("change",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Flash(0xfFF0000, 1, 900001),
                    new Decay(3000)
                )
            )
        )
        .Init("Woodland Mini Megamoth",
            new State(
                new Wander(0.1),
                new Shoot(25, projectileIndex: 0, count: 1, shootAngle: 0),
                new Protect(1, "Epic Mama Megamoth", 20, 5, 1)
            )
         )
        .Init("Epic Larva",
            new State(
                new HPScale(15),
                new TransformOnDeath("Epic Mama Megamoth"),
                new State("shoot1",
                    new Prioritize(
                        new Follow(0.75, 8, 1),
                        new Wander(0.25)
                    ),
                    new HpLessTransition(.3, "change"),
                    new Shoot(0, 3, shootAngle: 15, projectileIndex: 0, fixedAngle: 45, coolDownOffset: 1250),
                    new Shoot(0, 3, shootAngle: 15, projectileIndex: 0, fixedAngle: 135, coolDownOffset: 1250),
                    new Shoot(0, 3, shootAngle: 15, projectileIndex: 0, fixedAngle: 225, coolDownOffset: 1250),
                    new Shoot(0, 3, shootAngle: 15, projectileIndex: 0, fixedAngle: 315, coolDownOffset: 1250),
                    new Shoot(10, count: 8, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2, coolDownOffset: 1500),
                    new Shoot(10, count: 4, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2, coolDownOffset: 2000)
                ),
                new State("change",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Flash(0xfFF0000, 1, 900001),
                    new Decay(3000)
                )
            )
        )
        .Init("Woodland Ultimate Squirrel",
            new State(
                new Prioritize(
                    new Follow(0.4, 6, 1, -1, 0),
                    new Wander(0.3)
                    ),
                new Shoot(radius: 7, count: 1, projectileIndex: 0, shootAngle: 20, coolDown: 2000)
                ),
                new Threshold(0.025,
                    new ItemLoot("Speed Sprout", 0.05)
                )
            )
        .Init("Woodland Goblin Mage",
            new State(
                new Prioritize(
                    new Wander(0.4),
                    new Shoot(radius: 10, count: 2, projectileIndex: 0, predictive: 1, coolDown: 500, shootAngle: 2)
                    )
                ),
                new Threshold(0.025,
                    new ItemLoot("Speed Sprout", 0.05)
                )
            )
        .Init("Woodland Goblin",
            new State(
                new Prioritize(
                    new Wander(0.4),
                    new Follow(0.7, 10, 3, -1, 0),
                    new Shoot(radius: 4, count: 1, projectileIndex: 0, coolDown: 500)
                    )
                ),
                new Threshold(0.025,
                    new ItemLoot("Speed Sprout", 0.05)
                )
            )
        .Init("Wooland Armor Squirrel",
            new State(
                new Prioritize(
                    new Follow(0.6, 6, 1, -1, 0),
                    new Wander(0.7),
                    new Shoot(radius: 7, count: 3, projectileIndex: 0, predictive: 1, coolDown: 1000, shootAngle: 15)
                    )
                ),
                new Threshold(0.025,
                    new ItemLoot("Speed Sprout", 0.05)
                )
            )
        .Init("Woodland Silence Turret",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new State("idle",
                    new Shoot(10, count: 8, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2)
                    )
                )
            )
        .Init("Woodland Weakness Turret",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new State("idle",
                    new Shoot(10, count: 8, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2)
                    )
                )
            )
        .Init("Woodland Paralyze Turret",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new State("idle",
                    new Shoot(10, count: 8, projectileIndex: 0, fixedAngle: fixedAngle_RingAttack2)
                    )
                )
            );
                 }
}
