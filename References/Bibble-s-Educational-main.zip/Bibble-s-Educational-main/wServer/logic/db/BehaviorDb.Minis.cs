﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Minis = () => Behav()
        .Init("Turkhimera",
            new State(
                new HPScale(30),
                new State("Idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(8, "Start")
                    ),
                new State("Start",
                    new Wander(0.4),
                    new StayCloseToSpawn(0.5, 5),
                    new Shoot(10, 5, 12, 0, coolDown: 1200, predictive: 1),
                    new Shoot(10, 5, 12, 0, coolDown: 1200, predictive: 1, angleOffset: 180),
                    new Shoot(10, 4, 3, 1, coolDown: 100),
                    new HpLessTransition(0.66, "Next")
                    ),
                new State("Next",
                    new Follow(0.5, 10, 0, 0, 0),
                    new Shoot(10, 20, 18, 1, coolDown: 1500),
                    new Shoot(10, 3, 10, 2, coolDown: 1000),
                    new Shoot(10, 3, 15, 0, coolDown: 1000, coolDownOffset: 200),
                    new HpLessTransition(0.33, "Prep")
                    ),
                new State("Prep",
                    new ReturnToSpawn(1),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TimedTransition(4000, "Rage")
                    ),
                new State("Rage",
                    new Shoot(10, 1, 0, 0, 0, coolDown: 1200),
                    new Shoot(10, 1, 0, 0, 180, coolDown: 1200),
                    new Shoot(10, 3, 10, 0, 0, coolDown: 1200, coolDownOffset: 200),
                    new Shoot(10, 3, 10, 0, 180, coolDown: 1200, coolDownOffset: 200),
                    new Shoot(10, 5, 12, 0, 0, coolDown: 1200, coolDownOffset: 400),
                    new Shoot(10, 5, 12, 0, 180, coolDown: 1200, coolDownOffset: 400),
                    new Shoot(10, 1, 0, 0, 90, coolDown: 1200, coolDownOffset: 600),
                    new Shoot(10, 1, 0, 0, 270, coolDown: 1200, coolDownOffset: 600),
                    new Shoot(10, 3, 10, 0, 90, coolDown: 1200, coolDownOffset: 800),
                    new Shoot(10, 3, 10, 0, 270, coolDown: 1200, coolDownOffset: 800),
                    new Shoot(10, 5, 12, 0, 90, coolDown: 1200, coolDownOffset: 1000),
                    new Shoot(10, 5, 12, 0, 270, coolDown: 1200, coolDownOffset: 1000),
                    new Shoot(10, 2, 3, 1, coolDown: 100),
                    new TimedTransition(8000, "RageAlt")
                    ),
                new State("RageAlt",
                    new Follow(0.5, 10, 0, 0, 0),
                    new Shoot(10, 10, 36, 0, coolDown: 1500),
                    new Shoot(10, 5, 10, 2, coolDown: 1000),
                    new Shoot(10, 4, 3, 1, coolDown: 100),
                    new TimedTransition(8000, "Prep")
                    )
                ),
            new Threshold(0.001,
                LootTemplates.MiniDrop()
                ),
            new Threshold(0.01,
                new ItemLoot("Turkey Leg of Doom", 0.005),
                new ItemLoot("Spooky Tablet", 0.2)
                )
            )
        .Init("Luca",
            new State(
                new HPScale(30),
                new State("Idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(8, "Start")
                    ),
                new State("Start",
                    new Wander(0.4),
                    new StayCloseToSpawn(0.5, 5),
                    new Shoot(10, 3, 12, 0, coolDown: 1500),
                    new Shoot(10, 8, 45, 2, coolDown: 500, angleOffset: 22),
                    new Shoot(10, 2, 1, 1, coolDown: 1000),
                    new HpLessTransition(0.66, "Prep")
                    ),
                new State("Prep",
                    new ReturnToSpawn(1),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TimedTransition(4000, "Transform")
                    ),
                new State("Transform",
                    new Transform("Luca SwordAnim")
                    )
                )
            )
        .Init("Luca SwordAnim",
            new State(
                new State("this",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new TimedTransition(2500, "Transform (again)")
                    ),
                new State("Transform (again)",
                    new Transform("Luca Second")
                    )
                ) 
            )
        .Init("Luca Second",
            new State(
                new HPScale(30),
                new State("Invis",
                    new SetAltTexture(0),
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Follow(1, 10, 2.5, 0, 0),
                    new Shoot(10, 8, 45, 3, coolDown: 1000),
                    new Shoot(10, 3, 10, 1, coolDown: 1000),
                    new TimedTransition(4000, "Vulnerable")
                    ),
                new State("Vulnerable",
                    new SetAltTexture(1),
                    new Shoot(10, 4, 90, 2, 0, coolDown: 1600),
                    new Shoot(10, 4, 90, 2, 11, coolDown: 1600, coolDownOffset: 200),
                    new Shoot(10, 4, 90, 2, 22, coolDown: 1600, coolDownOffset: 400),
                    new Shoot(10, 4, 90, 2, 33, coolDown: 1600, coolDownOffset: 600),
                    new Shoot(10, 4, 90, 2, 44, coolDown: 1600, coolDownOffset: 800),
                    new Shoot(10, 4, 90, 2, 55, coolDown: 1600, coolDownOffset: 1000),
                    new Shoot(10, 4, 90, 2, 66, coolDown: 1600, coolDownOffset: 1200),
                    new Shoot(10, 4, 90, 2, 77, coolDown: 1600, coolDownOffset: 1400),
                    new Shoot(10, 3, 15, 0, coolDown: 1000, predictive: 1),
                    new TimedTransition(4000, "Invis"),
                    new HpLessTransition(0.5, "Rage")
                    ),
                new State("Rage",
                    new SetAltTexture(1),
                    new Spawn("Luca Orbital", 1),
                    new Follow(0.5, 10, 1, 0, 0),
                    new Shoot(10, 12, 30, 1, 0, coolDown: 2000),
                    new Shoot(10, 12, 30, 1, 15, coolDown: 2000, coolDownOffset: 300),
                    new Shoot(10, 5, 15, 2, coolDown: 1200), 
                    new Shoot(10, 2, 25, 3, coolDown: 1800)
                    )
                ),
            new Threshold(0.001,
                    LootTemplates.MiniDrop()
                    ),
            new Threshold(0.01,
                new ItemLoot("Peril", 0.004),
                new ItemLoot("Anguish", 0.004),
                new ItemLoot("Agony", 0.008),
                new ItemLoot("Spooky Tablet", 0.2)
                )
            )
        .Init("Luca Orbital",
            new State(
                new State("Grace",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Orbit(1.5, 8, 10, "Luca Second"),
                    new TimedTransition(2000, "Active")
                    ),
                new State("Active",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Orbit(1.5, 8, 10, "Luca Second"),
                    new Shoot(10, 8, 45, 0, coolDown: 1500),
                    new Shoot(10, 3, 12, 1, coolDown: 1500, coolDownOffset: 200),
                    new EntityNotExistsTransition("Luca Second", 12, "Dead")
                    ),
                new State("Dead",
                    new Suicide()
                    )
                )
            )
        .Init("DR Flying Sword",
            new State(
                new State("Constant",
                    new Follow(0.5, 10, 1, 0, 0),
                    new Shoot(10, 3, 8, 0, coolDown: 500),
                    new Shoot(10, 4, 16, 2, coolDown: 750),
                    new Shoot(10, 1, 0, 1, coolDown: 1250, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 4, explodeAngle: 90)
                    )
                ),
            new Threshold(0.01, 
                new ItemLoot("Spooky Tablet", 0.02)
                )
            )
        .Init("DR Succubus",
            new State(
                new State("Constant",
                    new Wander(0.3),
                    new Shoot(10, 4, 90, 0, 0, coolDown: 1500),
                    new Shoot(10, 4, 90, 1, 0, coolDown: 1500, coolDownOffset: 100),
                    new Shoot(10, 4, 90, 1, 0, coolDown: 1500, coolDownOffset: 200),
                    new Shoot(10, 4, 90, 1, 0, coolDown: 1500, coolDownOffset: 300),
                    new Shoot(10, 4, 90, 1, 0, coolDown: 1500, coolDownOffset: 400),
                    new Shoot(10, 3, 12, 2, 0, coolDown: 1000)
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.02)
                )
            )
        .Init("DR Werewolf",
            new State(
                new State("Shotgun",
                    new Shoot(10, 1, 0, 1, coolDown: 1200, coolDownOffset: 400),
                    new Shoot(10, 2, 8, 1, coolDown: 1200, coolDownOffset: 300),
                    new Shoot(10, 3, 12, 2, coolDown: 1200, coolDownOffset: 200),
                    new Shoot(10, 2, 15, 0, coolDown: 1200),
                    new TimedTransition(3000, "Wander")
                    ),
                new State("Wander",
                    new Wander(0.2),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TimedTransition(200, "Shotgun")
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.02)
                )
            )
        .Init("DR Tarantula",
            new State(
                new State("Constant",
                    new Follow(1, 10, 1, 0, 0),
                    new Shoot(10, 12, 30, 0, coolDown: 1000)
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.01)
                )
            )
        .Init("DR Imp",
            new State(
                new State("Constant",
                    new Follow(0.1, 10, 1, 0, 0),
                    new Shoot(10, 4, 90, 0, coolDown: 1000),
                    new Shoot(10, 4, 90, 18, coolDown: 1000, coolDownOffset: 200),
                    new Shoot(10, 4, 90, 36, coolDown: 1000, coolDownOffset: 400),
                    new Shoot(10, 4, 90, 54, coolDown: 1000, coolDownOffset: 600),
                    new Shoot(10, 4, 90, 72, coolDown: 1000, coolDownOffset: 800)
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.01)
                )
            )
        .Init("DR Rolling Pumpkin",
            new State(
                new State("Follow",
                    new Follow(1, 10, 1, 0, 0),
                    new PlayerWithinTransition(1, "Explode")
                    ),
                new State("Explode",
                    new Shoot(10, 12, 30, 0, coolDown: 1000),
                    new Decay(0)
                    )
                )
            )
        .Init("DR Flying Bat",
            new State(
                new State("Constant",
                    new Follow(1, 10, 1, 0, 0),
                    new Shoot(10, 12, 30, 0, coolDown: 1000)
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.01)
                )
            )
        .Init("DR Skeletal Warrior",
            new State(
                new State("Constant",
                    new Wander(0.2),
                    new Shoot(10, 1, 0, 0, coolDown: 1500),
                    new Shoot(10, 1, 0, 0, coolDown: 1500, coolDownOffset: 200),
                    new Shoot(10, 1, 0, 0, coolDown: 1500, coolDownOffset: 400),
                    new Shoot(10, 3, 12, 0, coolDown: 1500, coolDownOffset: 600)
                    )
                ),
            new Threshold(0.01,
                new ItemLoot("Spooky Tablet", 0.01)
                )
            );
    }
}
