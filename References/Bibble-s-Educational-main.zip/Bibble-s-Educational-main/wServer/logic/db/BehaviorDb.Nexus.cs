﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Nexus = () => Behav()
            .Init("Nexus Crier",
            new State(
                new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(0),
                        new PlayerWithinTransition(10, "PreTalk")
                        ),
                new State("PreTalk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(10000, "Talk")
                        ),
                new State("Talk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new TimedRandomTransition(15000, true, "Greetings"),
                    new TimedRandomTransition(15000, true, "Market"),
                    new TimedRandomTransition(15000, true, "Oryx"),
                    new TimedRandomTransition(15000, true, "Walk Around"),
                    new TimedRandomTransition(15000, true, "Raid")
                        ),
                new State("Greetings",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("Hey, welcome to Isle of Mythos!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Market",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("You should go check out the market. Plenty of good stuff and great prices too!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Walk Around",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("Walk around the nexus when you get the chance!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Oryx",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("Go out there and beat that Mad God!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Raid",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("Be careful out there! It's a dangerous world!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("PortalNPC",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new SetAltTexture(1),
                    new Taunt("You should go talk with that portal guy. I'm sure he has something important to say."),
                    new TimedTransition(5000, "Wait")
                            )
                        )
                    )
        .Init("Forgotten Knight",
            new State(
                new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(8, "PreTalk")
                        ),
                new State("PreTalk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(5000, "Talk")
                        ),
                new State("Talk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new TimedRandomTransition(6000, true, "Line1"),
                    new TimedRandomTransition(6000, true, "Line2")
                        ),
                new State("Line1",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("All dead.."),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Line2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Couldn't save them.."),
                    new TimedTransition(5000, "Wait")
                    )
                 )
              )
        .Init("Forgotten Rogue",
            new State(
                new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(8, "PreTalk")
                        ),
                new State("PreTalk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(5000, "Talk")
                        ),
                new State("Talk",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new TimedRandomTransition(6000, true, "Line1"),
                    new TimedRandomTransition(6000, true, "Line2")
                        ),
                new State("Line1",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("..."),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Line2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Leave me alone please..."),
                    new TimedTransition(5000, "Wait")
                    )
                 )
              )
        .Init("Titan, The Mountain Splitter",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new State("Wait",
                    new PlayerTextTransition("Greet", "hi"),
                    new PlayerTextTransition("Greet", "hello"),
                    new PlayerTextTransition("Where", "where am i"),
                    new PlayerTextTransition("Where", "where is this"),
                    new PlayerTextTransition("Where", "where are we")
                    ),
                new State("Greet",
                    new Taunt("Hello there! Welcome to the nexus.", "Hello Hero! While fighting, make sure to keep an eye on your arm. Hahaha!"),
                    new TimedTransition(5000, "Wait")
                    ),
                new State("Where",
                    new Taunt("Well we are in the nexus!"),
                    new TimedTransition(3000, "Where2")
                    ),
                new State("Where2",
                    new Taunt("This place is where heroes like you come after death."),
                    new TimedTransition(4000, "Where3")
                    ),
                new State("Where3",
                    new Taunt("I hope you can help us fight back those bastard dark gods."),
                    new TimedTransition(4000, "Wait")
                    )
                )
            )
        .Init("Sheep",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Prioritize(
                        new StayCloseToSpawn(0.3, range: 3),
                        new Wander(0.2)
                    ),
                    new State("Exist",
                        new TimedTransition(10000, "Baa")
                        ),
                    new State("Baa",
                        new Taunt("baaa"),
                        new TimedTransition(5000, "Exist")
                        )
                    )
                )
        .Init("White Fountain",
                new State(
                    new HealPlayer(12, 500)
                )
            )
        .Init("Nexus Huge Tree",
            new State(
                new State("Exist",
                        new ConditionalEffect(ConditionEffectIndex.Invincible)
                        )
                   )

             )
        .Init("BudofLife",
            new State(
                new State("Exist",
                    new HealPlayer(6, 1000, 25),
                    new HealPlayerMP(6, 1000, 10),
                    new Decay(5001)
                    )
                )
            )
        .Init("Terraprisma",
                new State(
                    new PetFollow()
                )
            )
        .Init("Wheelchair",
                new State(
                    new PetFollow()
                )
            )
        .Init("Gamer Girl",
                new State(
                    new PetFollow()
                )
            )
        .Init("Cirno",
                new State(
                    new PetFollow()
                )
            )
        .Init("Yoru the Blade of the Fallen",
                new State(
                    new PetFollow()
                )
            )
        .Init("Pepe Dance",
                new State(
                    new PetFollow()
                )
            )
        .Init("Decaying Ancient",
                new State(
                    new PetFollow()
                )
            )
        .Init("Deadpool",
                new State(
                    new PetFollow()
                )
            )
        .Init("Dragun:o",
                new State(
                    new PetFollow()
                )
            )
        .Init("Smelter of The Onyx Valley",
                new State(
                    new PetFollow()
                )
            )
        .Init("Dark Horse",
                new State(
                    new PetFollow()
                )
            )
        .Init("SUS",
                new State(
                    new PetFollow()
                )
            )
        .Init("Jiggy",
                new State(
                    new PetFollow()
                )
            )
        .Init("Ohwy",
                new State(
                    new PetFollow()
                )
            )
        .Init("Tungsten Bat",
                new State(
                    new PetFollow()
                )
            )
        .Init("Icy Scythe",
                new State(
                    new PetFollow()
                )
            )
        .Init("Creepy Joey",
                new State(
                    new PetFollow()
                )
            )
        .Init("Lil King Slime",
                new State(
                    new PetFollow()
                )
            )
        .Init("Kino Konoko",
                new State(
                    new PetFollow()
                )
            )
        .Init("Kino Mushy",
                new State(
                    new PetFollow()
                )
            )
        .Init("Ultra Instinct Goku",
                new State(
                    new PetFollow()
                )
            )
        .Init("Nine and a half tales",
                new State(
                    new PetFollow()
                )
            )
        .Init("Rem the Maiden",
                new State(
                    new PetFollow()
                )
            )
        .Init("Rainbow Arcanuo",
                new State(
                    new PetFollow()
                )
            )
        .Init("Kurama",
                new State(
                    new PetFollow()
                )
            )

                .InitMany("Black Cat", "Snowman", name =>
                new State(
                    new PetFollow()
                    )
            );

    }
}