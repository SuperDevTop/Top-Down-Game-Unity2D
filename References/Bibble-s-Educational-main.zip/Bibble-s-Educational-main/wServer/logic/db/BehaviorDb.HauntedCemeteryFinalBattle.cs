using common.resources;
using wServer.logic.behaviors;
using wServer.logic.transitions;
using wServer.logic.loot;
//by GhostMaree
namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ HauntedCemeteryFinalBattle = () => Behav()
            .Init("Zombie Hulk",
                new State(
                    new Wander(speed: 0.35),
                    new State("Attack2",
                        new SetAltTexture(0),
                        new StayBack(speed: 0.55, distance: 7, entity: null),
                        new Follow(speed: 0.3, acquireRange: 11, range: 5),
                        new Shoot(radius: 10, count: 1, projectileIndex: 1, coolDown: 400, coolDownOffset: 500),
                        new TimedRandomTransition(3000, true, "Attack1", "Attack3")
                    ),
                    new State("Attack1",
                        new SetAltTexture(1),
                        new Shoot(radius: 8, count: 3, shootAngle: 40, projectileIndex: 0, coolDown: 400, coolDownOffset: 250),
                        new Shoot(radius: 8, count: 2, shootAngle: 60, projectileIndex: 0, coolDown: 400, coolDownOffset: 250),
                        new Charge(speed: 1.1, range: 11, coolDown: 200),
                        new TimedRandomTransition(3000, true, "Attack2", "Attack3")
                    ),
                    new State("Attack3",
                        new SetAltTexture(0),
                        new Wander(speed: 0.4),
                        new Shoot(radius: 10, count: 3, shootAngle: 30, projectileIndex: 1, coolDown: 400, coolDownOffset: 500),
                        new TimedRandomTransition(3000, true, "Attack1", "Attack2")
                    )
                ),
                new Threshold(0.01,
                    new TierLoot(5, ItemType.Weapon, 0.4),
                    new TierLoot(6, ItemType.Weapon, 0.4),
                    new TierLoot(5, ItemType.Armor, 0.4),
                    new TierLoot(6, ItemType.Armor, 0.4),
                    new TierLoot(3, ItemType.Ring, 0.25)
                )
            )
            .Init("Classic Ghost",
                new State(
                    new Wander(speed: 0.4),
                    new Follow(speed: 0.55, acquireRange: 10, range: 3, duration: 1000, coolDown: 2000),
                    new Orbit(speed: 0.55, radius: 4, acquireRange: 7, target: null),
                    new Shoot(radius: 5, count: 4, shootAngle: 16, projectileIndex: 0, coolDown: 1000, coolDownOffset: 0)
                )
            )
            .Init("Werewolf",
                new State(
                    new Spawn(children: "Mini Werewolf", maxChildren: 2, initialSpawn: 0, coolDown: 5400, givesNoXp: false),
                    new Spawn(children: "Mini Werewolf", maxChildren: 3, initialSpawn: 0, coolDown: 5400, givesNoXp: false),
                    new StayCloseToSpawn(speed: 0.8, range: 6),
                    new State("Circling",
                        new Shoot(radius: 10, count: 3, shootAngle: 20, projectileIndex: 0, coolDown: 1600),
                        new Prioritize(
                            new Orbit(speed: 0.4, radius: 5.4, acquireRange: 8, target: null),
                            new Wander(speed: 0.4)
                        ),
                        new TimedTransition(time: 3400, targetState: "Engaging")
                    ),
                    new State("Engaging",
                        new Shoot(radius: 5.5, count: 5, shootAngle: 13, projectileIndex: 0, coolDown: 1600),
                        new Follow(speed: 0.6, acquireRange: 10, range: 1),
                        new TimedTransition(time: 2600, targetState: "Circling")

                    )
                )
            )
            .Init("Mini Werewolf",
                new State(
                    new Shoot(radius: 4, count: 1, projectileIndex: 0, coolDown: 1000),
                    new Prioritize(
                            new Follow(speed: 0.6, acquireRange: 15, range: 1),
                            new Protect(speed: 0.8, protectee: "Werewolf", acquireRange: 15, protectionRange: 6, reprotectRange: 3),
                            new Wander(speed: 0.4)
                    )
                )
            )
            .Init("Halloween Zombie Spawner",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new State("Leech"),
                    new State("1",
                        new Spawn("Zombie Rise", maxChildren: 1),
                        new EntityNotExistsTransition("Ghost of Skuld", 100, "2")
                    ),
                    new State("2",
                        new Suicide()
                    )
                )
            )
            .Init("Zombie Rise",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new TransformOnDeath("Blue Zombie"),
                    new State("1",
                        new SetAltTexture(1),
                        new TimedTransition(750, "2")
                    ),
                    new State("2",
                        new SetAltTexture(2),
                        new TimedTransition(750, "3")
                    ),
                    new State("3",
                        new SetAltTexture(3),
                        new TimedTransition(750, "4")
                    ),
                    new State("4",
                        new SetAltTexture(4),
                        new TimedTransition(750, "5")
                    ),
                    new State("5",
                        new SetAltTexture(5),
                        new TimedTransition(750, "6")
                    ),
                    new State("6",
                        new SetAltTexture(6),
                        new TimedTransition(750, "7")
                    ),
                    new State("7",
                        new SetAltTexture(7),
                        new TimedTransition(750, "8")
                    ),
                    new State("8",
                        new SetAltTexture(8),
                        new TimedTransition(750, "9")
                    ),
                    new State("9",
                        new SetAltTexture(9),
                        new TimedTransition(750, "10")
                    ),
                    new State("10",
                        new SetAltTexture(10),
                        new TimedTransition(750, "11")
                    ),
                    new State("11",
                        new SetAltTexture(11),
                        new TimedTransition(750, "12")
                    ),
                    new State("12",
                        new SetAltTexture(12),
                        new TimedTransition(750, "13")
                    ),
                    new State("13",
                        new SetAltTexture(13),
                        new TimedTransition(750, "14")
                    ),
                    new State("14",
                        new Suicide()
                    )
                )
            )
            .Init("Blue Zombie",
                new State(
                    new Follow(0.03, 100, 1),
                    new State("1",
                        new Shoot(10, 1, projectileIndex: 0, coolDown: 1000),
                        new EntityNotExistsTransition("Ghost of Skuld", 100, "2")
                    ),
                    new State("2",
                        new Suicide()
                    )
                )
            )
            .Init("Flying Flame Skull",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Orbit(1, 5, 20, target: "Ghost of Skuld"),
                    new State("1",
                        new Shoot(100, 10, shootAngle: 36, projectileIndex: 0, coolDown: 1000),
                        new EntityNotExistsTransition("Ghost of Skuld", 100, "2")
                    ),
                    new State("2",
                        new Suicide()
                    )
                )
            )
            ;
    }
}
