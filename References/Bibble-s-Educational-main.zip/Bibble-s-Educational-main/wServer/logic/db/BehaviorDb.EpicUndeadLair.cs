﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ EpicUndeadLair = () => Behav()
           .Init("Skeleton Rager",
                new State(
                    new HPScale(30),
                    new State("Start",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new PlayerWithinTransition(8, "Taunt")
                        ),
                    new State("Taunt",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("RAHHHH"),
                        new TimedTransition(3000, "Attack")
                        ),
                    new State("Attack",
                        new TossObject("Little Rager 1", 8, coolDown: 3000, throwEffect: true),
                        new Shoot(10, 3, 12, coolDown: 1500, projectileIndex: 0, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 4, explodeAngle: 90),
                        new RingAttack(20, 2, 0, projectileIndex: 1, 0.20, 0.2, coolDown: 170),
                        new HpLessTransition(0.60, "Attack2")
                        ),
                    new State("Attack2",
                        new TossObject("Little Rager 2", 8, coolDown: 4000, throwEffect: true),
                        new Shoot(10, 1, fixedAngle: 0, rotateAngle: 20, coolDown: 500, projectileIndex: 0, hasExplodingShots: true, explodeShotIndex: 2, explodeCount: 2, explodeAngle: 180),
                        new Shoot(10, 3, 8, coolDown: 2000, projectileIndex: 1),
                        new RingAttack(20, 12, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 4000),
                        new HpLessTransition(0.30, "Taunt2")
                        ),
                    new State("Taunt2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TossObject("Little Rager 3", 0, angle: 0, coolDown: 999999, throwEffect: true),
                        new Taunt("AHHH IT HURTSSS"),
                        new TimedTransition(3000, "Attack3")
                        ),
                    new State("Attack3",
                        new Swirl(0.8, 9, targeted: false),
                        new Shoot(10, 4, 8, coolDown: 3000, projectileIndex: 0, hasExplodingShots: true, explodeShotIndex: 2, explodeCount: 3, explodeAngle: 120),
                        new RingAttack(20, 2, 0, projectileIndex: 3, 0.3, 0.3, coolDown: 200)
                        )
                    ),
                new Threshold(0.005,
                    new ItemLoot("Wisdom Fragment", 0.005),
                    new ItemLoot("Defense Fragment", 0.005),
                    new ItemLoot("Shard of Divinity", 0.0025),
                    new ItemLoot("Potion of Wisdom", 1),
                    new ItemLoot("Potion of Defense", 1),
                    new ItemLoot("Potion Tablet", .5),
                    new ItemLoot("Phantoplasmic Slasher", 0.005),
                    new ItemLoot("Executioners Medallion", 0.005),
                    new ItemLoot("Chainmail of Rage", 0.02),
                    new ItemLoot("Phantom Pendant", 0.02),
                    new ItemLoot("Support Fragment", 0.10)
                    ),
                new Threshold(0.005,
                    LootTemplates.StrongerDrop()
                    )
                )
        .Init("Soul Collector",
                new State(
                    new HPScale(30),
                    new State("Start",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new PlayerWithinTransition(8, "Taunt")
                        ),
                    new State("Taunt",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Hmm?"),
                        new TimedTransition(3000, "Taunt2")
                        ),
                    new State("Taunt2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Did you kill rager?"),
                        new TimedTransition(3000, "Taunt3")
                        ),
                    new State("Taunt3",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Well, that's unexpected, he was a good experiment.."),
                        new TimedTransition(3000, "Taunt4")
                        ),
                    new State("Taunt4",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Good thing his new replacements came straight to me!"),
                        new TimedTransition(3000, "Attack")
                        ),
                    new State("Attack",
                        new Shoot(10, 1, 0, fixedAngle: 0, rotateAngle: 45, coolDown: 1000, projectileIndex: 1, hasExplodingShots: true, explodeShotIndex: 0, explodeCount: 4, explodeAngle: 90),
                        new RingAttack(20, 18, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 4000),
                        new RingAttack(20, 8, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 8000),
                        new RingAttack(20, 2, 0, projectileIndex: 4, 0.15, 0.15, coolDown: 75),
                        new HpLessTransition(0.80, "Talk1")
                        ),
                    new State("Talk1",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Your quite strong, looks like i'll have to put my soul on the line."),
                        new TimedTransition(4000, "Soul")
                        ),
                    new State("Soul",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new TossObject("Soul of the Collector", 3, angle: 0, coolDown: 500000, throwEffect: false),
                        new TimedTransition(4000, "Attack2")
                        ),
                    new State("Attack2",
                        new Order(25, "Soul of the Collector", "Attack"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1250),
                        new TimedTransition(14000, "Attack2.1")
                        ),
                    new State("Attack2.1",
                        new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1500)
                        )
                    ),
                new Threshold(0.005,
                    new ItemLoot("Wisdom Fragment", 0.05),
                    new ItemLoot("Defense Fragment", 0.05),
                    new ItemLoot("Shard of Divinity", 0.0025),
                    new ItemLoot("Life Fragment", 0.005),
                    new ItemLoot("Mana Fragment", 0.05),
                    new ItemLoot("Greater Potion of Wisdom", 1),
                    new ItemLoot("Greater Potion of Defense", 1),
                    new ItemLoot("Potion Tablet", 0.01),
                    new ItemLoot("Potion of Life", 0.5),
                    new ItemLoot("Potion of Mana", 0.5),
                    new ItemLoot("Doom Bow", 0.02),
                    new ItemLoot("Spectral Quiver", 0.02),
                    new ItemLoot("Ectoplasmic Hide", 0.02),
                    new ItemLoot("Soul Shredder", 0.005),
                    new ItemLoot("Eerie Scripture", 0.005),
                    new ItemLoot("Shadowbolt Wand", 0.02),
                    new ItemLoot("Wrath of The Ancients", 0.02),
                    new ItemLoot("Undead Lair Key", 0.008),
                    new ItemLoot("Treasure of Nazarick", 0.000001),
                    new ItemLoot("Support Fragment", 0.25),
                    new ItemLoot("Blood Siphon Rune", 0.025)
                    ),
                new Threshold(0.005,
                    LootTemplates.StrongerDrop()
                    )
                )
        .Init("Soul of the Collector",
                new State(
                    new State("Start",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                        ),
                    new State("Attack",
                        new Orbit(1.2, 8, 18, "Soul Collector"),
                        new RingAttack(20, 16, 0, projectileIndex: 4, 0.2, 0.2, coolDown: 1500),
                        new Shoot(10, 3, coolDown: 3000, projectileIndex: 3)
                        )
                    )
                )
        .Init("Skeleton Alchemist Black",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new Grenade(3, 175, range: 12, effect: ConditionEffectIndex.ArmorBroken, effectDuration: 3000, color: 0x000000, coolDown: 1500)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.02)
                    )
                )
        .Init("Little Rager 1",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new State("Start",
                        new Follow(0.85, 13, 0),
                        new Grenade(3.0, 150, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Dazed, effectDuration: 1500, color: 0xff0000, coolDown: 1000),
                        new TimedTransition(4500, "die")
                    ),
                    new State("die",
                        new Suicide()
                    )
                )
             )
        .Init("Little Rager 2",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new State("Start",
                        new Follow(1.00, 13, 0),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 0, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 30, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 60, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 90, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 120, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 150, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 180, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 210, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 240, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 270, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 300, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 330, color: 0xff0000, coolDown: 2000),
                        new Grenade(1.5, 250, range: 4, fixedAngle: 360, color: 0xff0000, coolDown: 2000),
                        new TimedTransition(5000, "die")
                    ),
                    new State("die",
                        new Suicide()
                    )
                )
             )
        .Init("Little Rager 3",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new State("Start1",
                        new Grenade(4.0, 375, range: 9, fixedAngle: 45, color: 0xff0000, coolDown: 6000),
                        new EntityNotExistsTransition("Skeleton Rager", 100, "die"),
                        new TimedTransition(3500, "Start2")
                    ),
                    new State("Start2",
                        new Grenade(4.0, 375, range: 9, fixedAngle: 135, color: 0xff0000, coolDown: 6000),
                        new EntityNotExistsTransition("Skeleton Rager", 100, "die"),
                        new TimedTransition(3500, "Start3")
                    ),
                    new State("Start3",
                        new Grenade(4.0, 375, range: 9, fixedAngle: 225, color: 0xff0000, coolDown: 6000),
                        new EntityNotExistsTransition("Skeleton Rager", 100, "die"),
                        new TimedTransition(3500, "Start4")
                    ),
                    new State("Start4",
                        new Grenade(4.0, 375, range: 9, fixedAngle: 315, color: 0xff0000, coolDown: 6000),
                        new EntityNotExistsTransition("Skeleton Rager", 100, "die"),
                        new TimedTransition(3500, "Final")
                    ),
                    new State("Final",
                        new Grenade(3.0, 325, range: 9, fixedAngle: 0, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 30, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 60, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 90, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 120, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 150, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 180, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 210, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 240, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 270, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 300, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 330, color: 0xff0000, coolDown: 6000),
                        new Grenade(3.0, 325, range: 9, fixedAngle: 360, color: 0xff0000, coolDown: 6000),
                        new EntityNotExistsTransition("Skeleton Rager", 100, "die"),
                        new TimedTransition(3500, "Start1")
                    ),
                    new State("die",
                        new Suicide()
                    )
                )
             )
        .Init("Skeleton Alchemist Cyan",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new Grenade(3, 150, range: 12, effect: ConditionEffectIndex.Slowed, effectDuration: 3000, color: 0x15dddd, coolDown: 1500)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.02)
                    )
                )
        .Init("Spirit Witch",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new RingAttack(30, 12, 0, projectileIndex: 0, 0, 0, coolDown: 3000),
                    new Shoot(10, 2, 7, coolDown: 1500, projectileIndex: 1)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
                )
        .Init("Bat Swarm",
                new State(
                    new Prioritize(
                        new Follow(0.75, 12, 1)
                    ),
                    new RingAttack(30, 3, 0, projectileIndex: 0, 0.4, 0, coolDown: 250)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
                )
        .Init("Skeleton Alchemist Green",
                new State(
                    new Prioritize(
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1)
                    ),
                    new Grenade(3, 125, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0x0fea31, coolDown: 1500)
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.02)
                    )
            );
    }
}
