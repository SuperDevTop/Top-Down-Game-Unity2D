﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Aerial = () => Behav()
        .Init("AbyssIdolDead",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible)
                )
            )
        .Init("AE Teleport",
            new State(
                new State("Constant",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                     new Orbit(0.5, 1, target: "AbyssIdolDead"),
                     new TeleportPlayer(2, 105, 115, true)
                    )
                )
            )
        .Init("Ethereal Being",
            new State(
                new HPScale(25),
                new State("Idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(12, "Dialogue I")
                    ),
                new State("Dialogue I",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("*alien noises*"),
                    new TimedTransition(2000, "Start")
                    ),
                new State("Start",
                    new Follow(0.1, 10, 2.5, 0, 0),
                    new Shoot(12, 2, 180, 1, 0, coolDown: 2000),
                    new Shoot(12, 2, 180, 1, 18, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(12, 2, 180, 1, 36, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(12, 2, 180, 1, 54, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(12, 2, 180, 1, 72, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(12, 2, 180, 1, 90, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(12, 2, 180, 1, 108, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(12, 2, 180, 1, 126, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(12, 2, 180, 1, 144, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(12, 2, 180, 1, 162, coolDown: 2000, coolDownOffset: 1800),
                    new Shoot(10, 4, 90, 3, coolDown: 200),
                    new Shoot(10, 1, 0, 2, coolDown: 1500),
                    new Shoot(10, 2, 8, 0, coolDown: 200),
                    new HpLessTransition(0.6, "Prep")
                    ),
                new State("Prep",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new ReturnToSpawn(0.3),
                    new TimedTransition(4000, "Tentacle")
                    ),
                new State("Tentacle",
                    new Shoot(10, 6, 60, 5, 30, coolDown: 100),
                    new Shoot(10, 1, 0, 2, coolDown: 1500),
                    new Shoot(10, 5, 15, 4, coolDown: 1000),
                    new Shoot(10, 2, 180, 0, 0, coolDown: 1000),
                    new Shoot(10, 2, 180, 0, 18, coolDown: 1000, coolDownOffset: 100),
                    new Shoot(10, 2, 180, 0, 36, coolDown: 1000, coolDownOffset: 200),
                    new Shoot(10, 2, 180, 0, 54, coolDown: 1000, coolDownOffset: 300),
                    new Shoot(10, 2, 180, 0, 72, coolDown: 1000, coolDownOffset: 400),
                    new Shoot(10, 2, 180, 0, 90, coolDown: 1000, coolDownOffset: 500),
                    new Shoot(10, 2, 180, 0, 108, coolDown: 1000, coolDownOffset: 600),
                    new Shoot(10, 2, 180, 0, 126, coolDown: 1000, coolDownOffset: 700),
                    new Shoot(10, 2, 180, 0, 144, coolDown: 1000, coolDownOffset: 800),
                    new Shoot(10, 2, 180, 0, 162, coolDown: 1000, coolDownOffset: 900),
                    new HpLessTransition(0.4, "Active")
                    ),
                new State("Active",
                    new Follow(0.2, 10, 2.5, 0, 0),
                    new Shoot(12, 3, 120, 1, 0, coolDown: 2000),
                    new Shoot(12, 3, 120, 1, 12, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(12, 3, 120, 1, 24, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(12, 3, 120, 1, 36, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(12, 3, 120, 1, 48, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(12, 3, 120, 1, 60, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(12, 3, 120, 1, 72, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(12, 3, 120, 1, 84, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(12, 3, 120, 1, 96, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(12, 3, 120, 1, 108, coolDown: 2000, coolDownOffset: 1800),
                    new Shoot(10, 3, 120, 3, coolDown: 200),
                    new Shoot(10, 4, 10, 5, coolDown: 400),
                    new Shoot(10, 2, 12, 2, coolDown: 600)
                    )
                ),
                new Threshold(0.001,
                    LootTemplates.StrongerDrop()
                    ),
                new Threshold(0.001,
                    LootTemplates.BasicPots()
                    ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.9),
                    new ItemLoot("Support Fragment", 0.1)
                    ),
                new Threshold(0.02,
                    new ItemLoot("Lucent Crutch", 0.0125),
                    new ItemLoot("Lunar Monolith", 0.0125),
                    new ItemLoot("Astronomer's Cloth", 0.0125),
                    new ItemLoot("Andromeda Band", 0.0125)
                    )
            )
        .Init("AE Ethereal Spiral",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(12, 1, 0, 1, coolDown: 1500),
                    new Shoot(12, 2, 8, 1, coolDown: 1500, coolDownOffset: 200),
                    new Shoot(12, 4, 8, 1, coolDown: 1500, coolDownOffset: 400),
                    new Shoot(12, 4, 90, 0, coolDown: 2000)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Lightning Cloud",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(12, 1, 0, 1, coolDown: 400),
                    new Shoot(10, 4, 10, 0, coolDown: 1200)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Tornado",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(10, 6, 60, 1, coolDown: 1500),
                    new Shoot(10, 6, 60, 0, coolDown: 1500, coolDownOffset: 300)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Yellow Stormy",
            new State(
                new HPScale(5),
                new State("Main",
                    new Wander(0.2),
                    new Shoot(12, 2, 8, 0, coolDown: 1000),
                    new Shoot(12, 8, 45, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Yellow Wasp",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(12, 3, 8, 0, coolDown: 1000),
                    new Shoot(12, 5, 10, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Yellow Defender",
            new State(
                new HPScale(5),
                new State("Main",
                    new Wander(0.2),
                    new Shoot(12, 1, 0, 0, coolDown: 300),
                    new Shoot(12, 6, 12, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Blue Guardian",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(12, 2, 180, 0, 0, coolDown: 2000),
                    new Shoot(12, 2, 180, 0, 18, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(12, 2, 180, 0, 36, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(12, 2, 180, 0, 54, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(12, 2, 180, 0, 72, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(12, 2, 180, 0, 90, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(12, 2, 180, 0, 108, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(12, 2, 180, 0, 126, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(12, 2, 180, 0, 144, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(12, 2, 180, 0, 162, coolDown: 2000, coolDownOffset: 1800),
                    new Shoot(12, 3, 10, 1, coolDown: 1000)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Blue Stormy",
            new State(
                new HPScale(5),
                new State("Main",
                    new Wander(0.2),
                    new Shoot(12, 2, 8, 0, coolDown: 1000),
                    new Shoot(12, 8, 45, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Blue Wasp",
            new State(
                new HPScale(5),
                new State("Main",
                    new Follow(0.3, 10, 2.5, 0, 0),
                    new Shoot(12, 3, 8, 0, coolDown: 1000),
                    new Shoot(12, 5, 10, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            )
        .Init("AE Blue Defender",
            new State(
                new HPScale(5),
                new State("Main",
                    new Wander(0.2),
                    new Shoot(12, 1, 0, 0, coolDown: 300),
                    new Shoot(12, 6, 12, 1, coolDown: 1500)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.04)
                    )
            );
    }
}