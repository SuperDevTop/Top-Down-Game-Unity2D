﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Reptilian = () => Behav()

        .Init("Reptilian Warrior",
            new State(
                new State("Exist",
                    new Wander(0.2),
                    new Shoot(10, 2, 8, 0, coolDown: 1200),
                    new Shoot(10, 4, 10, 1, coolDown: 1800)
                    )
                )
            )

        .Init("Bombardier Serpent",
            new State(
                new State("Exist",
                    new StayCloseToSpawn(0.3, range: 2),
                    new Wander(0.1),
                    new Shoot(10, 1, 0, 0, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 8, explodeAngle: 45, coolDown: 2000),
                    new Grenade(2, 90, range: 10, effect: ConditionEffectIndex.Slowed, effectDuration: 300, color: 0xacc734, coolDown: 500)
                    )
                )
            )

        .Init("Cordierite Warrior",
            new State(
                new State("Exist",
                    new Wander(0.2),
                    new Shoot(10, 1, 0, 0, hasExplodingShots: true, explodeShotIndex: 0, explodeCount: 6, explodeAngle: 60, coolDown: 1500),
                    new Shoot(10, 1, 0, 1, coolDown: 1200),
                    new Shoot(10, 1, 0, 1, coolDown: 1200, coolDownOffset: 200),
                    new Shoot(10, 1, 0, 1, coolDown: 1200, coolDownOffset: 400)
                    )
                )
            )

        .Init("Crystalline Being",
            new State(
                new State("Exist",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(6, "Active")
                    ),
                new State("Active",
                    new Shoot(10, 18, 20, 0, coolDown: 10000),
                    new Shoot(10, 1, 0, 0, coolDown: 200),
                    new HpLessTransition(0.2, "Decay")
                    ),
                new State("Decay",
                    new Shoot(10, 18, 20, 0, coolDown: 999999),
                    new Spawn("Crystalline Hatchling", 1, 1),
                    new Decay(50)
                    )
                )
            )

        .Init("Crystalline Hatchling",
            new State(
                new State("Exist",
                    new Follow(0.4, 10, 2.5, 0, 0),
                    new Shoot(10, 1, 0, 0, hasExplodingShots: true, explodeShotIndex: 0, explodeCount: 6, explodeAngle: 60, coolDown: 1500),
                    new Shoot(10, 1, 0, 1, coolDown: 1200),
                    new Shoot(10, 1, 0, 1, coolDown: 1200, coolDownOffset: 200),
                    new Shoot(10, 1, 0, 1, coolDown: 1200, coolDownOffset: 400)
                    )
                )
            )

        .Init("Wisp",
            new State(
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Prioritize(
                    new StayCloseToSpawn(0.2, 4),
                    new Wander(0.2)
                    ),
                new State("Activate",
                    new PlayerWithinTransition(6, "Dialogue")
                    ),
                new State("Dialogue",
                    new Taunt("Greetings.. If you wish to meet my guardian you must eliminate all floating crystals."),
                    new TimedTransition(3000, "Wait")
                    ),
                new State("Wait",
                    new Taunt("Otherwise my teleporting magic is too weak.."),
                    new EntitiesNotExistsTransition(99, "Teleport", "Crystalline Being", "Crystalline Hatchling")
                    ),
                new State("Teleport",
                    new Taunt("Come, come.. Run towards me and I shall send you to him."),
                    new TeleportPlayer(4, 105, 50, true)
                    )
                )
            )

        .Init("Crystalline Orbiter",
            new State(
                new State("Exist",
                    new Orbit(speed: 0.8, radius: 10, acquireRange: 20, target: "Crystalline Guardian", speedVariance: 0, radiusVariance: 0, orbitClockwise: true),
                    new Shoot(10, 3, 0, 0, coolDown: 750)
                    )
                )
            )

        .Init("Crystalline Guardian",
            new State(
                new HPScale(30),
                new State("Exist",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(12, "Dialogue I")
                    ),
                new State("Dialogue I",
                    new Taunt("Welcome to my cavern humans."),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TimedTransition(5000, "Intro")
                    ),
                new State("Intro",
                    new Follow(0.1, 10, 1, 0, 0),
                    // wave spiral
                    new Shoot(10, 3, 120, 1, 0, coolDown: 2000),
                    new Shoot(10, 3, 120, 1, 12, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(10, 3, 120, 1, 24, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(10, 3, 120, 1, 36, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(10, 3, 120, 1, 48, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(10, 3, 120, 1, 60, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(10, 3, 120, 1, 72, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(10, 3, 120, 1, 84, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(10, 3, 120, 1, 96, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(10, 3, 120, 1, 108, coolDown: 2000, coolDownOffset: 1800),
                    // exploding crystal balls
                    new Shoot(10, 10, 36, 0, hasExplodingShots: true, explodeShotIndex: 2, explodeCount: 2, explodeAngle: 180, coolDown: 1500),
                    new HpLessTransition(0.66, "Prep")
                    ),
                new State("Prep",
                    // roams to center before spawning mininons
                    new ReturnToSpawn(speed: 1.50),
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TimedTransition(4500, "Minion")
                    ),
                new State("Minion",
                    // spawns minions
                    new InvisiToss("Crystalline Orbiter", 10, 0, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 45, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 90, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 135, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 180, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 235, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 290, 9999),
                    new InvisiToss("Crystalline Orbiter", 10, 315, 9999),
                    new TimedTransition(500, "Waiting")
                    ),
                /* shoots a stream of rocks while armored until minions are killed, 
                   if damaged below 1/2 hp the guardian becomes invulnerable */
                new State("Waiting",
                    new ConditionalEffect(ConditionEffectIndex.Armored),
                    new Shoot(10, 2, 12, 2, coolDown: 200),
                    new HpLessTransition(0.5, "Protected"),
                    new EntityNotExistsTransition("Crystalline Orbiter", 99, "Shotgun")
                    ),
                new State("Protected",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Shoot(10, 2, 12, 3, coolDown: 200),
                    new EntityNotExistsTransition("Crystalline Orbiter", 99, "Shotgun")
                    ),
                // oryx 2-esque shotgun before going into rage phase
                new State("Shotgun",
                    new Shoot(10, 10, 36, 0, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 5, explodeAngle: 72, coolDown: 9999),
                    new Shoot(10, 5, 10, 1, coolDown: 9999),
                    new Shoot(10, 8, 8, 2, coolDown: 9999),
                    new TimedTransition(1000, "Rage")
                    ),
                new State("Rage",
                    // more dense exploding crystal ball shot
                    new Shoot(10, 10, 36, 0, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 3, explodeAngle: 120, coolDown: 4000),
                    // 3 shot shard burst
                    new Shoot(10, 3, 8, 1, predictive: 1, coolDown: 1000),
                    new Shoot(10, 3, 8, 1, predictive: 1, coolDown: 1000, coolDownOffset: 200),
                    new Shoot(10, 3, 8, 1, predictive: 1, coolDown: 1000, coolDownOffset: 400),
                    // rock tentacle thing that might look cool
                    new Shoot(10, 2, 180, 2, 0, coolDown: 2000),
                    new Shoot(10, 2, 180, 2, 18, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(10, 2, 180, 2, 36, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(10, 2, 180, 2, 54, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(10, 2, 180, 2, 72, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(10, 2, 180, 2, 90, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(10, 2, 180, 2, 108, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(10, 2, 180, 2, 126, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(10, 2, 180, 2, 144, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(10, 2, 180, 2, 162, coolDown: 2000, coolDownOffset: 1800),
                    // reverse tentacle
                    new Shoot(10, 2, 180, 2, 180, coolDown: 2000),
                    new Shoot(10, 2, 180, 2, 162, coolDown: 2000, coolDownOffset: 200),
                    new Shoot(10, 2, 180, 2, 144, coolDown: 2000, coolDownOffset: 400),
                    new Shoot(10, 2, 180, 2, 126, coolDown: 2000, coolDownOffset: 600),
                    new Shoot(10, 2, 180, 2, 108, coolDown: 2000, coolDownOffset: 800),
                    new Shoot(10, 2, 180, 2, 90, coolDown: 2000, coolDownOffset: 1000),
                    new Shoot(10, 2, 180, 2, 72, coolDown: 2000, coolDownOffset: 1200),
                    new Shoot(10, 2, 180, 2, 54, coolDown: 2000, coolDownOffset: 1400),
                    new Shoot(10, 2, 180, 2, 36, coolDown: 2000, coolDownOffset: 1600),
                    new Shoot(10, 2, 180, 2, 18, coolDown: 2000, coolDownOffset: 1800)
                    )
                ),
                new Threshold(0.005,
                    LootTemplates.StrongerDrop()
                    ),
                new Threshold(0.005,
                    LootTemplates.StrongerPots()
                    ),
                new Threshold(0.005,
                    new ItemLoot("Crystalized Lootbox", 0.1),
                    new ItemLoot("Support Fragment", 0.06)
                    ),
                new Threshold(0.01,
                    new ItemLoot("Agate Cluster", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Stalactite Stiletto", 0.005),
                    new ItemLoot("Impenetrable Hide", 0.005)
                    )
            )

        .Init("Reptilian Ruler",
            new State(
                new HPScale(30),
                new DropPortalOnDeath("Reptillian Cavern Portal", 1),
                new State("Exist",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(8, "Dialogue I")
                    ),
                new State("Dialogue I",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Ah the heroes, Don't worry, I'll make quick work of you all."),
                    new TimedTransition(4000, "Intro")
                    ),
                new State("Intro",
                    // waving shots
                    new Shoot(10, 2, 8, 1, 180, coolDown: 4000),
                    new Shoot(10, 2, 8, 1, 171, coolDown: 4000, coolDownOffset: 100),
                    new Shoot(10, 2, 8, 1, 162, coolDown: 4000, coolDownOffset: 200),
                    new Shoot(10, 2, 8, 1, 153, coolDown: 4000, coolDownOffset: 300),
                    new Shoot(10, 2, 8, 1, 144, coolDown: 4000, coolDownOffset: 400),
                    new Shoot(10, 2, 8, 1, 135, coolDown: 4000, coolDownOffset: 500),
                    new Shoot(10, 2, 8, 1, 126, coolDown: 4000, coolDownOffset: 600),
                    new Shoot(10, 2, 8, 1, 117, coolDown: 4000, coolDownOffset: 700),
                    new Shoot(10, 2, 8, 1, 108, coolDown: 4000, coolDownOffset: 800),
                    new Shoot(10, 2, 8, 1, 72, coolDown: 4000, coolDownOffset: 1200),
                    new Shoot(10, 2, 8, 1, 63, coolDown: 4000, coolDownOffset: 1300),
                    new Shoot(10, 2, 8, 1, 54, coolDown: 4000, coolDownOffset: 1400),
                    new Shoot(10, 2, 8, 1, 45, coolDown: 4000, coolDownOffset: 1500),
                    new Shoot(10, 2, 8, 1, 36, coolDown: 4000, coolDownOffset: 1600),
                    new Shoot(10, 2, 8, 1, 27, coolDown: 4000, coolDownOffset: 1700),
                    new Shoot(10, 2, 8, 1, 18, coolDown: 4000, coolDownOffset: 1800),
                    new Shoot(10, 2, 8, 1, 9, coolDown: 4000, coolDownOffset: 1900),
                    new Shoot(10, 2, 8, 1, 0, coolDown: 4000, coolDownOffset: 2000),
                    new Shoot(10, 2, 8, 1, 9, coolDown: 4000, coolDownOffset: 2100),
                    new Shoot(10, 2, 8, 1, 18, coolDown: 4000, coolDownOffset: 2200),
                    new Shoot(10, 2, 8, 1, 27, coolDown: 4000, coolDownOffset: 2300),
                    new Shoot(10, 2, 8, 1, 36, coolDown: 4000, coolDownOffset: 2400),
                    new Shoot(10, 2, 8, 1, 45, coolDown: 4000, coolDownOffset: 2500),
                    new Shoot(10, 2, 8, 1, 54, coolDown: 4000, coolDownOffset: 2600),
                    new Shoot(10, 2, 8, 1, 63, coolDown: 4000, coolDownOffset: 2700),
                    new Shoot(10, 2, 8, 1, 72, coolDown: 4000, coolDownOffset: 2800),
                    new Shoot(10, 2, 8, 1, 108, coolDown: 4000, coolDownOffset: 3200),
                    new Shoot(10, 2, 8, 1, 117, coolDown: 4000, coolDownOffset: 3300),
                    new Shoot(10, 2, 8, 1, 126, coolDown: 4000, coolDownOffset: 3400),
                    new Shoot(10, 2, 8, 1, 135, coolDown: 4000, coolDownOffset: 3500),
                    new Shoot(10, 2, 8, 1, 144, coolDown: 4000, coolDownOffset: 3600),
                    new Shoot(10, 2, 8, 1, 153, coolDown: 4000, coolDownOffset: 3700),
                    new Shoot(10, 2, 8, 1, 162, coolDown: 4000, coolDownOffset: 3800),
                    new Shoot(10, 2, 8, 1, 171, coolDown: 4000, coolDownOffset: 3900),
                    // burst
                    new Shoot(10, 3, 10, 0, coolDown: 200),
                    // transition
                    new HpLessTransition(0.66, "Provoked")
                    ),
                new State("Provoked",
                    new Follow(0.2, 10, 2.5, 0, 0),
                    // shield waves
                    new Shoot(10, 5, 10, 1, coolDown: 2000),
                    new Shoot(10, 5, 7, 1, coolDown: 2000, coolDownOffset: 500),
                    // fireballs
                    new Shoot(10, 3, 20, 2, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 6, explodeAngle: 60, coolDown: 2000, coolDownOffset: 1000),
                    // hammers
                    new Shoot(10, 18, 20, 0, coolDown: 4000),
                    // transition
                    new HpLessTransition(0.33, "Dialogue II")
                    ),
                new State("Dialogue II",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Taunt("Be gone! You little worms are making me angry."),
                    new TimedTransition(4000, "Rage")
                    ),
                new State("Rage",
                    new Follow(0.5, 10, 2.5, 0, 0),
                    new Taunt("I said BE GONE!"),
                    // 360 ring
                    new Shoot(10, 36, 10, 1, coolDown: 4000),
                    // fireballs
                    new Shoot(10, 3, 20, 2, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 12, explodeAngle: 30, coolDown: 2000),
                    // hammers
                    new Shoot(10, 3, 12, 4, coolDown: 200),
                    // transition
                    new HpLessTransition(0.08, "Dialogue III")
                    ),
                new State("Dialogue III",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Flash(0xff0000, 0.5f, 1),
                    new Taunt("*HISSSSSsssssss*"),
                    new Decay(2000)
                    )
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                    ),
                new Threshold(0.01,
                    new ItemLoot("Shield of Giants", 0.02),
                    new ItemLoot("Fangs of the Wolf King", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Hammer of Reptillian Valor", 0.005)
                    )
            );

    }
}
