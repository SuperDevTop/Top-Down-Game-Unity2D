﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Cthu = () => Behav()
            .Init("Cthu Stargazer",
                new State(
                    new HPScale(5),
                    new State("Attack",
                        new Follow(0.6, 12, 3),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 1900),
                        new TimedTransition(2000, "Attack2")
                        ),
                    new State("Attack2",
                        new Follow(0.6, 12, 3),
                        new Shoot(15, count: 2, shootAngle: 7, projectileIndex: 0, coolDown: 1900),
                        new TimedTransition(2000, "Attack3")
                        ),
                    new State("Attack3",
                        new Follow(0.6, 12, 3),
                        new Shoot(15, count: 3, shootAngle: 7, projectileIndex: 0, coolDown: 1900),
                        new TimedTransition(2000, "Attack4")
                        ),
                    new State("Attack4",
                        new Follow(0.6, 12, 3),
                        new Shoot(15, count: 4, shootAngle: 7, projectileIndex: 0, coolDown: 1900),
                        new TimedTransition(2000, "Attack5")
                        ),
                    new State("Attack5",
                        new Follow(1.8, 12, 0),
                        new Grenade(4, 150, range: 0, fixedAngle: 36, color: 0xca5f12, coolDown: 900),
                        new TimedTransition(1000, "Attack")
                        )
                     )
                   )
        .Init("Cthu Stargazer Priest",
                new State(
                    new HPScale(5),
                    new State("Attack",
                        new Wander(0.2),
                        new HealEntity(10, "Cthu Stargazer", healAmount: 900, coolDown: 3500),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 750)
                        )
                   )
                )
        .Init("Cthu Stargazer Rogue",
                new State(
                    new HPScale(5),
                    new State("Go Invis",
                        new Follow(0.5, 14, 4),
                        new TimedTransition(1500, "Walk Towards")
                        ),
                    new State("Walk Towards",
                        new SetAltTexture(1),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Follow(1.5, 12, 1),
                        new TimedTransition(3000, "Attack")
                        ),
                    new State("Attack",
                        new SetAltTexture(2),
                        new Follow(0.2, 14, 3),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(3000, "Go Invis")
                        )
                    )
                )
            .Init("Cthu Stargazer Knight",
                new State(
                    new HPScale(5),
                    new State("Follow",
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Follow(0.6, 14, 4),
                        new TimedTransition(6000, "attack")
                        ),
                    new State("attack",
                        new Follow(1.0, 14, 2),
                        new Grenade(6, 100, range: 0, effect: ConditionEffectIndex.Slowed, effectDuration: 4000, fixedAngle: 36, color: 0xca5f12, coolDown: 1300),
                        new TimedTransition(2000, "Follow")
                        )
                    )
                )
            .Init("Cthu Flying Formless Spawn",
                new State(
                    new HPScale(5),
                    new State("Follow",
                        new Follow(0.6, 14, 2),
                        new TimedTransition(2000, "attack")
                        ),
                    new State("attack",
                        new Follow(0.2, 14, 7),
                        new TossObject("Cthu Formless Egg", 0, angle: 180, coolDown: 3000, throwEffect: true),
                        new Grenade(3, 150, range: 8, effect: ConditionEffectIndex.Dazed, effectDuration: 2500, color: 0xca5f12, coolDown: 1000),
                        new TimedTransition(2000, "Follow")
                        )
                    )
                )
        .Init("Cthu Formless Egg",
                new State(
                    new HPScale(5),
                    new State("wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(1500, "shoot before death")
                        ),
                    new State("shoot before death",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 12, 0, projectileIndex: 0, 35, 35, coolDown: 900),
                        new TimedTransition(1000, "die")
                        ),
                   new State("die",
                        new Decay(0)
                        )
                    )
                )
        .Init("Cthu Crawling Formless Spawn",
                new State(
                    new HPScale(5),
                    new State("follow",
                        new Follow(0.9, 12, 1),
                        new TimedTransition(2000, "attack")
                        ),
                    new State("attack",
                        new RingAttack(20, 2, 0, projectileIndex: 0, 0.3, 0.3, coolDown: 100, seeInvis: true),
                        new TimedTransition(2000, "follow")
                        )
                    )
                )
        .Init("Cthu Spiked Formless Spawn",
                new State(
                    new HPScale(5),
                    new State("attack",
                        new StayBack(0.6, 7),
                        new Wander(0.1),
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 1200)
                        )
                    )
                )
        .Init("Cthu Stargazer Guardian",
                new State(
                    new HPScale(25),
                    new Prioritize(
                        new Shoot(15, count: 1, projectileIndex: 0, coolDown: 3000)
                        ),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(12, "throwtentacle")
                        ),
                    new State("throwtentacle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TossObject("Cthu Guardian Tentacle", 0, angle: 0, coolDown: 5000000, throwEffect: false, tossInvis: true),
                        new TimedTransition(2500, "attack1")
                        ),
                    new State("attack1",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 0, projectileIndex: 1, coolDown: 3200),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 0, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 0, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack2"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack2",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 45, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 45, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 45, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack3"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack3",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 90, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 90, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 90, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack4"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack4",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 135, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 135, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 135, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack5"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack5",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 180, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 180, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 180, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack6"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack6",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 225, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 225, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 225, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack7"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack7",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 270, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 270, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 270, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack8"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("attack8",
                        new Shoot(15, count: 3, shootAngle: 7, fixedAngle: 315, projectileIndex: 1, coolDown: 3000),
                        new Shoot(15, count: 6, shootAngle: 7, fixedAngle: 315, projectileIndex: 4, coolDown: 3400),
                        new Shoot(15, count: 9, shootAngle: 7, fixedAngle: 315, projectileIndex: 5, coolDown: 3800),
                        new TimedTransition(1500, "attack1"),
                        new HpLessTransition(0.70, "pillars")
                        ),
                    new State("pillars",
                        new Order(30, "Cthu Guardian Tentacle", "stop"),
                        new TossObject("Cthu Tower 1", 9, angle: 45, coolDown: 500000, throwEffect: true),
                        new TossObject("Cthu Tower 2", 9, angle: 135, coolDown: 500000, throwEffect: true),
                        new TossObject("Cthu Tower 1", 9, angle: 225, coolDown: 500000, throwEffect: true),
                        new TossObject("Cthu Tower 2", 9, angle: 315, coolDown: 500000, throwEffect: true),
                        new RingAttack(315, 2, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 50, seeInvis: true),
                        new RingAttack(360, 16, 0, projectileIndex: 3, 0.3, 0.3, coolDown: 6000, seeInvis: true),
                        new HpLessTransition(0.40, "harderpillars")
                        ),
                    new State("harderpillars",
                        new Order(30, "Cthu Tower 1", "harderattack"),
                        new Order(30, "Cthu Tower 2", "harderattack"),
                        new Shoot(15, count: 3, shootAngle: 7, projectileIndex: 1, coolDown: 3200),
                        new Shoot(15, count: 6, shootAngle: 7, projectileIndex: 4, coolDown: 3400),
                        new RingAttack(315, 3, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 50, seeInvis: true),
                        new HpLessTransition(0.10, "removegate")
                        ),
                    new State("removegate",
                        new Order(30, "Cthu Tower 1", "decay"),
                        new Order(30, "Cthu Tower 2", "decay"),
                        new RemoveObjectOnDeath("Cthu Gate", 25),
                        new Suicide()
                        )
                    ),
                    new Threshold(0.001,
                        LootTemplates.StrongerDrop()
                    ),
                new Threshold(0.01,
                    new ItemLoot("Critical Damage Fragment", 0.05),
                    new ItemLoot("Necklace of the Elders", 0.02),
                    new ItemLoot("Armor of the Stargazer", 0.02),
                    new ItemLoot("Potion of Defense", 1.0),
                    new ItemLoot("Potion of Wisdom", 1.0),
                    new ItemLoot("Starseeker Lootbox", 0.1)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Spear of Pure Insanity", 0.005),
                    new ItemLoot("Bow of Insanity", 0.005),
                    new ItemLoot("Potion of Life", 0.66),
                    new ItemLoot("Potion of Mana", 0.66)
                    )
                )
        .Init("Cthu Tower 1",
                new State(
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.9, 0.9, coolDown: 4000, seeInvis: true)
                        ),
                    new State("harderattack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.9, 0.9, coolDown: 3000, seeInvis: true)
                        ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                    )
                )
        .Init("Cthu Tower 2",
                new State(
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.9, 0.9, coolDown: 4000, seeInvis: true)
                        ),
                    new State("harderattack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.9, 0.9, coolDown: 3000, seeInvis: true)
                        ),
                    new State("decay",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                    )
                )
            .Init("Cthu Teleport",
                new State(
                    new TeleportPlayer(3, 7, 6, true)
                )
            )
            .Init("Cthu Guardian Tentacle",
                new State(
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(270, 2, 0, projectileIndex: 0, 0.2, 0.2, coolDown: 50, seeInvis: true)
                        ),
                    new State("stop",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Decay(0)
                        )
                    )
                )
            .Init("Stargazer High Priest",
            new State(
                new HPScale(30),
                new State("Wait",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new PlayerWithinTransition(8, "Talk1")
                    ),
                new State("Talk1",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Ph'nglui mglw'nafh Cthulhu"),
                    new TimedTransition(2500, "Talk2")
                    ),
                new State("Talk2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Oh i forgot.."),
                    new TimedTransition(2500, "Talk3")
                    ),
                new State("Talk3",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Humans can't understand the great ones tongue.."),
                    new TimedTransition(2500, "Talk4")
                    ),
                new State("Talk4",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Well, nice to meet you, you disgusting beasts"),
                    new TimedTransition(2500, "Talk5")
                    ),
                new State("Talk5",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Disappear"),
                    new TimedTransition(2000, "Burst")
                    ),
                new State("Burst",
                    new RingAttack(270, 4, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 75, seeInvis: true),
                    new RingAttack(270, 12, 0, projectileIndex: 1, 0.25, 0.25, coolDown: 1000, seeInvis: true),
                    new RingAttack(270, 14, 0, projectileIndex: 2, 0.15, 0.15, coolDown: 1250, seeInvis: true),
                    new TimedTransition(5000, "Prepare")
                    ),
                new State("Prepare",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Oh your still alive? A pitty."),
                    new TimedTransition(2500, "Prepare2")
                    ),
                new State("Prepare2",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Ee ehye shugg syha'h"),
                    new TossObject("Cthu Orb", 3, angle: 90, coolDown: 500000, throwEffect: true),
                    new TimedTransition(3000, "Prepare3")
                    ),
                new State("Prepare3",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Lloig syha'h phlegeth"),
                    new TossObject("Cthu Fire Bomb", 3, angle: 180, coolDown: 500000, throwEffect: true),
                    new TimedTransition(3000, "Prepare4")
                    ),
                new State("Prepare4",
                    new ConditionalEffect(ConditionEffectIndex.Invincible),
                    new Taunt("Hlirgh wgah'n k'yarnak"),
                    new TossObject("Cthu Star Bomb", 3, angle: 270, coolDown: 500000, throwEffect: true),
                    new TimedTransition(3000, "First Order")
                    ),
                new State("First Order",
                    new Taunt("Destroy Them.."),
                    new Order(30, "Cthu Fire Bomb", "Order1"),
                    new Order(30, "Cthu Orb", "Order1"),
                    new Order(30, "Cthu Star Bomb", "Order1"),
                    new HpLessTransition(0.75, "Second Order")
                    ),
                new State("Second Order",
                    new Taunt("Die Already! Reposition!"),
                    new Order(30, "Cthu Fire Bomb", "Order2"),
                    new Order(30, "Cthu Orb", "Order2"),
                    new Order(30, "Cthu Star Bomb", "Order2"),
                    new RingAttack(270, 8, 0, projectileIndex: 1, 0.3, 0.3, coolDown: 2000, seeInvis: true),
                    new HpLessTransition(0.55, "Third Order")
                    ),
                new State("Third Order",
                    new Taunt("Return to me! I'll kill them with my magic!"),
                    new Order(30, "Cthu Fire Bomb", "Order3"),
                    new Order(30, "Cthu Orb", "Order3"),
                    new Order(30, "Cthu Star Bomb", "Order3"),
                    new RingAttack(270, 1, 0, projectileIndex: 0, 0.35, 0.35, coolDown: 50, seeInvis: true),
                    new HpLessTransition(0.30, "Final Order")
                    ),
                new State("Final Order",
                    new Taunt("Just.. Kill Them..."),
                    new Order(30, "Cthu Fire Bomb", "Order4"),
                    new Order(30, "Cthu Orb", "Order4"),
                    new Order(30, "Cthu Star Bomb", "Order4"),
                    new HpLessTransition(0.05, "Death")
                    ),
                new State("Death",
                    new Order(30, "Cthu Fire Bomb", "Order5"),
                    new Order(30, "Cthu Orb", "Order5"),
                    new Order(30, "Cthu Star Bomb", "Order5"),
                    new Suicide()
                    )
                ),
                            new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.06)
                ),
                    new Threshold(0.001,
                        LootTemplates.StrongerDrop()
                    ),

                new Threshold(0.03,
                    new ItemLoot("Attack Fragment", 0.05),
                    new ItemLoot("Wisdom Fragment", 0.05),
                    new ItemLoot("Intelligence Fragment", 0.05),
                    new ItemLoot("Shard of Divinity", 0.0025),
                    new ItemLoot("Wand of Old Gods", 0.005),
                    new ItemLoot("Robe of the Star Walker", 0.005),
                    new ItemLoot("Orb of Eldritch Visions", 0.005),
                    new ItemLoot("Star Gazing Staff", 0.005),
                    new ItemLoot("Greater Potion of Life", 0.5),
                    new ItemLoot("Greater Potion of Mana", 0.5),
                    new ItemLoot("Cthulhu Key", 0.008),
                    new ItemLoot("Greater Potion of Attack", 1),
                    new ItemLoot("Greater Potion of Wisdom", 1),
                    new ItemLoot("Starseeker Lootbox", 0.1),
                    new ItemLoot("Élan Vital Rune", 0.025)
                    )
            )
        .Init("Cthu Fire Bomb",
            new State(
            new State("Idle",
                new ConditionalEffect(ConditionEffectIndex.Invincible)
                ),
                new State("Order1",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(1.2, 6.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 2, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 150, seeInvis: true)
                ),
                new State("Order2",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.7, 6.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 1, 0, projectileIndex: 0, 0.3, 0.3, coolDown: 50, seeInvis: true)
                ),
                new State("Order3",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.6, 2.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 8, 0, projectileIndex: 0, 0.3, 0.3, coolDown: 4000, seeInvis: true)
                ),
                new State("Order4",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.8, 4.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 2, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 50, seeInvis: true)
                ),
                new State("Order5",
                new Suicide()
                )
            )
        )
        .Init("Cthu Orb",
            new State(
                new State("Idle",
                new ConditionalEffect(ConditionEffectIndex.Invincible)
                ),
                new State("Order1",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.6, 3, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new Shoot(15, count: 1, projectileIndex: 0, coolDown: 800)
                ),
                new State("Order2",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(2.0, 8.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, coolDown: 800)
                ),
                new State("Order3",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.5, 2, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new Shoot(15, count: 3, shootAngle: 16, projectileIndex: 0, coolDown: 2000)
                ),
                new State("Order4",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.5, 4.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new Shoot(15, count: 5, shootAngle: 15, projectileIndex: 0, coolDown: 1000)
                ),
                new State("Order5",
                new Suicide()
                )
            )
        )
        .Init("Cthu Star Bomb",
            new State(
                new State("Idle",
                new ConditionalEffect(ConditionEffectIndex.Invincible)
                ),
                new State("Order1",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(1.7, 9.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 12, 0, projectileIndex: 0, 0.5, 0.5, coolDown: 1500, seeInvis: true)
                ),
                new State("Order2",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(1.7, 4.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 4, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 500, seeInvis: true)
                ),
                new State("Order3",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(0.7, 2.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                    new RingAttack(270, 4, 0, projectileIndex: 0, 0.4, 0.4, coolDown: 2000, seeInvis: true)
                ),
                new State("Order4",
                new ConditionalEffect(ConditionEffectIndex.Invincible),
                new Orbit(2.2, 8.5, target: "Stargazer High Priest", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                new RingAttack(270, 14, 0, projectileIndex: 0, 0.5, 0.5, coolDown: 1000, seeInvis: true)
                ),
                new State("Order5",
                new Suicide()
                )
            )
        );
    }
}
