﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.transitions;
using wServer.logic.loot;
//by GhostMaree
namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ HauntedCemeteryGraves = () => Behav()
            .Init("Arena Risen Brawler",
                new State(
                    new Shoot(radius: 10, count: 3, shootAngle: 10, projectileIndex: 0, coolDown: 2000),
                    new Prioritize(
                        new Orbit(speed: 0.7, radius: 1, acquireRange: 14, target: null),
                        new Follow(speed: 0.6, acquireRange: 10, range: 7)
                    )
                )
            )
            .Init("Arena Risen Warrior",
                new State(
                    new Shoot(radius: 4, projectileIndex: 0, coolDown: 1200),
                    new Prioritize(
                        new Follow(speed: 0.9, acquireRange: 10, range: 1.2),
                        new Orbit(speed: 0.4, radius: 3, acquireRange: 10, target: null)
                    )
                )
            )
            .Init("Arena Risen Mage",
                new State(
                    new Shoot(radius: 10, projectileIndex: 0, coolDown: 1000),
                    new Prioritize(
                        new Follow(speed: 0.9, acquireRange: 10, range: 7),
                        new Orbit(speed: 0.4, radius: 3, acquireRange: 10,target: null)
                    ),
                    new HealGroup(range: 7, group: "Hallowrena", coolDown: 2500, healAmount: 175)
                )
            )
            .Init("Arena Risen Archer",
                new State(
                    new Shoot(radius: 10, count: 3, shootAngle: 33, projectileIndex: 0, coolDown: 3000),
                    new Shoot(radius: 10, count: 1, projectileIndex: 1, coolDown: 1300),
                    new Prioritize(
                        new Orbit(speed: 0.4, radius: 6, acquireRange: 10, target: null),
                        new Follow(speed: 0.8, acquireRange: 10, range: 7)
                    )
                )
            )
            .Init("Arena Blue Flame",
                new State(
                    new State("Ini",
                        new Orbit(speed: 1.6, radius: 1.5, acquireRange: 15, target: "Arena Grave Caretaker"),
                        new PlayerWithinTransition(dist: 3, targetState: "AttackPlayer", seeInvis: true)
                    ),
                    new State("AttackPlayer",
                        new Charge(speed: 4.1, range: 9),
                        new PlayerWithinTransition(dist: 1, targetState: "Explode", seeInvis: true),
                        new PlayerWithinTransition(dist: 4, targetState: "Follow", seeInvis: true)
                    ),
                    new State("Follow",
                        new Follow(speed: 1, acquireRange: 6, range: 0.5),
                        new PlayerWithinTransition(dist: 1, targetState: "Explode", seeInvis: true)
                    ),
                    new State("Explode",
                        new Shoot(radius: 6, count: 10, shootAngle: 36, projectileIndex: 0, fixedAngle: 18),
                        new Suicide()
                    )
                )
            )
            .Init("Arena Grave Caretaker",
                new State(
                    new HPScale(35),
                    new State("Ini",
                        new Prioritize(
                            new StayBack(speed: 0.6, distance: 4, entity: null),
                            new Wander(speed: 0.3)
                        ),
                        new Shoot(radius: 8, count: 1, projectileIndex: 0, coolDown: 1000),
                        new Shoot(radius: 8, count: 2, shootAngle: 45, projectileIndex: 1, coolDown: 1000),
                        new Spawn(children: "Arena Blue Flame", maxChildren: 5, initialSpawn: 0, coolDown: 1000, givesNoXp: true),
                        new TimedTransition(time: 10000, targetState: "Circle")
                    ),
                    new State("Circle",
                        new Orbit(speed: 0.8, radius: 3, acquireRange: 10, target: null),
                        new Shoot(radius: 8, count: 2, shootAngle: 45, projectileIndex: 1, coolDown: 1000),
                        new Spawn(children: "Arena Blue Flame", maxChildren: 5, initialSpawn: 0, coolDown: 2000, givesNoXp: true),
                        new TimedTransition(time: 8000, targetState: "Ini")
                    )
                ),
                new Threshold(0.01,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.01,
                    new ItemLoot("Speed Fragment", 0.05),
                    new ItemLoot("Wisdom Fragment", 0.05),
                    new ItemLoot("Potion Tablet", .05),
                    new ItemLoot("Old Gravestone", 0.02),
                    new ItemLoot("Potion of Speed", 0.3, 3),
                    new ItemLoot("Potion of Wisdom", 0.3)
                )
            )
            ;
    }
}
