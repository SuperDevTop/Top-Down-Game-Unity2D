﻿using common.resources;
using System.Runtime.CompilerServices;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ MarbleColossus = () => Behav()
          .Init("LH Realm Sentry",
            new State(
                new HPScale(35),
                new DropPortalOnDeath("Lost Halls Portal"),
                    new State("1",
                        new Wander(0.3),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, predictive: 1, coolDown: 2000),
                        new TimedTransition(750, "2")
                        ),
                      new State("2",
                        new Wander(0.3),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 1, predictive: 1, coolDown: 2000),
                        new TimedTransition(750, "3")
                          ),
                      new State("3",
                        new Wander(0.3),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 2, predictive: 1, coolDown: 2000),
                        new TimedTransition(750, "1")
                            ),
                      new State("End",
                        new Prioritize(
                            new Follow(1.5, 20, 1),
                            new Wander(1.5)
                            )
                      )
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                    ),
                new Threshold(0.0005,
                    new ItemLoot("Robe of The Deathless Ghost", 0.02),
                    new ItemLoot("Spectral Ring", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Ghastly Scythe", 0.005),
                    new ItemLoot("Spectral Cloak", 0.005)
                  )
        )
            .Init("LH Marble Colossus",
            new State(
                new HPScale(30),
                    new State("FindPlayer",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(6, "Lightup1")
                        ),
                    new State("Lightup1",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(0),
                        new TimedTransition(1500, "Lightup2")
                        ),
                    new State("Lightup2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(1),
                        new TimedTransition(1500, "Lightup3")
                        ),
                    new State("Lightup3",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(2),
                        new TimedTransition(1500, "Lightup4")
                        ),
                    new State("Lightup4",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(3),
                        new TimedTransition(1500, "Check")
                        ),
                    new State("Check",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new SetAltTexture(4),
                        new Flash(0xFFFFFF, 1, 2),
                        new TimedTransition(2000, "Fight1")
                        ),
                    new State("Fight1",
                        new ConditionalEffect(ConditionEffectIndex.Armored),
                        new Taunt("Look upon my mighty bulwark."),
                        new Order(30, "Marble Paralyze Pillar", "On"),
                        new Order(30, "Marble Bleed Pillar", "On"),
                        new Order(30, "Marble Daze Pillar", "On"),
                        new Order(30, "Marble Confuse Pillar", "On"),
                        new Shoot(50, count: 12, shootAngle: 36, projectileIndex: 1, coolDown: 1000),
                        new HpLessTransition(0.96, "Fight2")
                        ),
                    new State("Fight2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("You doubt my strength? FATUUS! I will destroy you!"),
                        new Follow(1.2, range: 1, coolDown: 0),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 3, coolDown: 1000),
                        new Shoot(50, count: 5, shootAngle: 18, projectileIndex: 2, coolDown: 1000),
                        new TimedTransition(5500, "Fight2p2")
                         ),
                    new State("Fight2p2",
                        new Flash(0xFFFFFF, 99999, 1),
                        new Follow(1.2, range: 1, coolDown: 0),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 3, coolDown: 1000),
                        new Shoot(50, count: 5, shootAngle: 18, projectileIndex: 2, coolDown: 1000),
                        new HpLessTransition(0.88, "Return")
                        ),
                    new State("Return",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(4),
                        new TimedTransition(2500, "Fight3")
                        ),
                    new State("Fight3",
                        new Taunt("I cast you off!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Spawn("LH Colossus Rock 1", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 2", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 3", initialSpawn: 1, maxChildren: 1),
                        new TimedTransition(2750, "Fight3p2")
                        ),
                    new State("Fight3p2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Spawn("LH Colossus Rock 4", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 5", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 6", initialSpawn: 1, maxChildren: 1),
                        new TimedTransition(2750, "Fight3p3")
                        ),
                    new State("Fight3p3",
                        new Spawn("LH Colossus Rock 1", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 2", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 3", initialSpawn: 1, maxChildren: 1),
                        new TimedTransition(2750, "Fight3p4"),
                        new HpLessTransition(0.79, "QuadForce")
                        ),
                    new State("Fight3p4",
                        new Spawn("LH Colossus Rock 4", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 5", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 6", initialSpawn: 1, maxChildren: 1),
                        new TimedTransition(2750, "Fight3p3"),
                        new HpLessTransition(0.79, "QuadForce")
                        ),
                    new State("QuadForce",
                        new Taunt("Your fervent attacks are no match for my strength! BEGONE!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable, duration: 5000),
                        new Shoot(50, count: 8, fixedAngle: 1.8, rotateAngle: 1.8, projectileIndex: 0, coolDown: 70),
                        new Shoot(50, count: 16, projectileIndex: 4, shootAngle: 22.5, coolDown: 2500),
                        new Shoot(50, count: 3, projectileIndex: 5, shootAngle: 8, coolDown: 5000),
                        new HpLessTransition(0.63, "Glow")
                        ),
                    new State("Glow",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Flash(0xFFFFFF, 1, 2),
                        new TimedTransition(1000, "Orbit")
                        ),
                    new State("Orbit",
                        new Taunt("INSOLENTIA! Darkness will consume you!"),
                        new Orbit(0.8, 6, target: "LH Orbit"),
                        new Grenade(3, 40, 6, coolDown: 2000),
                        new Shoot(50, count: 3, projectileIndex: 6, shootAngle: 15, coolDown: 500),
                        new Shoot(50, count: 1, projectileIndex: 7, coolDown: 250),
                        new Shoot(50, count: 2, projectileIndex: 7, shootAngle: 360, coolDown: 250),
                        new HpLessTransition(0.55, "Return2")
                        ),
                    new State("Return2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(1),
                        new TimedTransition(1000, "MixQuadForce")
                        ),
                    new State("MixQuadForce",
                        new Taunt("Brace for your demise!"),
                        new Reproduce("LH Colossus Rock 7", densityMax: 999, coolDown: 1250),
                        new Reproduce("LH Colossus Rock 8", densityMax: 999, coolDown: 1250),
                        new Reproduce("LH Colossus Rock 9", densityMax: 999, coolDown: 1250),
                        new Reproduce("LH Colossus Rock 10", densityMax: 999, coolDown: 1250),
                        new Shoot(50, count: 2, fixedAngle: 3, rotateAngle: 3, projectileIndex: 7, coolDown: 300),
                        new HpLessTransition(0.42, "RingBall")
                        ),
                    new State("RingBall",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Taunt("Futility!"),
                        new Grenade(2, 0, 30, coolDown: 1500, color: 0, effect: ConditionEffectIndex.Quiet, effectDuration: 1500),
                        new Shoot(50, count: 24, projectileIndex: 8, shootAngle: 15, coolDown: 1500),
                        new Shoot(50, count: 48, projectileIndex: 10, shootAngle: 7.5, coolDown: 1500),
                        new TimedTransition(15000, "Chase")
                        ),
                    new State("Chase",
                        new Taunt("Call of voice, for naught. Plea of mercy, for naught. None may enter this chamber and live!!"),
                        new Follow(1.2, range: 1, coolDown: 0),
                        new Shoot(50, count: 16, shootAngle: 22.5, projectileIndex: 9, coolDown: 4000),
                        new HpLessTransition(0.32, "Return3")
                        ),
                    new State("Return3",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(1.5),
                        new TimedTransition(2000, "MixedQuadForce")
                        ),
                    new State("MixedQuadForce",
                        new Taunt("It is my duty to protect these catacombs! You dare threaten my purpose?"),
                        new Shoot(1, count: 4, projectileIndex: 22, coolDown: 300, fixedAngle: 90, rotateAngle: 10, coolDownOffset: 0, shootAngle: 90),
                        new Shoot(1, count: 4, projectileIndex: 22, coolDown: 300, fixedAngle: 180, rotateAngle: -10, coolDownOffset: 0, shootAngle: 90),
                        new TimedTransition(45000, "Spawn"),
                        new HpLessTransition(0.23, "Spawn")
                        ),
                    new State("Spawn",
                        //new Taunt("Magia saps from my bodyEMy immense physical strength STILL REMAINS!"),
                        new Spawn("LH Colossus Rock 1", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 2", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 3", initialSpawn: 1, maxChildren: 1),
                        new HpLessTransition(0.09, "QuadForce2"),
                        new TimedTransition(2000, "Spawn2")
                        ),
                    new State("Spawn2",
                        new Spawn("LH Colossus Rock 4", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 5", initialSpawn: 1, maxChildren: 1),
                        new Spawn("LH Colossus Rock 6", initialSpawn: 1, maxChildren: 1),
                        new HpLessTransition(0.09, "QuadForce2"),
                        new TimedTransition(2000, "Spawn")
                        ),
                    new State("QuadForce2",
                        new Taunt("You... YOU WILL COME WITH ME!"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Order(30, "Marble Paralyze Pillar", "Hard"),
                       new Order(30, "Marble Bleed Pillar", "Hard"),
                       new Order(30, "Marble Daze Pillar", "Hard"),
                       new Order(30, "Marble Confuse Pillar", "Hard"),
                        new Shoot(50, count: 8, fixedAngle: 1.9, rotateAngle: 1.9, projectileIndex: 0, coolDown: 70),
                        new Shoot(50, count: 18, projectileIndex: 4, shootAngle: 22.5, coolDown: 2000),
                        new Grenade(2.5, 200, 30, coolDown: 2000),
                        new Shoot(50, count: 5, projectileIndex: 5, shootAngle: 9, coolDown: 4000),
                        new TimedTransition(20000, "End")
                        ),
                     new State("End",
                       new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                       new Flash(0x9400D3, 1000, 6),
                       new Taunt("I Feel... Myself... Slipping into the void... Its so dark..."),
                       new TimedTransition(5000, "End2")
                          ),
                        new State("End2",
                       new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                       new Order(30, "Marble Paralyze Pillar", "Death"),
                       new Order(30, "Marble Bleed Pillar", "Death"),
                       new Order(30, "Marble Daze Pillar", "Death"),
                       new Order(30, "Marble Confuse Pillar", "Death"),
                         new Shoot(12, projectileIndex: 14, count: 48),
                         new Shoot(12, projectileIndex: 13, count: 48),
                         new Shoot(12, projectileIndex: 12, count: 48),
                         new Shoot(12, projectileIndex: 10, count: 48),
                         new Shoot(12, projectileIndex: 8, count: 48),
                         new Suicide()
                            )
                         ),
            new Threshold(0.0005,
                    new ItemLoot("Life Fragment", 0.05),
                    new ItemLoot("Mana Fragment", 0.05),
                    new ItemLoot("Attack Fragment", 0.05),
                    new ItemLoot("Defense Fragment", 0.05),
                    new ItemLoot("Critical Hit Fragment", 0.05),
                    new ItemLoot("Potion of Attack", 1),
                    new ItemLoot("Potion of Defense", 1),
                    new ItemLoot("Potion Tablet", 1),
                    new ItemLoot("Potion of Life", 1),
                    new ItemLoot("Potion of Mana", 1),
                    new ItemLoot("Marble Lootbox", 0.1),
                    new TierLoot(13, ItemType.Weapon, 0.10),
                    new TierLoot(6, ItemType.Ability, 0.05),
                    new TierLoot(14, ItemType.Armor, 0.10),
                    new TierLoot(6, ItemType.Ring, 0.05)
                ),
                new Threshold(0.02,
                    new ItemLoot("Staff of Unholy Sacrifice", 0.005),
                    new ItemLoot("Skull of Corrupted Souls", 0.005),
                    new ItemLoot("Ritual Robe", 0.005),
                    new ItemLoot("Bloodshed Ring", 0.005),
                    new ItemLoot("Sword of the Colossus", 0.005),
                    new ItemLoot("Marble Seal", 0.005),
                    new ItemLoot("Lost Halls Key", 0.008),
                    new ItemLoot("Breastplate of New Life", 0.005),
                    new ItemLoot("Magical Lodestone", 0.005),
                    new ItemLoot("Cloak of Bloody Surprises", 0.005),
                    new ItemLoot("Bow of the Void", 0.005),
                    new ItemLoot("Quiver of the Shadows", 0.005),
                    new ItemLoot("Armor of Nil", 0.005),
                    new ItemLoot("Sourcestone", 0.005),
                    new ItemLoot("Shard of Divinity", 0.0025),
                    new ItemLoot("Omnipotence Ring", 0.005),
                    new ItemLoot("Tears of Nihil", 0.000001)
                    )
            )
        .Init("Marble Paralyze Pillar",
            new State(
                    new State("Off",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                    ),
                    new State("On",
                        new Shoot(50, count: 4, shootAngle: 90, projectileIndex: 0, coolDown: 3000),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                    ),
                    new State("Hard",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(90, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Death",
                        new Suicide()
                       )
                    )
                )
        .Init("Marble Bleed Pillar",
            new State(
                    new State("Off",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                    ),
                    new State("On",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(50, count: 4, shootAngle: 90, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Hard",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(90, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Death",
                        new Suicide()
                       )
                    )
                )
        .Init("Marble Daze Pillar",
            new State(
                    new State("Off",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                    ),
                    new State("On",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(50, count: 4, shootAngle: 90, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Hard",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(90, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Death",
                        new Suicide()
                       )
                    )
                )
        .Init("Marble Confuse Pillar",
            new State(
                    new State("Off",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable)
                    ),
                    new State("On",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(90, count: 4, shootAngle: 90, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Hard",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new Shoot(90, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 3000)
                    ),
                    new State("Death",
                        new Suicide()
                       )
                    )
                )
        #region rocks
          .Init("LH Colossus Rock 1",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 135),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                )
                       )
            )
          .Init("LH Colossus Rock 2",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 225),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                              )
                       )
            )
          .Init("LH Colossus Rock 3",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 0),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                        )
                       )
            )
          .Init("LH Colossus Rock 4",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 325),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                    )
                       )
            )
          .Init("LH Colossus Rock 5",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 45),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                    )
                       )
            )
          .Init("LH Colossus Rock 6",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 180),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                                                )
                       )
            )
          .Init("LH Colossus Rock 7",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 90),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                                                )
                       )
            )
          .Init("LH Colossus Rock 8",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 180),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                                                )
                       )
            )
          .Init("LH Colossus Rock 9",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 270),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                                                                                                                )
                       )
            )
          .Init("LH Colossus Rock 10",
            new State(
                    new State("Move",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new MoveLine(0.3, 360),
                        new TimedTransition(1500, "LightUp")
                        ),
                        new State("LightUp",
                        new Flash(0xFFFFFF, 1, 2),
                        new Shoot(50, count: 8, shootAngle: 45, projectileIndex: 0, coolDown: 500),
                        new TimedTransition(500, "Death")
                        ),
                        new State("Death",
                        new Suicide()
                    )
                )
            )
        #endregion
         .Init("Eye of Marble",
             new State(
               new State("Idle",
               new HealPlayer(4, 1000, 50),
               new TimedTransition(4500, "die")
                   ),
              new State("die",
              new Decay(0)
                                )
                       )
            )
                .Init("LH Orbit",
                new State(
                  new ConditionalEffect(ConditionEffectIndex.Invincible)
                )
            );
    }
}
