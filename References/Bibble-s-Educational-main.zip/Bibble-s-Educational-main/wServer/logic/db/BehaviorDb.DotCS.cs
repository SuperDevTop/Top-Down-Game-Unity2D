﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ DotCS = () => Behav()
            .Init("DotCS Yatagarasu",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new Wander(0.4),
                            new Grenade(4, 100, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0xca5f12, coolDown: 5000),
                            new Shoot(15, count: 5, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 2500),
                            new HpLessTransition(0.25, "rage")
                            ),
                        new State("rage",
                            new Follow(0.8, 13, 2),
                            new Flash(0xff0000, 0.2, 9999),
                            new Grenade(4, 190, range: 12, effect: ConditionEffectIndex.Bleeding, effectDuration: 3000, color: 0xca5f12, coolDown: 2500),
                            new Shoot(15, count: 5, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 2500)
                            )
                        )
                )
            .Init("DotCS Oni",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new Prioritize(
                            new Follow(1.5, 8, 1),
                            new Wander(0.3)
                                ),
                        new State("attack",
                            new Grenade(3, 100, range: 0, fixedAngle: 36, color: 0xca5f12, coolDown: 500),
                            new Shoot(15, count: 1, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                            new Shoot(15, count: 6, shootAngle: 6, projectileIndex: 1, predictive: 0.3, coolDown: 2000)
                            )
                        )
            )
            .Init("DotCS Kappa",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new StayBack(0.5, 4),
                            new Wander(0.4),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                            new HpLessTransition(0.50, "waves")
                            ),
                        new State("waves",
                            new StayBack(0.5, 3),
                            new Follow(1, 2, 1),
                            new Shoot(15, count: 2, shootAngle: 6, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                            new Shoot(15, count: 8, projectileIndex: 1, coolDown: 4000),
                            new HpLessTransition(0.35, "rage")
                            ),
                        new State("rage",
                            new Follow(0.8, 15, 1),
                            new Flash(0x2d00b0, 0.2, 9999),
                            new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 1500),
                            new Shoot(15, count: 10, projectileIndex: 2, coolDown: 3000)
                            )
                        )
                    )
        .Init("DotCS Yuki Onna",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new Wander(0.3),
                            new Shoot(15, count: 2, shootAngle: 0, projectileIndex: 0, predictive: 0.3, coolDown: 2500),
                            new HpLessTransition(0.50, "rage")
                            ),
                        new State("rage",
                            new Follow(1.4, 13, 0),
                            new Flash(0x11c2e5, 0.2, 9999),
                            new Grenade(4, 10, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Paralyzed, effectDuration: 1500, color: 0xdde90c, coolDown: 2000),
                            new Grenade(5, 10, range: 0, fixedAngle: 36, effect: ConditionEffectIndex.Slowed, effectDuration: 2500, color: 0x170b7b, coolDown: 3000),
                            new Grenade(6, 300, range: 0, fixedAngle: 36, color: 0x10b0b9, coolDown: 3000)
                            )
                        )
                    )
        .Init("DotCS Tsuchigomo",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("web",
                            new Follow(0.8, 13, 1),
                            new Shoot(15, count: 3, shootAngle: 4, projectileIndex: 0, predictive: 1, coolDown: 1000),
                            new HpLessTransition(0.25, "rage"),
                            new TimedTransition(2000, "bite")
                            ),
                        new State("bite",
                            new Follow(1.3, 13, 0),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 1500),
                            new HpLessTransition(0.35, "rage"),
                            new TimedTransition(3000, "web")
                            ),
                        new State("rage",
                            new Follow(1.5, 13, 0),
                            new Flash(0x08d72e, 0.2, 9999),
                            new Shoot(15, count: 6, shootAngle: 5, projectileIndex: 0, predictive: 1, coolDown: 1500),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, predictive: 1, coolDown: 500)
                            )
                        )
                    )
        .Init("DotCS Nurikabe",
                    new State(
                    new ScaleHP(14000, 0, true, 10, 1),
                        new State("walk",
                            new Follow(0.3, 13, 0),
                            new ReproduceChildren(3, .5, 5000, "DotCS Tree Youkai"),
                            new Shoot(15, count: 30, projectileIndex: 0, coolDown: 2000)
                            )
                        )
                    )
        .Init("DotCS Tree Youkai",
                    new State(
                    new ScaleHP(2000, 0, true, 10, 1),
                        new Prioritize(
                            new Orbit(1.3, 2, target: "DotCS Tsuchigomo", acquireRange: 10, speedVariance: 0, radiusVariance: 0),
                            new Wander(0.4)
                                ),
                        new State("attack",
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, predictive: 0.3, coolDown: 500)
                            )
                        )
                    )
        .Init("DotCS Tengu",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new StayBack(0.5, 5),
                            new Wander(0.4),
                            new Shoot(15, count: 5, shootAngle: 6, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                            new HpLessTransition(0.45, "rage")
                            ),
                        new State("rage",
                            new StayBack(0.5, 6),
                            new Wander(0.4),
                            new Flash(0xbdbdbd, 0.2, 9999),
                            new Shoot(15, count: 3, shootAngle: 5, projectileIndex: 0, predictive: 0.3, coolDown: 1500),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, predictive: 0.3, coolDown: 500)
                            )
                        )
                    )
        .Init("DotCS Kamaitachi",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new Follow(0.6, 13, 0),
                            new Wander(0.4),
                            new Shoot(15, count: 5, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 3000),
                            new HpLessTransition(0.40, "rage")
                            ),
                        new State("rage",
                            new Follow(1.2, 13, 0),
                            new Flash(0x6e8d64, 0.2, 9999),
                            new Grenade(3, 150, range: 4, fixedAngle: 36, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 72, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 108, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 144, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 180, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 216, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 252, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 288, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 324, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 360, color: 0x000000, coolDown: 4000),
                            new Grenade(3, 150, range: 4, fixedAngle: 360, color: 0x000000, coolDown: 4000),
                            new Shoot(15, count: 8, shootAngle: 7, projectileIndex: 0, predictive: 0.3, coolDown: 2500)
                            )
                        )
                    )
        .Init("DotCS Kirin",
                    new State(
                    new ScaleHP(10000, 0, true, 10, 1),
                        new State("attack",
                            new Wander(0.4),
                            new Grenade(2, 300, range: 8, effect: ConditionEffectIndex.Paralyzed, effectDuration: 1300, color: 0xf3cd00, coolDown: 3000),
                            new HpLessTransition(0.50, "rage")
                            ),
                        new State("rage",
                            new Follow(1.4, 13, 0),
                            new Flash(0xcee014, 0.2, 9999),
                            new Grenade(4, 10, range: 7, effect: ConditionEffectIndex.Paralyzed, effectDuration: 2000, color: 0xf3cd00, coolDown: 6000),
                            new Grenade(3, 200, range: 0, fixedAngle: 36, color: 0xff0000, coolDown: 1000)
                            )
                        )
                )
        .Init("DotCS Terminator MKII",
                    new State(
                    new ScaleHP(12000, 0, true, 10, 1),
                        new State("attack",
                            new StayBack(0.5, 2),
                            new Wander(0.2),
                            new Shoot(15, count: 2, shootAngle: 3, projectileIndex: 0, predictive: 0.3, coolDown: 350),
                            new HpLessTransition(0.50, "charge")
                            ),
                        new State("charge",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Wander(0.2),
                            new Flash(0xcee014, 0.2, 9999),
                            new Shoot(15, count: 3, shootAngle: 4, projectileIndex: 0, predictive: 0.3, coolDown: 100),
                            new TimedTransition(2000, "fire")
                            ),
                        new State("fire",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Wander(0.2),
                            new Shoot(15, count: 1, projectileIndex: 1, coolDown: 2100),
                            new TimedTransition(2000, "weak")
                            ),
                        new State("weak",
                            new ConditionalEffect(ConditionEffectIndex.ArmorBroken),
                            new StayBack(0.5, 3),
                            new Wander(0.2),
                            new Flash(0xde1616, 0.2, 9999),
                            new TimedTransition(2000, "charge")
                            )
                        )
                    )
            .Init("DotCS Gashadokuro",
                    new State(
                    new HPScale(40),
                        new State("Activate",
                            new TimedTransition(2000, "Awaken 1")
                            ),
                        new State("Awaken 1",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("Hmm..."),
                            new TimedTransition(3000, "Awaken 2")
                            ),
                        new State("Awaken 2",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("What do i see with my little eye... humans!"),
                            new TimedTransition(3500, "Awaken 3")
                            ),
                        new State("Awaken 3",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("Oh so delightful... I have been starving for ages!"),
                            new TimedTransition(4000, "Awaken 4")
                            ),
                        new State("Awaken 4",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("I shall bite off your heads and drink the blood out of your corpses!"),
                            new TimedTransition(3500, "Attack")
                            ),
                        new State("Attack",
                            new Swirl(1, 10, targeted: false),
                            new RingAttack(20, 16, 0, projectileIndex: 2, 2, 2, coolDown: 4500),
                            new RingAttack(20, 12, 0, projectileIndex: 0, 2, 2, coolDown: 1500),
                            new Shoot(15, count: 5, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1500),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 2, predictive: 0.3, coolDown: 750),
                            new HpLessTransition(0.80, "Return 1"),
                            new TimedTransition(8000, "Attack 2")
                            ),
                        new State("Attack 2",
                            new Follow(1.2, 13, 0),
                            new RingAttack(20, 4, 0, projectileIndex: 0, 0.5, 0.5, coolDown: 100, seeInvis: true),
                            new Shoot(15, count: 3, shootAngle: 10, projectileIndex: 2, predictive: 0.3, coolDown: 500),
                            new Grenade(2.5, 125, range: 14, color: 0xff0000, coolDown: 500),
                            new HpLessTransition(0.80, "Return 1"),
                            new TimedTransition(3000, "Back")
                            ),
                        new State("Back",
                            new ReturnToSpawn(speed: 1.40),
                            new HpLessTransition(0.80, "Return 1"),
                            new TimedTransition(5000, "Attack")
                            ),
                        new State("Return 1",
                            new SetAltTexture(1),
                            new Taunt("Oh there goes my arm... I shall remake one with your spines!"),
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new ReturnToSpawn(speed: 0.52),
                            new TimedTransition(4000, "Assult")
                            ),
                        new State("Assult",
                            new Follow(1.2, 13, 0),
                            new ReproduceChildren(3, 0, 5000, "DotCS Lil Skelly Warrior"),
                            new RingAttack(20, 20, 0, projectileIndex: 4, 2, 2, coolDown: 1500),
                            new RingAttack(20, 4, 0, projectileIndex: 7, 180, 180, coolDown: 3000),
                            new Shoot(15, count: 6, shootAngle: 10, projectileIndex: 3, predictive: 0.3, coolDown: 1500),
                            new Grenade(2.5, 200, range: 14, effect: ConditionEffectIndex.Slowed, effectDuration: 1500, color: 0xff0000, coolDown: 4500),
                            new HpLessTransition(0.60, "Return 2")
                            ),
                        new State("Return 2",
                            new SetAltTexture(2),
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new ReturnToSpawn(speed: 0.52),
                            new TimedTransition(3000, "Tentacle")
                            ),
                        new State("Tentacle",
                            new Taunt("My skeletons have a bone to pick with you KYEHEHEHEHE!"),
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new ReproduceChildren(4, 0, 3000, "DotCS Lil Skelly"),
                            new Shoot(15, count: 1, projectileIndex: 7, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 3, shootAngle: 10, projectileIndex: 2, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 2, shootAngle: 180, projectileIndex: 3, predictive: 0.3, coolDown: 750),
                            new RingAttack(20, 4, 0, projectileIndex: 8, 0.10, 0.10, coolDown: 100, seeInvis: true),
                            new TimedTransition(25000, "Change 1")
                            ),
                        new State("Change 1",
                            new SetAltTexture(3),
                            new Taunt("There goes my other arm. Forget your bones, i shall disintegrate you!"),
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new TimedTransition(6000, "Beam")
                            ),
                        new State("Beam",
                            new Wander(0.3),
                            new RingAttack(20, 16, 0, projectileIndex: 6, 2, 2, coolDown: 3000),
                            new Shoot(15, count: 1, projectileIndex: 5, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 1, projectileIndex: 9, coolDown: 1500),
                            new Grenade(2, 200, range: 7, fixedAngle: 36, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 72, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 108, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 144, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 180, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 216, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 252, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 288, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 324, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 360, color: 0xff0000, coolDown: 6000),
                            new Grenade(2, 200, range: 7, fixedAngle: 360, color: 0xff0000, coolDown: 6000),
                            new HpLessTransition(0.40, "Return Fallen")
                            ),
                        new State("Return Fallen",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new ReturnToSpawn(speed: 1.52),
                            new TimedTransition(1500, "The Fallen Spawn")
                            ),
                        new State("The Fallen Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("KYEHEHEHE. Let's see how you will fare against my guardians!"),
                            new TossObject("DotCS Fallen Soilder", 5, angle: 180, coolDown: 500000, throwEffect: true),
                            new TossObject("DotCS Fallen Shield Bearer", 5, angle: 360, coolDown: 500000, throwEffect: true),
                            new TimedTransition(5500, "The Fallen")
                            ),
                        new State("The Fallen",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("CRUSH THEIR BONES. I WANT TO HEAR THEM BREAK AND SHATTER KYEHEHEHEHE!"),
                            new ReproduceChildren(3, 0, 8000, "DotCS Skelly Hands"),
                            new RingAttack(20, 8, 0, projectileIndex: 3, 90, 90, coolDown: 8000),
                            new EntityNotExistsTransition("DotCS Fallen Shield Bearer", 100, "Rage")
                            ),
                        new State("Rage",
                            new Taunt("KYEHEHEHE. NO MORE PLAYING AROUND. YOU SHALL BE CRUSHED UNDER MY FOOT!"),
                            new Flash(0xe60b0b, 0.2, 40),
                            new Follow(0.9, 13, 0),
                            new Shoot(15, count: 1, projectileIndex: 10, predictive: 0.3, coolDown: 1000),
                            new Shoot(15, count: 2, shootAngle: 180, projectileIndex: 9, predictive: 0.3, coolDown: 500),
                            new Grenade(2.5, 150, range: 10, color: 0xff0000, coolDown: 500),
                            new HpLessTransition(0.20, "Return 3"),
                            new TimedTransition(7500, "Rage 2")
                            ),
                        new State("Rage 2",
                            new Flash(0xe60b0b, 0.1, 80),
                            new Follow(1.4, 15, 0),
                            new Shoot(15, count: 5, shootAngle: 10, projectileIndex: 5, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 24, 0, projectileIndex: 6, 50, 50, coolDown: 3000, seeInvis: true),
                            new Grenade(5, 200, range: 0, fixedAngle: 36, color: 0xff0000, coolDown: 1000),
                            new HpLessTransition(0.20, "Return 3"),
                            new TimedTransition(7500, "Rage")
                            ),
                        new State("Return 3",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("KYEHEHEHEHE! LET'S SEE HOW YOU WILL CONTEND AGAINST MY ARMY!"),
                            new ReturnToSpawn(speed: 0.75),
                            new TimedTransition(5000, "Army Spawn")
                            ),
                        new State("Army Spawn",
                            new SetAltTexture(4),
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("RISE, FALLEN ONES!"),
                            new TossObject("DotCS Tokugawa Fallen General", 5, angle: 360, coolDown: 500000, throwEffect: true),
                            new TimedTransition(3500, "The Army")
                            ),
                        new State("The Army",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("SWARM THEM!"),
                            new Shoot(15, count: 1, projectileIndex: 5, predictive: 0.3, coolDown: 1500),
                            new EntityNotExistsTransition("DotCS Tokugawa Fallen General", 100, "Final")
                            ),
                        new State("Final",
                            new TransformOnDeath("DotCS Dokuro Beam Anim"),
                            new TransferDamageOnDeath("DotCS Dokuro Beam Anim"),
                            new Suicide()
                            )
                        )
                    )
        .Init("DotCS Dokuro Beam Anim",
                    new State(
                    new HPScale(30),
                        new State("Wait",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new TimedTransition(2000, "Dying")
                            ),
                        new State("Dying",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new TransformOnDeath("DotCS Dokuro Beam"),
                            new TransferDamageOnDeath("DotCS Dokuro Beam"),
                            new Suicide()
                            )
                        )
                    )
        .Init("DotCS Dokuro Beam",
                    new State(
                    new HPScale(30),
                        new State("Final",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("KYEHEHEHE! I HAVE THE WEIGHT OF COUNTLESS FALLEN SOLDIERS AND OF THOSE WHO HAVE DIED TO FAMINE. YOU SHALL FEEL TRUE PAIN!"),
                            new ReproduceChildren(5, 0, 5000, "DotCS Lil Skelly"),
                            new ReproduceChildren(2, 0, 3000, "DotCS Lil Skelly Warrior"),
                            new Shoot(15, count: 1, projectileIndex: 10, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 24, 0, projectileIndex: 6, 50, 50, coolDown: 2000, seeInvis: true),
                            new Grenade(2.5, 200, range: 14, effect: ConditionEffectIndex.Slowed, effectDuration: 1500, color: 0xff0000, coolDown: 4500),
                            new RingAttack(20, 6, 0, projectileIndex: 11, 0.03, 0.03, coolDown: 100, seeInvis: true),
                            new TimedTransition(25000, "Dying")
                            ),
                        new State("Dying",
                            new TransformOnDeath("DotCS Dokuro Dying Static"),
                            new TransferDamageOnDeath("DotCS Dokuro Dying Static"),
                            new Suicide()
                            )
                        )
                    )
        .Init("DotCS Dokuro Dying Static",
                    new State(
                    new HPScale(30),
                        new State("Dying 1",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("KYEHEHEHE, THAT WAS FUN."),
                            new TimedTransition(3500, "Dying 2")
                            ),
                        new State("Dying 2",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("BUT ALAS, YOU SHALL NOT GET FAR IN THIS PLACE."),
                            new TimedTransition(3500, "Dying 3")
                            ),
                        new State("Dying 3",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("MY BRETHREN, THE YOUKAI, SHALL SLAUGHTER EVERY SINGLE ONE OF YOU."),
                            new TimedTransition(3500, "Dying 4")
                            ),
                        new State("Dying 4",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("AND YOUR BONES... THEY WILL BE USED TO REVIVE ME AGAIN!"),
                            new TimedTransition(3500, "Dying 5")
                            ),
                        new State("Dying 5",
                            new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                            new Taunt("KYEHEHEHEHEHEHE!"),
                            new TimedTransition(3500, "Die")
                            ),
                        new State("Die",
                            new TransformOnDeath("DotCS Dokuro Dying"),
                            new TransferDamageOnDeath("DotCS Dokuro Dying"),
                            new Suicide()
                            )
                        )
                    )
        .Init("DotCS Dokuro Dying",
                    new State(
                    new HPScale(30),
                        new State("Wait",
                            new TimedTransition(3120, "Die")
                            ),
                        new State("Die",
                            new RemoveObjectOnDeath("DotCS Elemental Aura Barrier", 50),
                            new Suicide()
                            )
                        ),
                    new Threshold(0.01,
                    new ItemLoot("Keepsake of the Damned", 0.0066),
                    new ItemLoot("Skeletal Rapture", 0.0066),
                    new ItemLoot("Eye of Gashadokuro", 0.0066)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Ribcage of the Fallen", 0.0033),
                    new ItemLoot("Youkai Grimace", 0.0033),
                    new ItemLoot("Claw of the Giant Skeleton", 0.0033)
                    ),
                new Threshold(0.001,
                    new ItemLoot("Support Fragment", 1.0),
                    new ItemLoot("Greater Potion of Defense", 0.6),
                    new ItemLoot("Greater Potion of Dexterity", 0.6),
                    new ItemLoot("Greater Potion of Attack", 0.6),
                    new ItemLoot("Greater Potion of Vitality", 0.6),
                    new ItemLoot("Greater Potion of Wisdom", 0.6),
                    new ItemLoot("Greater Potion of Speed", 0.6),
                    new ItemLoot("Greater Potion of Life", 0.4),
                    new ItemLoot("Greater Potion of Mana", 0.4)
                )
            )
        .Init("DotCS Lil Skelly",
                    new State(
                    new ScaleHP(2500, 0, true, 10, 1),
                        new Prioritize(
                            new Follow(1.5, 15, 0)
                                ),
                        new State("attack",
                            new Shoot(15, count: 3, shootAngle: 6, projectileIndex: 0, predictive: 0.3, coolDown: 2000)
                            )
                        )
                    )
        .Init("DotCS Lil Skelly Warrior",
                    new State(
                    new ScaleHP(2500, 0, true, 10, 1),
                        new Prioritize(
                            new Orbit(1.5, 1, target: "DotCS Gashadokuro", acquireRange: 10, speedVariance: 0, radiusVariance: 0)
                                ),
                        new State("attack",
                            new Shoot(15, count: 2, shootAngle: 6, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new HpLessTransition(0.50, "Rage")
                            ),
                        new State("Rage",
                            new Shoot(15, count: 3, shootAngle: 25, projectileIndex: 0, predictive: 0.3, coolDown: 1000)
                            )
                        )
                    )
        .Init("DotCS Bone Pile",
                    new State(
                    new State("Waiting",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(7300, "Despawn")
                    ),
                    new State("Despawn",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TransformOnDeath("DotCS Gashadokuro"),
                        new Suicide()
                    )
                )
            )
        .Init("DotCS Bone Pile Static",
                    new State(
                        new State("Wait",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(12000, "Despawn")
                            ),
                    new State("Despawn",
                        new TransformOnDeath("DotCS Bone Pile")
                    )
                )
            )
        .Init("DotCS Fallen Soilder",
                    new State(
                    new HPScale(30),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(2000, "Ready")
                            ),
                        new State("Ready",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("Kill.. Kill, Fight.."),
                            new TimedTransition(4000, "Attack")
                            ),
                        new State("Attack",
                            new Taunt("MUST KILL!"),
                            new Follow(1.5, 13, 0),
                            new Shoot(15, count: 2, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 6, 0, projectileIndex: 1, 45, 45, coolDown: 1500, seeInvis: true),
                            new TimedTransition(3000, "Rush"),
                            new HpLessTransition(0.75, "Return")
                            ),
                        new State("Rush",
                            new Taunt("DESTROY!"),
                            new Flash(0xe60b0b, 0.2, 10),
                            new Follow(2, 13, 0),
                            new Shoot(15, count: 5, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 250),
                            new TimedTransition(2000, "Attack"),
                            new HpLessTransition(0.75, "Return")
                            ),
                        new State("Return",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("RAHH DIE!"),
                            new ReturnToSpawn(speed: 0.80),
                            new TimedTransition(4000, "Bone")
                            ),
                        new State("Bone",
                            new Taunt("DIE!"),
                            new Flash(0xe60b0b, 0.2, 10),
                            new Shoot(15, count: 1, projectileIndex: 2, predictive: 0.3, coolDown: 500),
                            new RingAttack(20, 6, 0, projectileIndex: 1, 45, 45, coolDown: 1500, seeInvis: true),
                            new HpLessTransition(0.50, "Attack 2")
                            ),
                        new State("Attack 2",
                            new Taunt("FINALLY WORTHY OPPENENTS!"),
                            new Follow(1.4, 13, 0),
                            new Shoot(15, count: 3, shootAngle: 15, projectileIndex: 0, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 5, shootAngle: 75, projectileIndex: 2, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 6, 0, projectileIndex: 1, 45, 45, coolDown: 1500, seeInvis: true),
                            new HpLessTransition(0.25, "Rage")
                            ),
                        new State("Rage",
                            new Taunt("NOW THIS IS A BATTLE!"),
                            new Flash(0xe60b0b, 0.1, 999999),
                            new Follow(3, 13, 0),
                            new Shoot(15, count: 4, shootAngle: 10, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 2, shootAngle: 25, projectileIndex: 2, predictive: 0.3, coolDown: 750),
                            new RingAttack(20, 8, 0, projectileIndex: 1, 45, 45, coolDown: 750, seeInvis: true)
                            )
                        )
                    )
        .Init("DotCS Fallen Shield Bearer",
                    new State(
                    new HPScale(30),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(2000, "Ready")
                            ),
                        new State("Ready",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("Must.. Protect..."),
                            new TimedTransition(4000, "Start")
                            ),
                        new State("Start",
                            new Taunt("MUST PROTECT HIM!"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Follow(0.5, 13, 0),
                            new Shoot(15, count: 2, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 1500),
                            new EntityNotExistsTransition("DotCS Fallen Soilder", 100, "Attack"),
                            new TimedTransition(6000, "Rush")
                            ),
                        new State("Rush",
                            new Taunt("LEAVE US!"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Follow(1.5, 13, 0),
                            new Flash(0xe60b0b, 0.2, 10),
                            new Shoot(15, count: 4, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 500),
                            new EntityNotExistsTransition("DotCS Fallen Soilder", 100, "Attack"),
                            new TimedTransition(2000, "Start")
                            ),
                        new State("Attack",
                            new Taunt("YOU KILLED HIM!"),
                            new Follow(1.0, 13, 0),
                            new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 6, 0, projectileIndex: 2, 45, 45, coolDown: 4000, seeInvis: true),
                            new HpLessTransition(0.70, "Return")
                            ),
                        new State("Return",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("I WILL DESTROY YOU!"),
                            new ReturnToSpawn(speed: 0.80),
                            new TimedTransition(4000, "Anger")
                            ),
                        new State("Anger",
                            new Taunt("I WON'T LET YOU GET AWAY!"),
                            new Follow(1.25, 13, 0),
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new Shoot(15, count: 4, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1250),
                            new Shoot(15, count: 5, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1500),
                            new HpLessTransition(0.50, "Weak")
                            ),
                        new State("Weak",
                            new Taunt("My.. Power.. Is.. Fading.."),
                            new Follow(1.0, 13, 0),
                            new Shoot(15, count: 5, shootAngle: 9, projectileIndex: 1, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 6, shootAngle: 45, projectileIndex: 2, coolDown: 1500),
                            new HpLessTransition(0.25, "Final")
                            ),
                        new State("Final",
                            new Taunt("I WILL FINISH YOU MYSELF!"),
                            new Flash(0xe60b0b, 0.1, 999999),
                            new Follow(1.5, 13, 0),
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new Shoot(15, count: 4, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1250),
                            new Shoot(15, count: 5, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1500),
                            new Shoot(15, count: 6, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1750),
                            new Shoot(15, count: 6, shootAngle: 45, projectileIndex: 2, coolDown: 1500)
                            )
                        )
                    )
        .Init("DotCS Skelly Hands",
                    new State(
                    new ScaleHP(1500, 0, true, 10, 1),
                        new State("Ingage",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Follow(1.8, 13, 0),
                            new TimedTransition(3000, "Attack")
                            ),
                        new State("Attack",
                            new Flash(0xe60b0b, 0.2, 30),
                            new Follow(1.0, 13, 0),
                            new RingAttack(20, 6, 0, projectileIndex: 0, 45, 45, coolDown: 1900, seeInvis: true),
                            new TimedTransition(4000, "Ingage")
                            )
                        )
                    )
        .Init("DotCS Lil Skelly Spearmen",
                    new State(
                    new ScaleHP(2500, 0, true, 10, 1),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(2000, "attack")
                            ),
                        new State("attack",
                            new Follow(0.35, 15, 0),
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 3000)
                            )
                        )
                    )
        .Init("DotCS Lil Skelly Rogue",
                    new State(
                    new ScaleHP(1500, 0, true, 10, 1),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(2000, "attack")
                            ),
                        new State("attack",
                            new Follow(1.5, 15, 0),
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 1250)
                            )
                        )
                    )
        .Init("DotCS Lil Skelly Protector",
                    new State(
                    new ScaleHP(3000, 0, true, 10, 1),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(2000, "attack")
                            ),
                        new State("attack",
                            new Follow(0.8, 15, 0),
                            new Shoot(15, count: 5, shootAngle: 6, projectileIndex: 0, predictive: 0.3, coolDown: 2000)
                            )
                        )
                    )
        .Init("DotCS Tokugawa Fallen General",
                    new State(
                    new HPScale(30),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new TimedTransition(4000, "Ready")
                            ),
                        new State("Ready",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("MEN KILL HIM!"),
                            new TimedTransition(6000, "Start")
                            ),
                        new State("Start",
                            new Taunt("DESTROY HIM!"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Follow(0.8, 13, 0),
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new EntityNotExistsTransition("DotCS Lil Skelly Spearmen", 100, "Attack"),
                            new TimedTransition(6000, "Rush")
                            ),
                        new State("Rush",
                            new Taunt("HAHA DIE!"),
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Follow(1.0, 13, 0),
                            new Flash(0xe60b0b, 0.2, 10),
                            new Shoot(15, count: 1, projectileIndex: 1, predictive: 0.3, coolDown: 100),
                            new EntityNotExistsTransition("DotCS Lil Skelly Spearmen", 100, "Attack"),
                            new TimedTransition(2000, "Start")
                            ),
                        new State("Attack",
                            new Taunt("MY ARMY YOU KILLED THEM!"),
                            new Follow(1.0, 13, 0),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new RingAttack(20, 8, 0, projectileIndex: 2, 45, 45, coolDown: 2500, seeInvis: true),
                            new HpLessTransition(0.70, "Return")
                            ),
                        new State("Return",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("TIME TO DISAPPEAR!"),
                            new TimedTransition(4000, "Anger")
                            ),
                        new State("Anger",
                            new Taunt("BE GONE!"),
                            new Follow(1.25, 13, 0),
                            new Shoot(15, count: 1, projectileIndex: 1, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 4, shootAngle: 9, projectileIndex: 1, predictive: 0.3, coolDown: 750),
                            new HpLessTransition(0.50, "Weak")
                            ),
                        new State("Weak",
                            new Taunt("How.. Dare.. You.. Kill.. Them"),
                            new Follow(1.0, 13, 0),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 5, shootAngle: 15, projectileIndex: 1, coolDown: 1000),
                            new RingAttack(20, 8, 0, projectileIndex: 2, 45, 45, coolDown: 2500, seeInvis: true),
                            new HpLessTransition(0.25, "Final")
                            ),
                        new State("Final",
                            new Taunt("I WON'T LET THEIR DEATHS BE IN VANE!"),
                            new Flash(0xe60b0b, 0.1, 999999),
                            new Follow(1.5, 13, 0),
                            new Shoot(15, count: 3, projectileIndex: 0, predictive: 0.3, coolDown: 500),
                            new Shoot(15, count: 4, shootAngle: 9, projectileIndex: 1, predictive: 0.3, coolDown: 750),
                            new RingAttack(20, 12, 0, projectileIndex: 2, 45, 45, coolDown: 2000, seeInvis: true)
                            )
                        )
                    )
        .Init("DotCS Wood Gate",
                new State(
                    new State("Open Gate",
                        new RemoveObjectOnDeath("DotCS Elemental Aura Barrier Wood", 300)
                        )
                    )
                )
        .Init("DotCS Metal Gate",
                new State(
                    new State("Open Gate",
                        new RemoveObjectOnDeath("DotCS Elemental Aura Barrier Metal", 300)
                        )
                    )
                )
        .Init("DotCS Water Gate",
                new State(
                    new State("Open Gate",
                        new RemoveObjectOnDeath("DotCS Elemental Aura Barrier Water", 300)
                        )
                    )
                )
        .Init("DotCS Fire Gate",
                new State(
                    new State("Open Gate",
                        new RemoveObjectOnDeath("DotCS Elemental Aura Barrier Fire", 300)
                        )
                    )
                )
        .Init("DotCS Wind Gate",
                new State(
                    new State("Open Gate",
                        new RemoveObjectOnDeath("DotCS Elemental Aura Barrier Wind", 300)
                        )
                    )
                )
         .Init("DotCS Invis Barrier",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(10000, "Check One")
                        ),
                    new State("Check One",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityNotExistsTransition("DotCS Bone Pile Static", 100, "Check Two")
                        ),
                    new State("Check Two",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityNotExistsTransition("DotCS Bone Pile", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(5000, "Suicide")
                        ),
                    new State("Suicide",
                        new Transform("DotCS Elemental Aura Barrier")
                        )
                    )
                )
        .Init("DotCS Invis Barrier Mid",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(10000, "Check One")
                        ),
                    new State("Check One",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityNotExistsTransition("DotCS Bone Pile Static", 100, "Check Two")
                        ),
                    new State("Check Two",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityNotExistsTransition("DotCS Bone Pile", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(7000, "Suicide")
                        ),
                    new State("Suicide",
                        new Transform("DotCS Elemental Aura Barrier")
                        )
                    )
                )
        .Init("DotCS Warning Skeleton",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(10000, "Check One")
                        ),
                    new State("Check One",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityNotExistsTransition("DotCS Bone Pile Static", 100, "Check Two")
                        ),
                    new State("Check Two",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Watch... Out.."),
                        new EntityNotExistsTransition("DotCS Bone Pile", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("Walls Closing in..."),
                        new TimedTransition(5500, "Scream")
                        ),
                    new State("Scream",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Taunt("ARHHHHH"),
                        new TimedTransition(1500, "Suicide")
                        ),
                    new State("Suicide",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Elemental Aura Barrier")
                        )
                    )
                )
        .Init("DotCS Izuchi Water Serpent",
                    new State(
                    new HPScale(30),
                        new State("Spawn",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("Hmm... Humans?"),
                            new TimedTransition(4000, "Start 1")
                            ),
                        new State("Start 1",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("Its been a while since humans have entered this place..."),
                            new TimedTransition(4000, "Start 2")
                            ),
                        new State("Start 2",
                            new Taunt("What do you want?"),
                            new HpLessTransition(0.95, "Start 3")
                            ),
                        new State("Start 3",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("Ah.. just to kill me, like all the rest"),
                            new TimedTransition(4000, "Ready")
                            ),
                        new State("Ready",
                            new Taunt("Well come at me i guess..."),
                            new Wander(0.25),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new RingAttack(20, 6, 0, projectileIndex: 3, 45, 45, coolDown: 2000, seeInvis: true),
                            new HpLessTransition(0.80, "Attack")
                            ),
                        new State("Attack",
                            new Taunt("I just want to go back to my sleep..."),
                            new Wander(0.15),
                            new Shoot(15, count: 2, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 4, shootAngle: 30, projectileIndex: 1, predictive: 0.3, coolDown: 2000),
                            new RingAttack(20, 6, 0, projectileIndex: 2, 45, 45, coolDown: 1000, seeInvis: true),
                            new HpLessTransition(0.50, "Sleep")
                            ),
                        new State("Sleep",
                            new Taunt("You humans always do this..."),
                            new Wander(0.10),
                            new Shoot(15, count: 3, shootAngle: 9, projectileIndex: 0, predictive: 0.3, coolDown: 1000),
                            new Shoot(15, count: 8, shootAngle: 30, projectileIndex: 1, predictive: 0.3, coolDown: 7000),
                            new RingAttack(20, 8, 0, projectileIndex: 2, 45, 45, coolDown: 5500, seeInvis: true),
                            new RingAttack(20, 16, 0, projectileIndex: 3, 45, 45, coolDown: 5500, seeInvis: true),
                            new HpLessTransition(0.25, "Weak")
                            ),
                        new State("Weak",
                            new Taunt("Can you leave already..."),
                            new Wander(0.15),
                            new Flash(0xe60b0b, 0.1, 200),
                            new Shoot(15, count: 4, shootAngle: 7, projectileIndex: 0, predictive: 0.3, coolDown: 750),
                            new Shoot(15, count: 8, shootAngle: 30, projectileIndex: 1, predictive: 0.3, coolDown: 7000),
                            new RingAttack(20, 8, 0, projectileIndex: 2, 45, 45, coolDown: 4500, seeInvis: true),
                            new RingAttack(20, 16, 0, projectileIndex: 3, 45, 45, coolDown: 4500, seeInvis: true),
                            new HpLessTransition(0.05, "Final")
                            ),
                        new State("Final",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("That's it.. i'll just leave myself i guess..."),
                            new Suicide()
                            )
                        ),
                new Threshold(0.001,
                    new ItemLoot("Support Fragment", 1.0),
                    new ItemLoot("Greater Potion of Defense", 0.1),
                    new ItemLoot("Greater Potion of Dexterity", 0.1),
                    new ItemLoot("Greater Potion of Attack", 0.2),
                    new ItemLoot("Greater Potion of Vitality", 0.1),
                    new ItemLoot("Greater Potion of Wisdom", 0.2),
                    new ItemLoot("Greater Potion of Speed", 0.2),
                    new ItemLoot("Greater Potion of Life", 0.05),
                    new ItemLoot("Greater Potion of Mana", 0.05)
                ),
                new Threshold(0.03,
                    new ItemLoot("Serpent Scale Longbow", 0.0066),
                    new ItemLoot("Spirit Serpent Orb", 0.0066)
                    )
            )
        .Init("DotCS Spear Skeleton Static",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityExistsTransition("DotCS Tokugawa Fallen General", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Spear Skeleton")
                        )
                    )
                )
        .Init("DotCS Spear Skeleton",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Lil Skelly Spearmen")
                        )
                    )
                )
        .Init("DotCS Rogue Skeleton Static",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityExistsTransition("DotCS Tokugawa Fallen General", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Rogue Skeleton")
                        )
                    )
                )
        .Init("DotCS Rogue Skeleton",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Lil Skelly Rogue")
                        )
                    )
                )
        .Init("DotCS Shield Skeleton Static",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new EntityExistsTransition("DotCS Tokugawa Fallen General", 100, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Shield Skeleton")
                        )
                    )
                )
        .Init("DotCS Shield Skeleton",
                new State(
                    new State("Wait",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(3000, "Transform")
                        ),
                    new State("Transform",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Transform("DotCS Lil Skelly Protector")
                        )
                    )
                )
        .Init("Dotcs Susano",
                    new State(
                    new HPScale(30),
                        new State("Activate",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new PlayerWithinTransition(8, "Awaken 1")
                            ),
                        new State("Awaken 1",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("..."),
                            new TimedTransition(3000, "Awaken 2")
                            ),
                        new State("Awaken 2",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("You got past that skeleton?"),
                            new TimedTransition(3500, "Awaken 3")
                            ),
                        new State("Awaken 3",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("...I never thought i would take up the blade again..."),
                            new TimedTransition(4000, "Awaken 4")
                            ),
                        new State("Awaken 4",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("I'm sorry... atleast you will die a death on the battle field..."),
                            new TimedTransition(3500, "Attack")
                            ),
                        new State("Attack",
                            new Shoot(15, count: 5, shootAngle: 8, projectileIndex: 0, predictive: 0.3, coolDown: 2000)
                            )
                      )
                )
        .Init("Dotcs Mizuchi Tower",
                new State(
                    new State("Attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 1, 0, projectileIndex: 0, 0.18, 0.18, coolDown: 180, seeInvis: true)
                        ),
                    new State("Attack2",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 2, 0, projectileIndex: 0, 0.18, 0.18, coolDown: 190, seeInvis: true)
                        )
                    )
                )
        .Init("Dotcs Mizuchi",
                    new State(
                    new HPScale(25),
                        new State("Activate",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new PlayerWithinTransition(6, "Awaken 1")
                            ),
                        new State("Awaken 1",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Taunt("..."),
                            new TimedTransition(3000, "Awaken 2")
                            ),
                        new State("Awaken 2",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Flash(0xff0000, 0.5, 6),
                            new Taunt("Grrrr.."),
                            new TimedTransition(3500, "Awaken 3")
                            ),
                        new State("Awaken 3",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new Flash(0xff0000, 0.1, 40),
                            new Taunt("ROOAAAR"),
                            new TimedTransition(4000, "Attack")
                            ),
                        new State("Attack",
                            new RingAttack(20, 6, 0, projectileIndex: 0, 0.24, 0.24, coolDown: 175, seeInvis: true),
                            new Shoot(15, count: 3, shootAngle: 5, projectileIndex: 2, predictive: 0.3, coolDown: 1300),
                            new HpLessTransition(0.80, "Attack2")
                            ),
                        new State("Attack2",
                            new RingAttack(20, 12, 0, projectileIndex: 2, 0.24, 0.24, coolDown: 1200, seeInvis: true),
                            new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, predictive: 0.3, coolDown: 500),
                            new HpLessTransition(0.60, "Attack3")
                            ),
                        new State("Attack3",
                            new Shoot(15, count: 3, shootAngle: 12, projectileIndex: 2, predictive: 0.3, coolDown: 800),
                            new Shoot(15, count: 5, shootAngle: 12, projectileIndex: 1, predictive: 0.3, coolDown: 800, coolDownOffset: 300),
                            new HpLessTransition(0.40, "Attack4")
                            ),
                        new State("Attack4",
                            new TossObject("Dotcs Mizuchi Tower", 7, angle: 0, coolDown: 500000, throwEffect: true),
                            new TossObject("Dotcs Mizuchi Tower", 7, angle: 90, coolDown: 500000, throwEffect: true),
                            new TossObject("Dotcs Mizuchi Tower", 7, angle: 180, coolDown: 500000, throwEffect: true),
                            new TossObject("Dotcs Mizuchi Tower", 7, angle: 270, coolDown: 500000, throwEffect: true),
                            new Shoot(15, count: 5, shootAngle: 12, projectileIndex: 2, predictive: 0.3, coolDown: 800),
                            new HpLessTransition(0.20, "Attack5")
                            ),
                        new State("Attack5",
                            new Order(30, "Dotcs Mizuchi Tower", "Attack2"),
                            new RingAttack(20, 12, 0, projectileIndex: 0, 0.54, 0.54, coolDown: 1200, seeInvis: true),
                            new Shoot(15, count: 4, shootAngle: 12, projectileIndex: 2, predictive: 0.3, coolDown: 800)
                            )
                      ),
                new Threshold(0.001,
                    new ItemLoot("Support Fragment", 1.0),
                    new ItemLoot("Greater Potion of Defense", 0.15),
                    new ItemLoot("Greater Potion of Dexterity", 0.15),
                    new ItemLoot("Greater Potion of Attack", 0.25),
                    new ItemLoot("Greater Potion of Vitality", 0.15),
                    new ItemLoot("Greater Potion of Wisdom", 0.25),
                    new ItemLoot("Greater Potion of Speed", 0.25),
                    new ItemLoot("Greater Potion of Life", 0.1),
                    new ItemLoot("Greater Potion of Mana", 0.1)
                ),
                new Threshold(0.03,
                    new ItemLoot("Draconic Blight", 0.0066),
                    new ItemLoot("Effulgent Yataghan", 0.0066)
                    )
            );

    }
}