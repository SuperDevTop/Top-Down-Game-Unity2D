﻿using common.resources;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ CubeGod = () => Behav()
            .Init("Cube God",
                new State(
                    new HPScale(30),
                    new Wander(.3),
                    new Shoot(30, 9, 10, 0, predictive: .5, coolDown: 750),
                    new Shoot(30, 4, 10, 1, predictive: .5, coolDown: 1500)
                  //  new Reproduce("Cube Overseer", 30, 10, coolDown: 1500)
                    ),
                 new Threshold(.005, 
                     LootTemplates.BasicDrop()
                     ),
                  new Threshold(.005,
                     LootTemplates.BasicPots()
                     ),
                  new Threshold(0.01,
                    new ItemLoot("Cloak of Slimy Elegance", 0.02),
                    new ItemLoot("Elastic Armor", 0.02),
                    new ItemLoot("Gelatinous Chunk", 0.02),
					new ItemLoot("Dirk of Cronus", 0.005)
                    )
				)
            .Init("Cube Overseer",
                new State(
                    new Prioritize(
                        new Orbit(.375, 10, 30, "Cube God", .075, 5),
                        new Wander(.375)
                        ),
                    new Reproduce("Cube Defender", 12, 10, coolDown: 1000),
                    new Reproduce("Cube Blaster", 30, 10, coolDown: 1000),
                    new Shoot(10, 4, 10, 0, coolDown: 750),
                    new Shoot(10, projectileIndex: 1, coolDown: 1500)
                    ),
                new Threshold(.01,
                    new ItemLoot("Fire Sword", .05)
                    )
            )
            .Init("Cube Defender",
                new State(
                    new Prioritize(
                        new Orbit(1.05, 5, 15, "Cube Overseer", .15, 3),
                        new Wander(1.05)
                        ),
                    new Shoot(10, coolDown: 500)
                    )
            )
            .Init("Cube Blaster",
                new State(
                    new State("Orbit",
                        new Prioritize(
                            new Orbit(1.05, 7.5, 40, "Cube Overseer", .15, 3),
                            new Wander(1.05)
                            ),
                        new EntityNotExistsTransition("Cube Overseer", 10, "Follow")
                        ),
                    new State("Follow",
                        new Prioritize(
                            new Follow(.75, 10, 1, 5000),
                            new Wander(1.05)
                            ),
                        new EntityNotExistsTransition("Cube Defender", 10, "Orbit"),
                        new TimedTransition(5000, "Orbit")
                        ),
                    new Shoot(10, 2, 10, 1, predictive: 1, coolDown: 500),
                    new Shoot(10, predictive: 1, coolDown: 1500)
                    )
            );
    }
}
