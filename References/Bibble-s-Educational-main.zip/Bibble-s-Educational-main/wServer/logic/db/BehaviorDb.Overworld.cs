﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using common.resources;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ Overworld = () => Behav()
            .Init("Lizard Monarch",
                new State(
                    new HPScale(30),
                    new State("Inactive",
                        new PlayerWithinTransition(12, "Initiate")
                        ),
                    new State("Initiate",
                        new Shoot(10, 4, 90, 3, 40, coolDown: 2000),
                        new Shoot(10, 4, 90, 3, 50, coolDown: 2000),
                        new Shoot(10, 4, 90, 3, 35, coolDown: 2000, coolDownOffset: 200),
                        new Shoot(10, 4, 90, 3, 45, coolDown: 2000, coolDownOffset: 200),
                        new Shoot(10, 4, 90, 3, 55, coolDown: 2000, coolDownOffset: 200),
                        new Shoot(10, 4, 90, 3, 35, coolDown: 2000, coolDownOffset: 400),
                        new Shoot(10, 4, 90, 3, 42, coolDown: 2000, coolDownOffset: 400),
                        new Shoot(10, 4, 90, 3, 49, coolDown: 2000, coolDownOffset: 400),
                        new Shoot(10, 4, 90, 3, 55, coolDown: 2000, coolDownOffset: 400),
                        new Shoot(10, 4, 90, 3, 35, coolDown: 2000, coolDownOffset: 600),
                        new Shoot(10, 4, 90, 3, 42, coolDown: 2000, coolDownOffset: 600),
                        new Shoot(10, 4, 90, 3, 49, coolDown: 2000, coolDownOffset: 600),
                        new Shoot(10, 4, 90, 3, 55, coolDown: 2000, coolDownOffset: 600),
                        new Shoot(10, 4, 90, 3, 35, coolDown: 2000, coolDownOffset: 800),
                        new Shoot(10, 4, 90, 3, 45, coolDown: 2000, coolDownOffset: 800),
                        new Shoot(10, 4, 90, 3, 55, coolDown: 2000, coolDownOffset: 800),
                        new Shoot(10, 4, 90, 3, 40, coolDown: 2000, coolDownOffset: 1000),
                        new Shoot(10, 4, 90, 3, 50, coolDown: 2000, coolDownOffset: 1000),
                        new Shoot(10, 9, 40, 0, coolDown: 2000),
                        new Shoot(10, 2, 12, 1, coolDown: 1000),
                        new Shoot(10, 3, 16, 1, coolDown: 1000, coolDownOffset: 200),
                        new HpLessTransition(0.5, "Provoked")
                        ),
                    new State("Provoked",
                        new Wander(0.2),
                        new Shoot(10, 4, 3, 2, coolDown: 200),
                        new Shoot(10, 5, 10, 1, coolDown: 1000),
                        new Shoot(10, 18, 20, 0, coolDown: 1500)
                        )
                    ),
                new Threshold(0.001,
                    new ItemLoot("Potion Tablet", 0.65),
                    new ItemLoot("Potion Tablet", 0.55),
                    new ItemLoot("Potion Tablet", 0.35)
                ),
                new Threshold(0.03,
                    new ItemLoot("Sahara's Stinger", 0.003)
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                )
             )
            .Init("Halfling Monarch",
                new State(
                    new HPScale(25),
                    new State("Inactive",
                        new PlayerWithinTransition(12, "Initiate")
                        ),
                    new State("Initiate",
                        new Shoot(10, 3, 120, 1, 6, coolDown: 2000, coolDownOffset: 100),
                        new Shoot(10, 3, 120, 1, 12, coolDown: 2000, coolDownOffset: 200),
                        new Shoot(10, 3, 120, 1, 18, coolDown: 2000, coolDownOffset: 300),
                        new Shoot(10, 3, 120, 1, 24, coolDown: 2000, coolDownOffset: 400),
                        new Shoot(10, 3, 120, 1, 36, coolDown: 2000, coolDownOffset: 600),
                        new Shoot(10, 3, 120, 1, 42, coolDown: 2000, coolDownOffset: 700),
                        new Shoot(10, 3, 120, 1, 48, coolDown: 2000, coolDownOffset: 800),
                        new Shoot(10, 3, 120, 1, 54, coolDown: 2000, coolDownOffset: 900),
                        new Shoot(10, 3, 120, 1, 66, coolDown: 2000, coolDownOffset: 1100),
                        new Shoot(10, 3, 120, 1, 72, coolDown: 2000, coolDownOffset: 1200),
                        new Shoot(10, 3, 120, 1, 78, coolDown: 2000, coolDownOffset: 1300),
                        new Shoot(10, 3, 120, 1, 84, coolDown: 2000, coolDownOffset: 1400),
                        new Shoot(10, 3, 120, 1, 96, coolDown: 2000, coolDownOffset: 1600),
                        new Shoot(10, 3, 120, 1, 102, coolDown: 2000, coolDownOffset: 1700),
                        new Shoot(10, 3, 120, 1, 108, coolDown: 2000, coolDownOffset: 1800),
                        new Shoot(10, 3, 120, 1, 114, coolDown: 2000, coolDownOffset: 1900),
                        new HpLessTransition(0.66, "Moving")
                        ),
                    new State("Moving",
                        new Follow(0.3, 10, 2.5, 0, 0),
                        new Shoot(10, 2, 180, 1, 0, coolDown: 1600),
                        new Shoot(10, 2, 180, 1, 20, coolDown: 1600, coolDownOffset: 200),
                        new Shoot(10, 2, 180, 1, 40, coolDown: 1600, coolDownOffset: 400),
                        new Shoot(10, 2, 180, 1, 60, coolDown: 1600, coolDownOffset: 600),
                        new Shoot(10, 2, 180, 1, 80, coolDown: 1600, coolDownOffset: 800),
                        new Shoot(10, 2, 180, 1, 100, coolDown: 1600, coolDownOffset: 1000),
                        new Shoot(10, 2, 180, 1, 120, coolDown: 1600, coolDownOffset: 1200),
                        new Shoot(10, 2, 180, 1, 140, coolDown: 1600, coolDownOffset: 1400),
                        new Shoot(10, 3, 10, 2, coolDown: 1000),
                        new Shoot(10, 1, 0, 0, coolDown: 1000)
                        )
                    ),
                new Threshold(0.001,
                    new ItemLoot("Potion Tablet", 0.55),
                    new ItemLoot("Potion Tablet", 0.45),
                    new ItemLoot("Potion Tablet", 0.25)
                ),
                new Threshold(0.03,
                    new ItemLoot("Crystalline Fury", 0.005)
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                )
            )
            .Init("Crab Monarch",
                new State(
                    new HPScale(25),
                    new State("Inactive",
                        new PlayerWithinTransition(12, "Initiate")
                        ),
                    new State("Initiate",
                        new Follow(0.2, 10, 2.5, 0, 0),
                        new Shoot(10, 18, 20, 1, coolDown: 2000),
                        new Shoot(10, 2, 10, 0, coolDown: 1500),
                        new Shoot(10, 2, 10, 0, coolDown: 1500, coolDownOffset: 200),
                        new Shoot(10, 2, 10, 0, coolDown: 1500, coolDownOffset: 400),
                        new HpLessTransition(0.5, "Provoked")
                        ),
                    new State("Provoked",
                        new Follow(0.5, 10, 2.5, 0, 0),
                        new Shoot(10, 20, 18, 1, coolDown: 2000),
                        new Shoot(10, 3, 15, 1, coolDown: 1500),
                        new Shoot(10, 2, 10, 0, coolDown: 1500),
                        new Shoot(10, 2, 10, 0, coolDown: 1500, coolDownOffset: 200),
                        new Shoot(10, 2, 10, 0, coolDown: 1500, coolDownOffset: 400),
                        new Shoot(10, 4, 8, 0, coolDown: 1500, coolDownOffset: 600)
                        )
                    ),
                new Threshold(0.001,
                    new ItemLoot("Potion Tablet", 0.55),
                    new ItemLoot("Potion Tablet", 0.45),
                    new ItemLoot("Potion Tablet", 0.25)
                ),
                new Threshold(0.03,
                    new ItemLoot("Big Meaty Claw", 0.005)
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                )
             )
        .Init("Orc Monarch",
                new State(
                    new HPScale(25),
                    new State("Inactive",
                        new PlayerWithinTransition(12, "Initiate")
                        ),
                    new State("Initiate",
                        new Follow(0.2, 10, 2.5, 0, 0),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, angleOffset: -30),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 100, angleOffset: -15),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 200, angleOffset: 0),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 300, angleOffset: 15),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 400, angleOffset: 30),
                        new Shoot(10, 8, 45, 1, 22, coolDown: 1500),
                        new Shoot(10, 8, 45, 1, 22, coolDown: 1500, coolDownOffset: 300),
                        new Shoot(10, 8, 45, 1, 22, coolDown: 1500, coolDownOffset: 600),
                        new HpLessTransition(0.5, "Provoked")
                        ),
                    new State("Provoked",
                        new ReturnToSpawn(0.8),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, angleOffset: -42),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 100, angleOffset: -28),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 200, angleOffset: -14),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 300, angleOffset: 0),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 400, angleOffset: 14),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 500, angleOffset: 28),
                        new Shoot(10, 1, 0, 0, coolDown: 1200, coolDownOffset: 600, angleOffset: 42),
                        new Shoot(10, 4, 90, 2, coolDown: 1600, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 6, explodeAngle: 60)
                        )
                    ),
                new Threshold(0.001,
                    new ItemLoot("Potion Tablet", 0.55),
                    new ItemLoot("Potion Tablet", 0.45),
                    new ItemLoot("Potion Tablet", 0.25)
                ),
                new Threshold(0.03,
                    new ItemLoot("Helm of the Mercenary", 0.005)
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                )
             )
        .Init("Cola Can",
                new State(
                    new SetNoXp(),
                    new State("active",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Flash(0xFF0000, 0.2, 3),
                        new TimedTransition(1500, "boom")
                        ),
                    new State("boom",
                        new Shoot(1, fixedAngle: 0, count: 8, shootAngle: 45, coolDown: 1000, projectileIndex: 0),
                        new Suicide()
                        )
                    )
            )
        .Init("Ghost Pirate Swashbuckler",
                new State(
                    new Prioritize(
                        new Follow(0.75),
                        new Wander(0.25)
                        ),
                    new Shoot(15, count: 3, shootAngle: 7, projectileIndex: 0, coolDown: 980)
                    ),
                new TierLoot(2, ItemType.Weapon, 0.09),
                new TierLoot(3, ItemType.Armor, 0.09),
                new TierLoot(1, ItemType.Ring, 0.07),
                new TierLoot(1, ItemType.Ability, 0.07),
                new ItemLoot("Health Potion", 0.1)
            )
        .Init("Ghost Pirate Gunslinger",
                new State(
                    new Prioritize(
                        new Wander(0.15),
                        new StayCloseToSpawn(0.2, 3)
                        ),
                    new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 0, coolDown: 400)
                    ),
                new TierLoot(2, ItemType.Weapon, 0.09),
                new TierLoot(3, ItemType.Armor, 0.09),
                new TierLoot(1, ItemType.Ring, 0.05),
                new TierLoot(1, ItemType.Ability, 0.05),
                new ItemLoot("Health Potion", 0.15)
            )
        .Init("Elder Ent Ancient",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(12, "attack")
                        ),
                    new State("attack",
                        new Swirl(0.6, 7, targeted: false),
                        new RingAttack(30, 4, 0, projectileIndex: 0, 0.3, 0.3, coolDown: 75),
                        new Shoot(15, count: 3, shootAngle: 15, coolDown: 3000, projectileIndex: 1),
                        new Shoot(15, count: 1, coolDown: 4000, projectileIndex: 2),
                        new HpLessTransition(0.66, "Return")
                        ),
                    new State("Return",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new ReturnToSpawn(speed: 1.00),
                        new TimedTransition(4000, "attack2")
                        ),
                    new State("attack2",
                        new Shoot(15, count: 3, shootAngle: 12, coolDown: 250, projectileIndex: 0),
                        new RingAttack(30, 8, 0, projectileIndex: 1, 0.3, 0.3, coolDown: 1500),
                        new Shoot(15, count: 1, coolDown: 3000, projectileIndex: 2, hasExplodingShots: true, explodeShotIndex: 3, explodeCount: 8, explodeAngle: 45),
                        new HpLessTransition(0.33, "attack3")
                        ),
                    new State("attack3",
                        new Shoot(15, count: 8, shootAngle: 45, projectileIndex: 2, coolDown: 8000, hasExplodingShots: true, explodeShotIndex: 0, explodeCount: 8, explodeAngle: 45),
                        new Grenade(2, 100, range: 10, effect: ConditionEffectIndex.Slowed, effectDuration: 1000, color: 0x773a1f, coolDown: 4000),
                        new RingAttack(30, 2, 0, projectileIndex: 1, 0.30, 0.30, coolDown: 100)
                        )
                    ),
                new Threshold(0.001,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.001,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.0001,
                    new ItemLoot("Potion Tablet", 0.05),
                    new ItemLoot("Trunk of The Ent Ancient", 0.02),
                    new ItemLoot("Elderwood Buckler", 0.02),
                    new ItemLoot("Branch of the Evergreen", 0.005),
                    new ItemLoot("Shard of Evolution", 0.013)
                )
            )
        .Init("Monarch of the Shoreline",
                new State(
                    new HPScale(15),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(9, "attack")
                        ),
                    new State("attack",
                        new Wander(0.3),
                        new StayCloseToSpawn(0.4, 4),
                        new RingAttack(30, 8, 0, projectileIndex: 1, 0.25, 0.25, coolDown: 1500),
                        new Shoot(15, count: 2, shootAngle: 17, coolDown: 500, projectileIndex: 0),
                        new HpLessTransition(0.7, "attack2")
                        ),
                    new State("attack2",
                        new Follow(0.3, 12, 0),
                        new Shoot(6, count: 1, coolDown: 100, projectileIndex: 2),
                        new RingAttack(30, 2, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 200),
                        new HpLessTransition(0.4, "attack3")
                        ),
                    new State("attack3",
                        new Follow(1.4, 12, 0),
                        new Shoot(6, count: 3, shootAngle: 6, coolDown: 100, projectileIndex: 2),
                        new RingAttack(30, 2, 0, projectileIndex: 1, 0.55, 0.55, coolDown: 500)
                        )
                    ),
                new Threshold(0.0001,
                    new ItemLoot("Potion Tablet", 0.35),
                    new ItemLoot("Potion Tablet", 0.25),
                    new ItemLoot("Potion Tablet", 0.15)
                ),
                new Threshold(0.03,
                    new ItemLoot("Sahara's Stinger", 0.005)
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                )
            )
        .Init("Nuka",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new PlayerWithinTransition(12, "attack")
                        ),
                    new State("attack",
                        new Swirl(0.6, 7, targeted: false),
                        new RingAttack(30, 12, 0, projectileIndex: 0, 10, 10, coolDown: 2000),
                        new Shoot(15, predictive: 1, count: 1, coolDown: 4000, projectileIndex: 1),
                        new TossObject("Cola Can", 5, angle: 0, coolDown: 8000, throwEffect: true),
                        new TossObject("Cola Can", 5, angle: 120, coolDown: 8000, throwEffect: true),
                        new TossObject("Cola Can", 5, angle: 240, coolDown: 8000, throwEffect: true),
                        new HpLessTransition(0.6, "Return")
                        ),
                    new State("Return",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new ReturnToSpawn(speed: 1.00),
                        new TimedTransition(4000, "attack2")
                        ),
                    new State("attack2",
                        new Wander(0.2),
                        new RingAttack(30, 12, 0, projectileIndex: 0, 10, 10, coolDown: 2100),
                        new RingAttack(30, 12, 0, projectileIndex: 2, 10, 10, coolDown: 2000),
                        new Shoot(15, predictive: 1, count: 1, coolDown: 3000, projectileIndex: 1),
                        new TossObject("Cola Can", 5, angle: 0, coolDown: 6000, throwEffect: true),
                        new TossObject("Cola Can", 5, angle: 90, coolDown: 6000, throwEffect: true),
                        new TossObject("Cola Can", 5, angle: 180, coolDown: 6000, throwEffect: true),
                        new TossObject("Cola Can", 5, angle: 270, coolDown: 6000, throwEffect: true),
                        new HpLessTransition(0.1, "flash")
                        ),
                    new State("flash",
                        new Flash(0xFF0000, 0.2, 3),
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new TimedTransition(2000, "death")
                        ),
                    new State("death",
                         new Shoot(1, fixedAngle: 0, count: 8, shootAngle: 45, coolDown: 1000, projectileIndex: 0),
                         new Suicide()
                        )
                    ),
                new Threshold(0.001,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.001,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Cola Armor", 0.02),
                    new ItemLoot("Bottle Opener", 0.02),
                    new ItemLoot("Nuka Cola Can", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Nuka-Cannon", 0.005)
                )
            )
        .Init("Nuka Vending Machine",
                new State(
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new PlayerWithinTransition(20, "attack")
                        ),
                    new State("attack",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new RingAttack(20, 2, 0, projectileIndex: 1, 0.50, 0.50, coolDown: 500, seeInvis: true),
                        new Shoot(10, predictive: 1, count: 1, coolDown: 3000, projectileIndex: 0),
                        new EntityNotExistsTransition("Nuka", 50, "Suicide")
                        ),
                    new State("Suicide",
                        new Suicide()
                        )
                    )
                )

        // Alpha Deathclaw

        .Init("Deathclaw",
                new State(
                    new HPScale(30),
                    new State("idle",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new PlayerWithinTransition(12, "attack")
                        ),
                    new State("attack",
                        new Wander(0.2),
                        new Shoot(15, count: 5, shootAngle: 13, projectileIndex: 2, predictive: 0.3, coolDown: 2000),
                        new Shoot(15, count: 1, projectileIndex: 1, predictive: 0.3, coolDown: 4000),
                        new RingAttack(30, 16, 0, projectileIndex: 3, 10, 10, coolDown: 6000),
                        new Grenade(2, 125, range: 10, effect: ConditionEffectIndex.Slowed, effectDuration: 1250, color: 0xff0000, coolDown: 4000),
                        new HpLessTransition(0.75, "Return 1")
                        ),
                    new State("Return 1",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.30),
                        new TimedTransition(4000, "TentacleL")
                        ),
                    new State("TentacleL",
                        new RingAttack(20, 6, 0, projectileIndex: 0, 0.25, 0.25, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 5, 0, projectileIndex: 0, 0.50, 0.50, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 4, 0, projectileIndex: 0, 0.75, 0.75, coolDown: 750, seeInvis: true),
                        new Grenade(2, 125, fixedAngle: 0, range: 5, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 90, range: 6, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 180, range: 7, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 270, range: 8, coolDown: 2000),
                        new HpLessTransition(0.30, "ring2"),
                        new TimedTransition(6000, "TentacleR")
                        ),
                    new State("TentacleR",
                        new Flash(0xe60b0b, 0.2, 60),
                        new RingAttack(20, 8, 0, projectileIndex: 0, -0.25, -0.25, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 7, 0, projectileIndex: 0, -0.50, -0.50, coolDown: 750, seeInvis: true),
                        new RingAttack(20, 6, 0, projectileIndex: 0, -0.75, -0.75, coolDown: 750, seeInvis: true),
                        new Grenade(2, 125, fixedAngle: 0, range: 5, coolDown: 1000),
                        new Grenade(2, 125, fixedAngle: 90, range: 6, coolDown: 1000),
                        new Grenade(2, 125, fixedAngle: 180, range: 7, coolDown: 1000),
                        new Grenade(2, 125, fixedAngle: 270, range: 8, coolDown: 1000),
                        new HpLessTransition(0.30, "ring2"),
                        new TimedTransition(6000, "TentacleL")
                        ),
                    new State("ring2",
                        new Follow(0.7, 12, 0),
                        new Shoot(15, count: 6, shootAngle: 13, projectileIndex: 2, predictive: 0.3, coolDown: 2000),
                        new Shoot(15, count: 1, projectileIndex: 1, predictive: 0.3, coolDown: 2000),
                        new RingAttack(30, 24, 0, projectileIndex: 3, 10, 10, coolDown: 4000),
                        new Grenade(2, 125, fixedAngle: 0, range: 5, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 90, range: 6, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 180, range: 7, coolDown: 2000),
                        new Grenade(2, 125, fixedAngle: 270, range: 8, coolDown: 2000)
                        ),
                    new Prioritize(
                        new StayAbove(0.4, 9),
                        new Wander(0.15)
                        )
                    ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Radioactive Hide", 0.02),
                    new ItemLoot("Skull Torque", 0.02),
                    new ItemLoot("Pallid Sheathing", 0.02),
                    new ItemLoot("Irradiated Novel", 0.02),
                    new ItemLoot("Ashen Estoc", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Ghastly Shuriken", 0.005)
                )
            )
          .Init("Ice Obelisk",
            new State(
                new HPScale(30),
                new State("idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(10, "attack")
                ),
                new State("attack",
                    new Grenade(3, 130, range: 8, color: 0x07cde1, coolDown: 2000),
                    new RingAttack(20, 8, 0, projectileIndex: 1, 90, 90, coolDown: 4000),
                    new HpLessTransition(0.8, "attack2")
                    ),
                new State("attack2",
                    new Order(30, "Goblin In Ice", "transform"),
                    new RingAttack(20, 2, 0, projectileIndex: 0, 0.15, 0.15, coolDown: 200, seeInvis: true),
                    new RingAttack(20, 8, 0, projectileIndex: 1, 90, 90, coolDown: 3500),
                    new HpLessTransition(0.6, "attack3")
                    ),
                new State("attack3",
                    new Order(30, "Goblin Ice Block", "transform"),
                    new Grenade(3, 130, range: 8, color: 0x07cde1, coolDown: 2000),
                    new RingAttack(20, 2, 0, projectileIndex: 0, 0.15, 0.15, coolDown: 150, seeInvis: true),
                    new RingAttack(20, 8, 0, projectileIndex: 1, 90, 90, coolDown: 3000),
                    new HpLessTransition(0.3, "attack4")
                    ),
                new State("attack4",
                    new Order(30, "Ice Block Goblin", "transform"),
                    new RingAttack(20, 2, 0, projectileIndex: 0, 0.15, 0.15, coolDown: 100, seeInvis: true),
                    new Shoot(15, count: 1, projectileIndex: 2, predictive: 0.3, coolDown: 1000),
                    new RingAttack(20, 8, 0, projectileIndex: 1, 90, 90, coolDown: 2000)
                    )
                ),
            new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Sword of the Obelisk", 0.02),
                    new ItemLoot("Freezing Ice Armor", 0.02),
                    new ItemLoot("Frozen Necklace", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Ice Obelisk Shield", 0.005),
                    new ItemLoot("Cloak of Frozen Towers", 0.005)
                )
            )
            .Init("Ice Goblin",
                    new State(
                    new ScaleHP(1800, 0, true, 10, 1),
                        new Prioritize(
                            new Wander(0.3)
                                ),
                        new State("attack",
                            new RingAttack(45, 8, 0, projectileIndex: 0, 2, 2, coolDown: 4000),
                            new Shoot(15, count: 1, projectileIndex: 1, predictive: 0.3, coolDown: 2000)
                            )
                        )
                    )
         .Init("Goblin In Ice",
                    new State(
                        new State("wait",
                            new ConditionalEffect(ConditionEffectIndex.Invincible)
                            ),
                        new State("transform",
                            new Transform("Ice Goblin")
                            )
                        )
                    )
        .Init("Goblin Ice Block",
                    new State(
                        new State("wait",
                            new ConditionalEffect(ConditionEffectIndex.Invincible)
                            ),
                        new State("transform",
                            new Transform("Ice Goblin")
                            )
                        )
                    )
        .Init("Ice Block Goblin",
                    new State(
                        new State("wait",
                            new ConditionalEffect(ConditionEffectIndex.Invincible)
                            ),
                        new State("transform",
                            new Transform("Ice Goblin")
                            )
                        )
                    )
          .Init("Failed Experiment",
            new State(
                new HPScale(30),
                new State("idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(10, "arena1")
                ),
                new State("arena1",
                    new MoveTo2(0, -8, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena2")
                    ),
                new State("arena2",
                    new MoveTo2(8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena3")
                    ),
                new State("arena3",
                    new MoveTo2(0, 8, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena4")
                    ),
                new State("arena4",
                    new MoveTo2(-8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "rotationL")
                    ),
                new State("rotationL",
                    new RingAttack(180, 2, 0, projectileIndex: 2, 0.24, 0.24, coolDown: 100, seeInvis: true),
                    new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1400),
                    new TimedTransition(2400, "rotationR")
                    ),
                new State("rotationR",
                    new RingAttack(180, 2, 0, projectileIndex: 3, -0.24, -0.24, coolDown: 100, seeInvis: true),
                    new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1400),
                    new TimedTransition(2400, "arena5")
                    ),
                new State("arena5",
                    new MoveTo2(-8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena6")
                    ),
                new State("arena6",
                    new MoveTo2(0, 8, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena7")
                    ),
                new State("arena7",
                    new MoveTo2(8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena8")
                    ),
                new State("arena8",
                    new MoveTo2(8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena9")
                    ),
                new State("arena9",
                    new MoveTo2(0, -8, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 2, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "arena10")
                    ),
                new State("arena10",
                    new MoveTo2(-8, 0, 0.7),
                    new RingAttack(45, 8, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 2000, seeInvis: true),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new Shoot(15, count: 1, coolDown: 500, projectileIndex: 0),
                    new TimedTransition(2400, "rotationL2")
                    ),
                new State("rotationL2",
                    new RingAttack(180, 2, 0, projectileIndex: 2, 0.24, 0.24, coolDown: 100, seeInvis: true),
                    new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1400),
                    new TimedTransition(2400, "rotationR2")
                    ),
                new State("rotationR2",
                    new RingAttack(180, 2, 0, projectileIndex: 3, -0.24, -0.24, coolDown: 100, seeInvis: true),
                    new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1400),
                    new TimedTransition(2400, "turretsToss")
                    ),
                new State("turretsToss",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TossObject("Experiment Eye Turret", 9, angle: 45, coolDown: 500000, throwEffect:true),
                    new TossObject("Experiment Eye Turret", 9, angle: 135, coolDown: 500000, throwEffect: true),
                    new TossObject("Experiment Eye Turret", 9, angle: 225, coolDown: 500000, throwEffect: true),
                    new TossObject("Experiment Eye Turret", 9, angle: 315, coolDown: 500000, throwEffect: true),
                    new TimedTransition(2000, "turretsWait")
                    ),
                new State("turretsWait",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, predictive: 0.3, coolDown: 1400),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true),
                    new EntityNotExistsTransition("Experiment Eye Turret", 100, "Final1")
                    ),
                new State("Final1",
                    new Shoot(15, count: 1, projectileIndex: 4, coolDown: 2000),
                    new RingAttack(90, 16, 0, projectileIndex: 3, 0.2, 0.2, coolDown: 1000, seeInvis: true)
                    )
                ),
            new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Experimental Robe", 0.02),
                    new ItemLoot("The Experimental Ring", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Experimental Orb", 0.005),
                    new ItemLoot("Experimental Staff", 0.005)
                )
            )
          .Init("Experiment Eye Turret",
                    new State(
                    new ScaleHP(5000, 0, true, 10, 1),
                        new State("attack",
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 500)
                            )
                        )
                    )
          .Init("Jerry",
            new State(
                new HPScale(30),
                new State("idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(10, "attack")
                    ),
                    new State("attack",
                        new Wander(0.1),
                        new StayCloseToSpawn(0.1, 3),
                        new ReproduceChildren(6, 0, 8000, "Small Egg"),
                        new Shoot(15, count: 2, shootAngle: 12, projectileIndex: 1, predictive: 0.3, coolDown: 1500),
                        new RingAttack(20, 16, 0, projectileIndex: 0, 35, 35, coolDown: 3000),
                        new RingAttack(20, 24, 0, projectileIndex: 2, 35, 35, coolDown: 3000),
                        new HpLessTransition(0.75, "return")
                    ),
                    new State("return",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.52),
                        new TimedTransition(3000, "spiral")
                    ),
                    new State("spiral",
                        new Swirl(0.5, 6, targeted: false),
                        new ReproduceChildren(6, 0, 7000, "Small Egg"),
                        new RingAttack(20, 2, 0, projectileIndex: 0, 0.5, 0.5, coolDown: 100, seeInvis: true),
                        new Shoot(15, count: 2, shootAngle: 12, projectileIndex: 1, predictive: 0.3, coolDown: 1500),
                        new HpLessTransition(0.50, "return2")
                    ),
                    new State("return2",
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 0.52),
                        new TimedTransition(3000, "attack2")
                    ),
                    new State("attack2",
                        new Wander(0.7),
                        new StayCloseToSpawn(0.3, 5),
                        new ReproduceChildren(6, 0, 9000, "Big Egg"),
                        new Shoot(15, count: 2, shootAngle: 12, projectileIndex: 1, predictive: 0.3, coolDown: 1000),
                        new RingAttack(20, 16, 0, projectileIndex: 0, 35, 35, coolDown: 2000),
                        new RingAttack(20, 24, 0, projectileIndex: 2, 35, 35, coolDown: 2000),
                        new HpLessTransition(0.15, "charge")
                    ),
                    new State("charge",
                        new ConditionalEffect(ConditionEffectIndex.Invincible),
                        new Follow(1.0, 10, 2, 5000),
                        new Flash(0xff, 2, 2),
                        new TimedTransition(2500, "suicide")
                    ),
                    new State("suicide",
                        new Shoot(10, 30, 12, 0, coolDown: 5000),
                        new Shoot(10, 30, 12, 1, coolDown: 5000),
                        new Shoot(10, 30, 12, 2, coolDown: 5000),
                        new Order(200, "Lil Duck", "die"),
                        new Suicide()
                    )
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Duck Armor", 0.02),
                    new ItemLoot("Duck Necklace", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Duck Dagger", 0.005),
                    new ItemLoot("Duck Prism", 0.005)
                )
            )
        .Init("Small Egg",
                    new State(
                    new ScaleHP(3000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "die"),
                            new TimedTransition(4000, "transform")
                            ),
                        new State("transform",
                            new Transform("Small Egg Cracked")
                            ),
                        new State("die",
                            new ReproduceChildren(1, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Small Egg Cracked",
                    new State(
                    new ScaleHP(3000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "die"),
                            new TimedTransition(4000, "transform")
                            ),
                        new State("transform",
                            new Transform("Small Egg Broken")
                            ),
                        new State("die",
                            new ReproduceChildren(2, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Small Egg Broken",
                    new State(
                    new ScaleHP(3000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "shoot before death"),
                            new TimedTransition(3000, "shoot before death")
                            ),
                        new State("shoot before death",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new RingAttack(20, 12, 0, projectileIndex: 0, 35, 35, coolDown: 900),
                            new TimedTransition(1000, "die")
                            ),
                        new State("die",
                            new ReproduceChildren(3, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Big Egg",
                    new State(
                    new ScaleHP(6000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "die"),
                            new TimedTransition(6000, "transform")
                            ),
                        new State("transform",
                            new Transform("Big Egg Cracked")
                            ),
                        new State("die",
                            new ReproduceChildren(4, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Big Egg Cracked",
                    new State(
                    new ScaleHP(6000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "die"),
                            new TimedTransition(6000, "transform")
                            ),
                        new State("transform",
                            new Transform("Big Egg Broken")
                            ),
                        new State("die",
                            new ReproduceChildren(5, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Big Egg Broken",
                    new State(
                    new ScaleHP(6000, 0, true, 10, 1),
                        new State("wait",
                            new HpLessTransition(0.25, "shoot before death"),
                            new TimedTransition(3000, "shoot before death")
                            ),
                        new State("shoot before death",
                            new ConditionalEffect(ConditionEffectIndex.Invincible),
                            new RingAttack(20, 24, 0, projectileIndex: 0, 35, 35, coolDown: 900),
                            new TimedTransition(1000, "die")
                            ),
                        new State("die",
                            new ReproduceChildren(6, 1, 1000, "Lil Duck"),
                            new Decay(0)
                            )
                        )
                    )
        .Init("Lil Duck",
                    new State(
                    new ScaleHP(1000, 0, true, 10, 1),
                        new Prioritize(
                            new Follow(0.6, 12, 1),
                            new Wander(0.3)
                                ),
                        new State("attack",
                            new Shoot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 2000)
                            ),
                        new State("die",
                            new Suicide()
                            )
                        )
                    )
        .Init("Exploding Projectile Test",
                    new State(
                    new ScaleHP(3000, 0, true, 10, 1),
                        new Prioritize(
                            new Follow(0.6, 12, 1)
                                )/*,
                        new State("attack",
                            new ExplodeShot(15, count: 1, projectileIndex: 0, predictive: 0.3, coolDown: 2000)
                            )*/
                        )
                    )
        .Init("Fire Entity",
            new State(
                new HPScale(30),
                new State("idle",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new PlayerWithinTransition(10, "attack")
                    ),
                    new State("attack",
                        new StayCloseToSpawn(0.1, 4),
                        new Wander(0.2),
                        new RingAttack(20, 1, 0, projectileIndex: 1, 0.3, 0.3, coolDown: 500, seeInvis: true),
                        new Shoot(15, count: 3, shootAngle: 13, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                        new RingAttack(20, 8, 0, projectileIndex: 1, 10, 10, coolDown: 4000),
                        new RingAttack(22, 12, 0, projectileIndex: 2, 10, 10, coolDown: 4100),
                        new HpLessTransition(0.7, "return")
                    ),
                    new State("return",
                        new ReturnToSpawn(speed: 1.00),
                        new RingAttack(22, 16, 0, projectileIndex: 0, 0.10, 0.10, coolDown: 2000),
                        new RingAttack(22, 12, 0, projectileIndex: 0, 0.07, 0.07, coolDown: 250),
                        new RingAttack(22, 14, 0, projectileIndex: 0, 0.05, 0.05, coolDown: 400),
                        new TimedTransition(4000, "attack2")
                    ),
                    new State("attack2",
                        new Swirl(0.4, 8, targeted: false),
                        new RingAttack(20, 2, 0, projectileIndex: 1, 0.2, 0.2, coolDown: 500, seeInvis: true),
                        new RingAttack(20, 10, 0, projectileIndex: 1, 10, 10, coolDown: 4000),
                        new RingAttack(22, 12, 0, projectileIndex: 2, 10, 10, coolDown: 4100),
                        new RingAttack(22, 14, 0, projectileIndex: 0, 10, 10, coolDown: 4200),
                        new HpLessTransition(0.5, "return2")
                    ),
                    new State("return2",
                        new ReturnToSpawn(speed: 1.00),
                        new RingAttack(22, 16, 0, projectileIndex: 0, 0.10, 0.10, coolDown: 100),
                        new RingAttack(22, 12, 0, projectileIndex: 0, 0.07, 0.07, coolDown: 200),
                        new RingAttack(22, 14, 0, projectileIndex: 0, 0.05, 0.05, coolDown: 350),
                        new TimedTransition(4000, "rage")
                    ),
                    new State("rage",
                        new StayCloseToSpawn(0.2, 5),
                        new Wander(0.3),
                        new RingAttack(20, 2, 0, projectileIndex: 1, 0.3, 0.3, coolDown: 500, seeInvis: true),
                        new Shoot(15, count: 2, shootAngle: 13, projectileIndex: 0, predictive: 0.3, coolDown: 2000),
                        new RingAttack(20, 12, 0, projectileIndex: 1, 10, 10, coolDown: 3000),
                        new RingAttack(22, 14, 0, projectileIndex: 2, 10, 10, coolDown: 3100),
                        new RingAttack(22, 16, 0, projectileIndex: 0, 10, 10, coolDown: 3200)
                    )
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Essence of Flame", 0.02),
                    new ItemLoot("Ruby Dowel", 0.02),
                    new ItemLoot("Mantle of Grimace", 0.02),
                    new ItemLoot("Onslaught Bracelet", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Tome of Destruction", 0.005)
                )
            )
        .Init("Water Tsunami",
            new State(
                new HPScale(25),
                new State("Tasunami",
                  new Follow(0.6, 10, 2),
                  new Shoot(20, 4, shootAngle: 10, projectileIndex: 2, coolDown: 1200),
                  new Shoot(20, 3, shootAngle: 5, projectileIndex: 1, coolDown: 1200),
                  new HpLessTransition(0.5, "Tsunami2")
                    ),
                new State("Tsunami2",
                    new Wander(0.1),
                    new Shoot(20, 4, shootAngle: 10, projectileIndex: 2, coolDown: 900),
                  new Shoot(20, 3, shootAngle: 5, projectileIndex: 1, coolDown: 900),
                    new Shoot(20, 1, fixedAngle: 0, projectileIndex: 0, coolDown: 400, rotateAngle: 10),
                  new Shoot(20, 1, fixedAngle: 180, projectileIndex: 0, coolDown: 400, rotateAngle: 10),
                  new HpLessTransition(0.25, "Rage")
                    ),
                new State("Rage",
                    new Wander(0.1),
                    new Shoot(20, 4, shootAngle: 10, projectileIndex: 2, coolDown: 850),
                  new Shoot(20, 3, shootAngle: 5, projectileIndex: 1, coolDown: 850),
                  new Shoot(20, 1, fixedAngle: 0, projectileIndex: 0, coolDown: 350, rotateAngle: 10),
                  new Shoot(20, 1, fixedAngle: 180, projectileIndex: 0, coolDown: 350, rotateAngle: 10),
                  new Shoot(20, 1, fixedAngle: 270, projectileIndex: 0, coolDown: 350, rotateAngle: 10),
                  new Shoot(20, 1, fixedAngle: 90, projectileIndex: 0, coolDown: 350, rotateAngle: 10)
                )
              )
            )
        .Init("Water Entity",
            new State(
                new HPScale(30),
                new State("Phase1",
                    new Shoot(20, 6, fixedAngle: 90, shootAngle: 10, projectileIndex: 0, coolDown: 1000),
                    new Shoot(20, 6, fixedAngle: 270, shootAngle: 10, projectileIndex: 0, coolDown: 1000),
                    new Shoot(20, 8, shootAngle: 45, projectileIndex: 1, coolDown: 2000),
                    new TimedTransition(2500, "Phase1.1"),
                    new HpLessTransition(0.75, "Phase2")
                    ),
                new State("Phase1.1",
                    new Shoot(20, 6, fixedAngle: 0, shootAngle: 10, projectileIndex: 0, coolDown: 1000),
                    new Shoot(20, 6, fixedAngle: 180, shootAngle: 10, projectileIndex: 0, coolDown: 1000),
                    new Shoot(20, 8, shootAngle: 45, projectileIndex: 1, coolDown: 2000),
                    new TimedTransition(2500, "Phase1"),
                    new HpLessTransition(0.75, "Phase2")
                    ),
                new State("Phase2",
                    new Wander(0.1),
                    new Shoot(20, 4, shootAngle: 10, projectileIndex: 0, coolDown: 800),
                    new Shoot(20, 8, fixedAngle: 45, projectileIndex: 1, coolDown: 1000),
                    new Shoot(20, 1, fixedAngle: 270, projectileIndex: 2, coolDown: 200, rotateAngle: 10),
                    new Shoot(20, 1, fixedAngle: 90, projectileIndex: 2, coolDown: 200, rotateAngle: 10),
                    new HpLessTransition(0.5, "PrePhase3")
                    ),
                new State("PrePhase3",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new TossObject("Water Tsunami", angle: 1, coolDown: 999999, minRange: 1, maxRange: 2, minAngle: 1, maxAngle: 359, throwEffect: true),
                    new TimedTransition(2000, "Phase3")
                    ),
                new State("Phase3",
                   new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                   new Shoot(20, 5, shootAngle: 10, projectileIndex: 0, coolDown: 2000),
                   new Orbit(1.5, 8, 20, "Water Tsunami"),
                   new EntityNotExistsTransition("Water Tsunami", dist: 999, targetState: "Phase4")
                    ),
                new State("Phase4",
                    new Follow(0.7, 10, 2),
                    new Shoot(20, 4, shootAngle: 10, projectileIndex: 0, coolDown: 800),
                    new Shoot(20, 8, fixedAngle: 45, projectileIndex: 1, coolDown: 1000),
                    new Shoot(20, 8, shootAngle: 45, projectileIndex: 2, coolDown: 1500),
                    new HpLessTransition(0.25, "PreRagePhase")
                    ),
                new State("PreRagePhase",
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new ReturnToSpawn(2),
                    new TimedTransition(5000, "RagePhase")
                    ),
                new State("RagePhase",
                    new Flash(0xe61212, 20, 100),
                    new Shoot(20, 2, fixedAngle: 0, shootAngle: 2, projectileIndex: 2, coolDown: 200, rotateAngle: 5),
                    new Shoot(20, 2, fixedAngle: 180, shootAngle: 2, projectileIndex: 2, coolDown: 200, rotateAngle: 5),
                    new Shoot(20, 2, fixedAngle: 270, shootAngle: 2, projectileIndex: 2, coolDown: 200, rotateAngle: 5),
                    new Shoot(20, 2, fixedAngle: 90, shootAngle: 2, projectileIndex: 2, coolDown: 200, rotateAngle: 5),
                    new Shoot(20, 4, shootAngle: 35, projectileIndex: 0, coolDown: 1000),
                    new Shoot(20, 8, fixedAngle: 45, projectileIndex: 1, coolDown: 900),
                    new Shoot(20, 8, shootAngle: 45, projectileIndex: 0, coolDown: 2000)

                    )
                ),
                new Threshold(0.005,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.005,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.00001,
                    new ItemLoot("Dampened Quiver", 0.02),
                    new ItemLoot("Rampant Rivers Armor", 0.02),
                    new ItemLoot("Aqua Band", 0.02)
                    ),
                new Threshold(0.03,
                    new ItemLoot("Tsunami", 0.005)
                )
            );
    }
}
