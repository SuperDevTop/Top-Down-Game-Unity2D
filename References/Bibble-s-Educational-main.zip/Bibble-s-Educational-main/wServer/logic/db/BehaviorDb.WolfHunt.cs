﻿using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;
using common.resources;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        private _ WolfHunt = () => Behav()
            .Init("Alpha Star Wolf",
                new State(
                    new HPScale(35),
                    new State("Activate",
                       new ConditionalEffect(ConditionEffectIndex.Invincible),
                       new PlayerWithinTransition(12, "Taunt")
                       ),
                    new State("Taunt",
                       new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                       new Taunt("How dare you challenge an apex predator you puny mortal!"),
                       new TimedTransition(3000, "attack")
                       ),
                    new State("attack",
                        new RingAttack(15, 10, 0, projectileIndex: 3, 0.05, 0, coolDown: 200),
                        new RingAttack(15, 2, 0, projectileIndex: 0, 0.45, 0, coolDown: 400),
                        new RingAttack(15, 24, 0, projectileIndex: 2, 20, 0, coolDown: 6500),
                        new HpLessTransition(0.80, "attack2")
                    ),
                    new State("attack2",
                        new Swirl(0.6, 7, targeted: false),
                        new TossObject("Battle Star Wolf", 5, angle: 0, coolDown: 900000, throwEffect: true),
                        new TossObject("Battle Star Wolf", 5, angle: 180, coolDown: 900000, throwEffect: true),
                        new RingAttack(15, 12, 0, projectileIndex: 3, 20, 0, coolDown: 1500),
                        new RingAttack(15, 8, 0, projectileIndex: 4, 20, 0, coolDown: 6000),
                        new HpLessTransition(0.55, "Return")
                    ),
                    new State("Return",
                        new Taunt("I'M GOING TO RIP YOU APART!"),
                        new Order(30, "Battle Star Wolf", "Harder"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 1.80),
                        new TimedTransition(4000, "attack3")
                    ),
                    new State("attack3",
                        new Charge(speed: 3, range: 20, coolDown: 2500),
                        new Shoot(15, count: 6, shootAngle: 60, projectileIndex: 5, coolDown: 8000, hasExplodingShots:true, explodeShotIndex: 2, explodeCount: 8, explodeAngle: 45),
                        new Shoot(15, count: 2, shootAngle: 7, projectileIndex: 1, coolDown: 2000),
                        new RingAttack(15, 12, 0, projectileIndex: 3, 20, 0, coolDown: 4000),
                        new HpLessTransition(0.25, "Return2")
                    ),
                    new State("Return2",
                        new Taunt("I REFUSE TO LET MY MASTERS SLEEP BE INTERRUPTED!"),
                        new Order(30, "Battle Star Wolf", "Final"),
                        new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                        new ReturnToSpawn(speed: 1.80),
                        new TimedTransition(4000, "attack4")
                    ),
                    new State("attack4",
                        new Shoot(15, count: 8, shootAngle: 60, projectileIndex: 5, coolDown: 8000, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 8, explodeAngle: 45),
                        new Shoot(15, count: 2, shootAngle: 7, projectileIndex: 2, coolDown: 1000),
                        new RingAttack(15, 18, 0, projectileIndex: 3, 20, 0, coolDown: 4000)
                    )
                ),
                new Threshold(0.001,
                    LootTemplates.BasicDrop()
                ),
                new Threshold(0.001,
                    LootTemplates.BasicPots()
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.25),
                    new ItemLoot("Support Fragment", 0.05),
                    new ItemLoot("Ethereal Clover Rune", 0.05)
                    ),
                new Threshold(0.02,
                    new ItemLoot("Star Splitter Broadsword", 0.01),
                    new ItemLoot("Star Dust Shiv", 0.01),
                    new ItemLoot("Crystal Horned Helm", 0.01),
                    new ItemLoot("Galactic Codex", 0.01),
                    new ItemLoot("Toxin of the Cosmos", 0.01)
                    )
            )
            .Init("Battle Star Wolf",
                new State(
                    new ConditionalEffect(ConditionEffectIndex.Invulnerable),
                    new State("Idle",
                        new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, coolDown: 5000),
                        new RingAttack(15, 16, 0, projectileIndex: 0, 20, 0, coolDown: 3000)
                    ),
                    new State("Harder",
                        new RingAttack(15, 1, 0, projectileIndex: 0, 0.5, 0, coolDown: 200)
                    ),
                    new State("Final",
                        new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 1, coolDown: 5000, hasExplodingShots: true, explodeShotIndex: 1, explodeCount: 6, explodeAngle: 60),
                        new EntityNotExistsTransition("Alpha Star Wolf", 100, "Decay")
                    ),
                    new State("Decay",
                        new Decay(0)
                        )
                )
            )
            .Init("Star Wolf",
                new State(
                    new State("Idle",
                        new StayCloseToSpawn(0.3),
                        new Wander(0.1),
                        new Shoot(15, count: 3, shootAngle: 8, projectileIndex: 0, coolDown: 2500),
                        new Shoot(15, count: 1, shootAngle: 0, projectileIndex: 1, coolDown: 5000)
                    )
                ),
                new Threshold(0.005,
                    new ItemLoot("Support Fragment", 0.1)
                    )
            );
    }
}
