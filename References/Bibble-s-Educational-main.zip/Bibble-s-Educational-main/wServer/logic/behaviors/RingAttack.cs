﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using common;
using wServer.realm;
using wServer.realm.entities;
using wServer.networking.packets.incoming;
using wServer.networking.packets.outgoing;
using common.resources;

namespace wServer.logic.behaviors
{
    class RingAttack : CycleBehavior
    {
        int _count;
        float? _radius;
        float? _offset;
        int _projectileIndex;
        float? _angleToIncrement;
        float? _fixedAngle;
        Cooldown _coolDown;
        bool _seeInvis;

        class RingAttackState
        {
            public float? angleToIncrement;
            public float? fixedAngle;
            public Cooldown coolDown;
        }
        
        public RingAttack(XElement e)
        {
            _count = e.ParseInt("@count", 1);
            _radius = e.ParseFloat("@radius", 5);
            _offset = e.ParseFloat("@offset");
            _projectileIndex = e.ParseInt("@projectileIndex");
            _angleToIncrement = e.ParseNFloat("@incrementAngle");
            _fixedAngle = (float?)(e.ParseNFloat("@fixedAngle") * Math.PI / 180);
            _coolDown = new Cooldown().Normalize(e.ParseInt("@coolDown", 1000));
            _seeInvis = e.ParseBool("@seeInvis");
        }

        public RingAttack(double radius, int count, double offset, int projectileIndex, double? angleToIncrement, double? fixedAngle = null, Cooldown coolDown = new Cooldown(), bool seeInvis = false)
        {
            _count = count;
            _radius = (float)radius;
            _offset = (float)offset;
            _projectileIndex = projectileIndex;
            _angleToIncrement = (float?)angleToIncrement;
            _fixedAngle = (float?)(fixedAngle * Math.PI / 180);
            _coolDown = coolDown.Zero();
            _seeInvis = seeInvis;
        }


        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            state = new RingAttackState
            {
                angleToIncrement = _angleToIncrement,
                fixedAngle = _fixedAngle,
                coolDown = _coolDown
            };
        }

        protected override void TickCore(Entity Host, RealmTime time, ref object state)
        {
            RingAttackState rastate = (RingAttackState)state;
            Status = CycleStatus.NotStarted;
            if (Host.HasConditionEffect(ConditionEffects.Stunned)) return;
            float dist = (float)_radius;
            var isQuest = Host.ObjectDesc.Quest;

            if (rastate.coolDown.CoolDown <= 0)
            {
                Entity entity = (float)_radius == 0 ? null : Host.GetNearestEntity((float)_radius, null, _seeInvis);

                var enemy = Host as Enemy;


                if (entity != null || _radius == 0)
                {
                    var chr = Host as Character;
                    if (chr.Owner == null) return;

                    var angleInc = (2 * Math.PI) / _count;
                    var desc = Host.ObjectDesc.Projectiles[_projectileIndex];

                    float? angle = null;

                    if (rastate.fixedAngle != null)
                    {
                        if (rastate.angleToIncrement != null)
                        {
                            rastate.fixedAngle += rastate.angleToIncrement;
                            //Console.WriteLine($"Cooldown: {cool} \n Angle Incremented!. \n Angle: {fixedAngle}");
                        }
                        angle = (float)rastate.fixedAngle;
                    }
                    else
                    {
                        angle = entity == null ? _offset : (float)Math.Atan2(entity.Y - chr.Y, entity.X - chr.X) + _offset;
                    }

                    var count = _count;
                    if (Host.HasConditionEffect(ConditionEffects.Dazed))
                        count = Math.Max(1, count / 2);

                    int dmg = Random.Next(desc.MinDamage, desc.MaxDamage);
                    var startAngle = angle * (count - 1) / 2;
                    byte prjId = 0;
                    Position prjPos = new Position() { X = 0, Y = 0 };
                    var prjs = new Projectile[count];
                    for (int i = 0; i < count; i++)
                    {
                        var prj = Host.CreateProjectile(
                            desc, Host.ObjectType, dmg, time.TotalElapsedMs,
                            prjPos, (float)(startAngle + angle * i), false);
                        Host.Owner.EnterWorld(prj);

                        if (i == 0)
                            prjId = prj.ProjectileId;

                        prjs[i] = prj;
                    }


                    var pkt = new EnemyShoot()
                    {
                        BulletId = prjId,
                        OwnerId = Host.Id,
                        StartingPos = prjPos,
                        Angle = (float)angle,
                        Damage = (short)dmg,
                        BulletType = (byte)(desc.BulletType),
                        AngleInc = (float)angleInc,
                        NumShots = (byte)count,
                    };
                    if (isQuest)
                        foreach (var plrs in Host.Owner.Players.Values)
                        {
                            plrs.Client.SendPacket(pkt);
                        }
                    else
                        foreach (var plr in Host.Owner.Players.Values.Where(p => p.DistSqr(Host) < Player.RadiusSqr))
                        {
                            plr.Client.SendPacket(pkt);
                        }
                }
                rastate.coolDown = _coolDown.Next(Random);
                Status = CycleStatus.Completed;
            }
            else
            {
                rastate.coolDown.CoolDown -= time.ElaspedMsDelta;
                Status = CycleStatus.InProgress;
            }

            state = rastate;
        }
    }
}