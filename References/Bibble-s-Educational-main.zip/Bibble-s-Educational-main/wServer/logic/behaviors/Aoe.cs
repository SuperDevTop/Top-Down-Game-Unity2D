﻿using System.Collections.Generic;
using System.Xml.Linq;
using common;
using common.resources;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    class Aoe : Behavior
    {
        //State storage: nothing

        private readonly float radius;
        private readonly bool players;
        private readonly int minDamage;
        private readonly int maxDamage;
        private readonly Cooldown coolDown;
        private readonly bool noDef;
        private readonly ConditionEffectIndex effect;
        private readonly int effectDuration;
        private readonly ARGB color;
        
        public Aoe(XElement e)
        {
            radius = e.ParseFloat("@radius");
            players = e.ParseBool("@players", true);
            minDamage = e.ParseInt("@minDamage");
            maxDamage = e.ParseInt("@maxDamage");
            coolDown = new Cooldown().Normalize(e.ParseInt("@coolDown", 1000));
            noDef = e.ParseBool("@noDef");
            effect = e.ParseConditionEffect("@effect");
            effectDuration = e.ParseInt("@effectDuration");
            color = new ARGB(e.ParseUInt("@color", true, 0xffff0000));
        }

        public Aoe(double radius, bool players, int minDamage, int maxDamage, Cooldown coolDown = new Cooldown(), 
            bool noDef = false, ConditionEffectIndex effect = 0, int effectDuration = 0, uint color = 0xffff0000)
        {
            this.radius = (float)radius;
            this.players = players;
            this.minDamage = minDamage;
            this.maxDamage = maxDamage;
            this.coolDown = coolDown.Normalize();
            this.noDef = noDef;
            this.effect = effect;
            this.effectDuration = effectDuration;
            this.color = new ARGB(color);
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            state = 0;
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
            var cool = (int)state;

            if (cool <= 0)
            {
                var pos = new Position
                {
                    X = host.X,
                    Y = host.Y
                };

                var damage = Random.Next(minDamage, maxDamage);
                var enemies = new List<Enemy>();

                if (!players)
                {
                    host.Owner.AOE(pos, radius, false, enemy =>
                    {
                        if (enemy is Enemy e)
                            enemies.Add(e);

                        host.Owner.BroadcastPacketNearby(new ShowEffect()
                        {
                            EffectType = EffectType.AreaBlast,
                            TargetObjectId = host.Id,
                            Pos1 = new Position { X = radius, Y = 0 },
                            Color = color
                        }, host);
                    });
                    
                    for (var i = 0; i < enemies.Count; i++)
                    {
                        var enemy = enemies[i];
                        enemy.ApplyConditionEffect(effect, effectDuration);
                        enemy.Damage(null, time, damage, noDef);
                    }
                }
                else
                {
                    host.Owner.AOE(pos, radius, true, _ =>
                    {
                        host.Owner.BroadcastPacketNearby(new networking.packets.outgoing.Aoe
                        {
                            Pos = pos,
                            Radius = radius,
                            Damage = (ushort)damage,
                            Duration = effectDuration,
                            Effect = effect,
                            OrigType = host.ObjectType,
                            ObjectName = host.ObjectDesc.DisplayId ?? host.ObjectDesc.ObjectId,
                        }, host);
                    });
                }

                cool = coolDown.Next(Random);
            }
            else
                cool -= time.ElaspedMsDelta;

            state = cool;
        }
    }
}