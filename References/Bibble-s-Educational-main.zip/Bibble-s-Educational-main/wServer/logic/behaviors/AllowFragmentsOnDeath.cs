﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using common.resources;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    class AllowFragmentsOnDeath : Behavior
    {
        public AllowFragmentsOnDeath(XElement e)
        {
        }
        
        public AllowFragmentsOnDeath()
        {
        }

        protected internal override void Resolve(State parent)
        {
            parent.Death += (sender, e) =>
            {
                foreach (var entity in e.Host.GetNearestEntities(20, null, true).OfType<Player>())
                {
                    if (entity.Owner == null)
                        return;

                    if (entity.Ascended != 0)
                    {
                        entity.SendError("Your character is already ascended!");
                        return;
                    }

                    entity.Ascended = 1;
                    entity.Stats.ReCalculateValues();
                    entity.SendInfo("Your character has been ascended!");
                }
            };
        }
        protected override void TickCore(Entity host, RealmTime time, ref object state)
        { }
    }
}
