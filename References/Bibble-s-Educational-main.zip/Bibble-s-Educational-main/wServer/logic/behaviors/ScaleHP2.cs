﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using common;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    internal class HPScale : Behavior
    {
        private readonly int _percentage;
        private readonly double _range;
        private readonly int _scaleAfter;

        class ScaleHPState
        {
            public IList<string> pNamesCounted;
            public int initialScaleAmount = 0;
            public int cooldown;
        }
        
        public HPScale(XElement e)
        {
            _percentage = e.ParseInt("@amount");
            _range = e.ParseFloat("@range", 25);
            _scaleAfter = e.ParseInt("@scaleAfter", 1);
        }

        public HPScale(int amount, int scaleStart = 0, double range = 25.0)
        {
            _percentage = amount;
            _range = range;
            _scaleAfter = scaleStart;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            state = new ScaleHPState
            {
                pNamesCounted = new List<string>(),
                initialScaleAmount = _scaleAfter,
                cooldown = 0
            };
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
            ScaleHPState scstate = (ScaleHPState)state;
            if (scstate.cooldown <= 0)
            {
                scstate.cooldown = 1000;
                if (!(host is Enemy)) return;
                Enemy enemy = host as Enemy;

                int plrCount = 0;
                foreach (var i in host.Owner.Players)
                {
                    if (scstate.pNamesCounted.Contains(i.Value.Name)) continue;
                    if (_range > 0)
                    {
                        if (host.Dist(i.Value) < _range)
                            scstate.pNamesCounted.Add(i.Value.Name);
                    }
                    else
                        scstate.pNamesCounted.Add(i.Value.Name);
                }
                plrCount = scstate.pNamesCounted.Count;

                if(plrCount > scstate.initialScaleAmount)
                {
                    foreach (var i in host.Owner.Players)
                    {
                        var amountPerPlayer = _percentage * enemy.ObjectDesc.MaxHP / 100 * (i.Value.Client.Character.HP >= 600 ? 1.2 : 1);
                        int amountInc = (int)((plrCount - scstate.initialScaleAmount) * amountPerPlayer);
                        scstate.initialScaleAmount += (plrCount - scstate.initialScaleAmount);

                        int newHpMaximum = enemy.MaximumHP + amountInc;

                        enemy.HP += amountInc;
                        enemy.MaximumHP = newHpMaximum;
                    }
                }
            }
            else
                scstate.cooldown -= time.ElaspedMsDelta;

            state = scstate;
        }
    }
}