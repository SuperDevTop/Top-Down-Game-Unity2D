﻿using System.Xml.Linq;
using common;
using wServer.realm;

namespace wServer.logic.behaviors
{
    class ToggleInteraction : Behavior
    {
        private bool allow;
        public ToggleInteraction(XElement e)
        {
            allow = e.ParseBool("@allow", true);
        }
        
        public ToggleInteraction(bool allow = true)
        {
            this.allow = allow;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            host.InteractionAllowed = allow;
        }
        
        protected override void TickCore(Entity host, RealmTime time, ref object state)
        { }
    }
}
