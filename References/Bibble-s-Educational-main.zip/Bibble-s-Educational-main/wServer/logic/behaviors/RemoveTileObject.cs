﻿using System;
using System.Linq;
using System.Xml.Linq;
using common;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    class RemoveTileObject : Behavior
    {
        private readonly ushort _objType;
        private readonly int _range;

        public RemoveTileObject(XElement e)
        {
            _objType = BehaviorDb.InitGameData.IdToTileType[e.ParseString("@type")];
            _range = e.ParseInt("@range");
        }
        
        public RemoveTileObject(ushort objType, int range)
        {
            _objType = objType;
            _range = range;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            var objType = _objType;

            var map = host.Owner.Map;

            var w = map.Width;
            var h = map.Height;

            for (var y = 0; y < h; y++)
                for (var x = 0; x < w; x++)
                {
                    var tile = map[x, y];

                    if (tile.ObjType != objType)
                        continue;

                    var dx = Math.Abs(x - (int)host.X);
                    var dy = Math.Abs(y - (int)host.Y);

                    if (dx > _range || dy > _range)
                        continue;

                    if (tile.ObjDesc?.BlocksSight == true)
                    {
                        foreach (var plr in host.Owner.Players.Values
                            .Where(p => MathsUtils.DistSqr(p.X, p.Y, x, y) < Player.RadiusSqr))
                            plr.Sight.UpdateCount++;
                    }

                    tile.ObjType = 0;
                    tile.UpdateCount++;
                    map[x, y] = tile;
                }
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state) { }
    }
}
