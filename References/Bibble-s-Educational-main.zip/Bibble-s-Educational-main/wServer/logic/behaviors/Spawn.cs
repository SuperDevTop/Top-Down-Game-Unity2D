﻿using System.Xml.Linq;
using common;
using common.resources;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    class Spawn : Behavior
    {
        //State storage: Spawn state
        class SpawnState
        {
            public int CurrentNumber;
            public int RemainingTime;
        }

        private readonly double _densityRadius;
        private readonly int _maxChildren;
        private readonly int _initialSpawn;
        private Cooldown _coolDown;
        private readonly string _childrenString;
        private ushort? _children;
        private readonly bool _givesNoXp;
        private readonly bool _countMax;
        
        public Spawn(XElement e)
        {
            _childrenString = e.ParseString("@child");
            _densityRadius = e.ParseFloat("@densityRadius", 10);
            _initialSpawn = (int)(_maxChildren * e.ParseFloat("@initialSpawn", 0.5f));
            _coolDown = new Cooldown().Normalize(e.ParseInt("@coolDown"));
            _givesNoXp = e.ParseBool("@givesNoXp", true);
            _maxChildren = e.ParseInt("@maxChildren");
            _countMax = e.ParseBool("@countMax");
        }

        public Spawn(string children, int maxChildren = 5, double initialSpawn = 0.5, Cooldown coolDown = new Cooldown(), bool givesNoXp = true, 
            double densityRadius = 10, bool countMax = false)
        {
            _childrenString = children;
            _densityRadius = densityRadius;
            _initialSpawn = (int)(maxChildren * initialSpawn);
            _coolDown = coolDown.Normalize(0);
            _givesNoXp = givesNoXp;
            _maxChildren = maxChildren;
            _countMax = countMax;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            if (_children == null)
                _children = host.Manager.Resources.GameData.IdToObjectType[_childrenString];
            var count = _initialSpawn;
            if (_countMax) 
                count = host.CountEntity(_densityRadius, _children);
            state = new SpawnState()
            {
                CurrentNumber = count,
                RemainingTime = _coolDown.Next(Random)
            };
            for (int i = 0; i < _initialSpawn; i++)
            {
                Entity entity = Entity.Resolve(host.Manager, _children.Value);
                entity.Move(host.X, host.Y);

                var enemyHost = host as Enemy;
                var enemyEntity = entity as Enemy;

                entity.GivesNoXp = _givesNoXp;
                if (enemyHost != null && !entity.GivesNoXp)
                    entity.GivesNoXp = enemyHost.GivesNoXp;

                if (enemyHost != null && enemyEntity != null)
                {
                    enemyEntity.ParentEntity = host as Enemy;
                    enemyEntity.Terrain = enemyHost.Terrain;
                    if (enemyHost.Spawned)
                    {
                        enemyEntity.Spawned = true;
                        enemyEntity.ApplyConditionEffect(new ConditionEffect()
                        {
                            Effect = ConditionEffectIndex.Invisible,
                            DurationMS = -1
                        });
                    }
                }

                host.Owner.EnterWorld(entity);
                (state as SpawnState).CurrentNumber++;
            }
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
            var spawn = state as SpawnState;

            if (spawn == null)
                return;

            if (spawn.RemainingTime <= 0 && spawn.CurrentNumber < _maxChildren)
            {
                Entity entity = Entity.Resolve(host.Manager, _children.Value);
                entity.Move(host.X, host.Y);

                var enemyHost = host as Enemy;
                var enemyEntity = entity as Enemy;
                if (enemyHost != null && enemyEntity != null)
                {
                    enemyEntity.Terrain = enemyHost.Terrain;
                    if (enemyHost.Spawned)
                    {
                        enemyEntity.Spawned = true;
                        enemyEntity.ApplyConditionEffect(new ConditionEffect()
                        {
                            Effect = ConditionEffectIndex.Invisible,
                            DurationMS = -1
                        });
                    }
                }

                host.Owner.EnterWorld(entity);
                spawn.RemainingTime = _coolDown.Next(Random);
                spawn.CurrentNumber++;
            }
            else
                spawn.RemainingTime -= time.ElaspedMsDelta;
        }
    }
}
