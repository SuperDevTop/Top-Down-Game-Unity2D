﻿using System;
using System.Xml.Linq;
using common;
using wServer.realm;

namespace wServer.logic.behaviors
{
    class SetDisplayName : Behavior
    {
        private readonly string _name; 

        public SetDisplayName(XElement e)
        {
            _name = e.ParseString("@name", "");
        }
        
        public SetDisplayName(string name = "")
        {
            _name = name;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            host.DisplayName.SetValue(_name);
        }
        
        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
        }
    }
}