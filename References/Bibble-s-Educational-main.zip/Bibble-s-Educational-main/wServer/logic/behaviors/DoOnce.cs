﻿using System.Collections.Generic;
using System.Xml.Linq;
using common;
using wServer.realm;

namespace wServer.logic.behaviors
{
    class DoOnce : CycleBehavior
    {
        //State storage: time, then nothing

        Behavior[] behaviors;
        int afterTime;
        
        public DoOnce(XElement e, IStateChildren[] children)
        {
            var behaviors = new List<Behavior>();
            foreach (var child in children)
            {
                if (child is Behavior bh)
                    behaviors.Add(bh);
            }

            this.behaviors = behaviors.ToArray();
            afterTime = e.ParseInt("@afterTime");
        }
        
        public DoOnce(int afterTime, params Behavior[] behaviors)
        {
            this.behaviors = behaviors;
            this.afterTime = afterTime;
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            foreach(var behavior in behaviors)
                behavior.OnStateEntry(host, time);
            state = afterTime;
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
            var afterTime = (int)state;
            if (afterTime == -69) return;

                foreach (var behavior in behaviors)
            {
                Status = CycleStatus.InProgress;

                afterTime -= time.ElaspedMsDelta;
                if (afterTime <= 0)
                {
                    afterTime = -69;
                    behavior.OnStateEntry(host, time);
                    Status = CycleStatus.Completed;
                    //......- -
                    if (behavior is Prioritize)
                        host.StateStorage[behavior] = -1;
                }
            }

            state = afterTime;
        }
    }
}
