﻿using System.Xml.Linq;
using common;
using wServer.realm;

namespace wServer.logic.transitions
{
    class OnInteractionTransition : Transition
    {
        public OnInteractionTransition(XElement e) : base(e.ParseString("@targetState", "root"))
        {
        }

        public OnInteractionTransition(string targetState) : base(targetState)
        {
        }
        
        protected override bool TickCore(Entity host, RealmTime time, ref object state)
        {
            if (host.InteractionOccurred)
            {
                host.InteractionOccurred = false;
                return true;
            }

            return false;
        }
    }
}