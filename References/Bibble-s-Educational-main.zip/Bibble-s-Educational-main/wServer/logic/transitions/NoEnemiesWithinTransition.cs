﻿using System.Xml.Linq;
using common;
using wServer.realm;

namespace wServer.logic.transitions
{
    class NoEnemiesWithinTransition : Transition
    {
        //State storage: none

        private readonly int _dist;

        public NoEnemiesWithinTransition(XElement e)
            : base(e.ParseString("@targetState", "root"))
        {
            _dist = e.ParseInt("@dist");
        }
        
        public NoEnemiesWithinTransition(int dist, string targetState)
            : base(targetState)
        {
            _dist = dist;
        }

        protected override bool TickCore(Entity host, RealmTime time, ref object state)
        {
            return !host.AnyKillableEnemyNearby(_dist);
        }
    }
}
