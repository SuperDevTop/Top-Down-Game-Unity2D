﻿using System;
using System.Collections.Generic;
using System.Linq;
using common.resources;
using wServer.realm.entities;
using wServer.realm;
using wServer;
using wServer.realm.worlds.logic;
using wServer.networking.packets.outgoing;
using common;

namespace wServer.logic.loot
{
    public class LootDef
    {
        public readonly Item Item;
        public readonly double Probabilty;
        public readonly int NumRequired;
        public readonly double Threshold;

        public LootDef(Item item, double probabilty, int numRequired, double threshold)
        {
            Item = item;
            Probabilty = probabilty;
            NumRequired = numRequired;
            Threshold = threshold;
        }
    }

    public class Loot : List<MobDrops>
    {
        static readonly Random Rand = new Random();

        static readonly ushort BROWN_BAG = 0x0500;
        static readonly ushort MAGIC_POTION_BAG = 0x6018;
        static readonly ushort HEALTH_POTION_BAG = 0x6019;
        static readonly ushort PINK_BAG = 0x0506;
        static readonly ushort PURPLE_BAG = 0x601A;
        static readonly ushort EGG_BASKET = 0x0508;
        static readonly ushort CYAN_BAG = 0x601C;
        static readonly ushort POTION_BAG = 0x601B;
        static readonly ushort WHITE_BAG = 0x050C;
        static readonly ushort RARE_BAG = 0x601D;
        static readonly ushort LEGEND_BAG = 0x601E;
        static readonly ushort ANCIENT_BAG = 0x601F;
        static readonly float[] TORMENT = { 1f, 1.2f, 1.5f, 2f, 3f, 5f };
        static readonly int EVENT = Program.Config.serverSettings.lbEventRate;

        public Loot(params MobDrops[] lootDefs)   //For independent loots(e.g. chests)
        {
            AddRange(lootDefs);
        }

        public IEnumerable<Item> GetLoots(RealmManager manager, int min, int max)   //For independent loots(e.g. chests)
        {
            var consideration = new List<LootDef>();
            foreach (var i in this)
            {
                i.Populate(consideration);
            }

            var retCount = Rand.Next(min, max);
            foreach (var i in consideration)
            {
                if (Rand.NextDouble() < i.Probabilty)
                {
                    yield return i.Item;
                    retCount--;
                }
                if (retCount == 0)
                {
                    yield break;
                }
            }
        }

        public List<LootDef> GetPossibleDrops()
        {
            var possibleDrops = new List<LootDef>();
            foreach (var i in this)
            {
                i.Populate(possibleDrops);
            }
            return possibleDrops;
        }

        public void Handle(Enemy enemy, RealmTime time)
        {
            // enemies that shouldn't drop loot
            if (enemy.Spawned || enemy.Owner is Arena || enemy.Owner is ArenaSolo)
            {
                return;
            }

            // generate a list of all possible loot drops
            var possibleDrops = GetPossibleDrops();
            var possibleWorldDrops = enemy.Owner.WorldLoot.GetPossibleDrops();
            foreach (var wDrop in possibleWorldDrops.Where(drop => drop.Item.ObjectType != 0xa22 && drop.Item.ObjectType != 0xa23))
            {
                // so we can override drops with world drops if we want to. For example, Oryx's arena key not dropping in OA.
                possibleDrops.RemoveAll(d => d.Item == wDrop.Item);
            }
            possibleDrops.AddRange(possibleWorldDrops); // adds world drops
            var reqDrops = possibleDrops.ToDictionary(drop => drop, drop => drop.NumRequired);

            // generate public loot
            var publicLoot = new List<Item>();
            foreach (var i in possibleDrops)
            {
                if (i.Threshold <= 0 && Rand.NextDouble() < i.Probabilty)
                {
                    publicLoot.Add(i.Item);
                    reqDrops[i]--;
                }
            }

            // generate individual player loot
            var eligiblePlayers = enemy.DamageCounter.GetPlayerData();
            var privateLoot = new Dictionary<Player, IList<Item>>();
            foreach (var player in eligiblePlayers)
            {
                var plr = player.Item1;
                double allBoosts = 1.0;
                if (enemy.ObjectDesc.Quest || enemy.ObjectDesc.MaxHP > 1000)
                {
                    int[] modifiers = new int[5];
                    modifiers[0] = plr.LDBoostTime > 0 ? 50 : 0;
                    modifiers[1] = plr.SupportRune == 2 ? 33 : 0;
                    modifiers[2] = plr.AttackRune == 5 ? 20 : 0;
                    modifiers[3] = 0;
                    modifiers[4] = (int)enemy.Owner.WorldLootBoost;
                    if (plr.Client.Account.GuildId != 0)
                    {
                        DbGuild guild = plr.Manager.Database.GetGuild(plr.Client.Account.GuildId);
                        modifiers[3] = (guild.Level * 5) + guild.LootBoost;
                    }

                    var damage = Math.Min(1, Math.Round(player.Item2 / (double)enemy.MaximumHP, 2));
                    allBoosts = 1 + (EVENT + modifiers.Sum()) / 100 + damage;
                }

                var loot = new List<Item>();
                foreach (var i in possibleDrops)
                {
                    if (i.Threshold > 0 && i.Threshold <= player.Item2 &&
                        Rand.NextDouble() < i.Probabilty * allBoosts)
                    {
                        loot.Add(i.Item);
                        reqDrops[i]--;
                    }
                }
                privateLoot[player.Item1] = loot;
            }

            // add required drops that didn't drop already
            foreach (var i in possibleDrops)
            {
                if (i.Threshold <= 0)
                {
                    // add public required loot
                    while (reqDrops[i] > 0)
                    {
                        publicLoot.Add(i.Item);
                        reqDrops[i]--;
                    }
                    continue;
                }

                // add private required loot
                var ePlayers = eligiblePlayers.Where(p => i.Threshold <= p.Item2).ToList();
                if (ePlayers.Count() <= 0)
                    continue;

                while (reqDrops[i] > 0 && ePlayers.Count() > 0)
                {
                    // make sure a player doesn't recieve more than one required loot
                    var reciever = ePlayers.RandomElement(Rand);
                    ePlayers.Remove(reciever);

                    // don't assign item if player already recieved one with random chance
                    if (privateLoot[reciever.Item1].Contains(i.Item))
                    {
                        continue;
                    }

                    privateLoot[reciever.Item1].Add(i.Item);
                    reqDrops[i]--;
                }
            }

            AddBagsToWorld(enemy, publicLoot, privateLoot);
        }

        private void AddBagsToWorld(Enemy enemy, IList<Item> shared, IDictionary<Player, IList<Item>> playerLoot)
        {
            foreach (var i in playerLoot)
            {
                if (i.Value.Count > 0)
                {
                    ShowBags(enemy, i.Value, i.Key);
                }
            }
            ShowBags(enemy, shared);
        }

        private static void ShowBags(Enemy enemy, IEnumerable<Item> loots, params Player[] owners)
        {
            var ownerIds = owners.Select(x => x.AccountId).ToArray();
            var items = new Item[8];
            var idx = 0;
            var bagType = 0;
            var highestTier = "";

            if (enemy.ObjectDesc.TrollWhiteBag)
                bagType = 8;

            var percent = 0d;
            if (ownerIds.Length > 0)
            {
                var total = enemy.DamageCounter.GetPlayerData().FirstOrDefault(x => ownerIds[0] == x.Item1.AccountId)?.Item2;
                if (total != null)
                    percent = Math.Min(100, Math.Round(total.Value / (double)enemy.MaximumHP * 100, 2));
            }
            
            foreach (var i in loots)
            {
                string rarity = "";
                if (i.Rare) rarity = "Rare";
                if (i.Legendary) rarity = "Legendary";
                if (i.Ancient) rarity = "Ancient";
                if (rarity != "")
                {
                    owners[0].Manager.Chat.Notification($"{owners[0].Name} has gotten a {rarity.ToLower()}: \'{i.ObjectId}\' with {percent}% damage dealt!");
                    if (rarity == "Ancient")
                        highestTier = rarity;
                    else if (highestTier != "Ancient" && rarity == "Legendary")
                        highestTier = rarity;
                    else if (highestTier == "" && rarity == "Rare")
                        highestTier = rarity;
                    if (rarity == "Legendary" || rarity == "Immortal")
                    {
                        var data = new Dictionary<string, string> { {"tier",rarity}, {"itemName",i.ObjectId}, {"playerName",owners[0].Name}, {"percent",percent.ToString()} };
                        WebhookLink.SendToWebhookClient(WebhookType.Loot, data);
                    }
                }

                if (i.BagType > bagType)
                    bagType = i.BagType;

                items[idx] = i;
                idx++;

                if (idx != 8)
                    continue;

                ShowBag(enemy, ownerIds, bagType, items);

                bagType = 0;
                items = new Item[8];
                idx = 0;
            }

            if (highestTier != "")
                owners[0].Client.SendPacket(new GlobalNotification() { Text = highestTier.ToLower() });

            if (idx > 0)
                ShowBag(enemy, ownerIds, bagType, items);
        }

        private static void ShowBag(Enemy enemy, int[] owners, int bagType, Item[] items)
        {
            ushort bag = BROWN_BAG;
            switch (bagType)
            {
                case 0:
                    if (items[0].ObjectId == "Magic Potion") bag = MAGIC_POTION_BAG; 
                    else bag = HEALTH_POTION_BAG;
                    break;
                case 1: bag = PINK_BAG; break;
                case 2: bag = PURPLE_BAG; break;
                case 3: bag = EGG_BASKET; break;
                case 4: bag = CYAN_BAG; break;
                case 5: bag = POTION_BAG; break;
                case 6: bag = WHITE_BAG; break;
                case 7: bag = RARE_BAG; break;
                case 8: bag = LEGEND_BAG; break;
                case 9: bag = ANCIENT_BAG; break;
            }

            var container = new Container(enemy.Manager, bag, 1000 * 60, true);
            for (int j = 0; j < 8; j++)
            {
                container.Inventory[j] = items[j];
            }
            container.BagOwners = owners;
            container.Move(
                enemy.X + (float)((Rand.NextDouble() * 2 - 1) * 0.5),
                enemy.Y + (float)((Rand.NextDouble() * 2 - 1) * 0.5));
            container.SetDefaultSize(container.ObjectDesc?.MinSize ?? 100);
            enemy.Owner.EnterWorld(container);
        }
    }
}