﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using common;
using common.resources;
using log4net;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.loot
{
    public interface IMobDrop { }
    public abstract class MobDrops : IMobDrop
    {
        protected static XmlData XmlData;
        protected readonly IList<LootDef> LootDefs = new List<LootDef>();
        public Player plr;

        public static void Init(RealmManager manager)
        {
            if (XmlData != null)
                throw new Exception("MobDrops already initialized");

            XmlData = manager.Resources.GameData;
        }

        public virtual void Populate(IList<LootDef> lootDefs, LootDef overrides = null)
        {
            if (overrides == null)
            {
                foreach (var lootDef in LootDefs)
                    lootDefs.Add(lootDef);
                return;
            }

            foreach (var lootDef in LootDefs)
            {
                lootDefs.Add(new LootDef(
                    lootDef.Item, 
                    overrides.Probabilty >= 0 ? overrides.Probabilty : lootDef.Probabilty,
                    overrides.NumRequired >= 0 ? overrides.NumRequired : lootDef.NumRequired,
                    overrides.Threshold >= 0 ? overrides.Threshold : lootDef.Threshold));
            }
        }
    }

    public class ItemLoot : MobDrops
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ItemLoot));

        public ItemLoot(XElement e)
        {
            
            try
            {
                LootDefs.Add(new LootDef(
                    XmlData.Items[XmlData.IdToObjectType[e.ParseString("@item")]],
                    e.ParseFloat("@probability", 1),
                    e.ParseInt("@numRequired"),
                    e.ParseInt("@threshold")));
            }
            catch
            {
                Log.Warn($"Problem adding {e.Attribute("item")} to mob loot table.");
            }
        }

        public ItemLoot(string item, double probability = 1, int numRequired = 0, double threshold = 0)
        {
            try
            {
                LootDefs.Add(new LootDef(
                    XmlData.Items[XmlData.IdToObjectType[item]],
                    probability,
                    numRequired,
                    threshold));
            }
            catch
            {
                Log.Warn($"Problem adding {item} to mob loot table.");
            }
        }
    }

    public class FragLoot : MobDrops
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ItemLoot));

        public FragLoot(XElement e)
        {
            var maxedStats = plr.Manager.Resources.GameData.Classes[plr.ObjectType].Stats;
            for (var i = 0; i < 8; i++)
            {
                if (plr.Stats.Base[i] != maxedStats[i].MaxValue)
                    return;
            }
            try
            {
                LootDefs.Add(new LootDef(
                    XmlData.Items[XmlData.IdToObjectType[e.ParseString("@item")]],
                    e.ParseFloat("@probability", 1),
                    e.ParseInt("@numRequired"),
                    e.ParseInt("@threshold")));
            }
            catch
            {
                Log.Warn($"Problem adding {e.Attribute("item")} to mob loot table.");
            }
        }
        
        public FragLoot(string item, double probability = 1, int numRequired = 0, double threshold = 0)
        {
            var maxedStats = plr.Manager.Resources.GameData.Classes[plr.ObjectType].Stats;
            for (var i = 0; i < 8; i++)
            {
                if (plr.Stats.Base[i] != maxedStats[i].MaxValue)
                    return;
            }
            try
            {
                LootDefs.Add(new LootDef(
                    XmlData.Items[XmlData.IdToObjectType[item]],
                    probability,
                    numRequired,
                    threshold));
            }
            catch
            {
                Log.Warn($"Problem adding {item} to mob loot table.");
            }
        }
    }

    public class TierLoot : MobDrops
    {
        private static readonly int[] WeaponT = new int[] { 1, 2, 3, 8, 17, 24, };
        private static readonly int[] AbilityT = new int[] { 4, 5, 11, 12, 13, 15, 16, 18, 19, 20, 21, 22, 23, 25, };
        private static readonly int[] ArmorT = new int[] { 6, 7, 14, };
        private static readonly int[] RingT = new int[] { 9 };
        private static readonly int[] PotionT = new int[] { 10 };
        
        public TierLoot(XElement e)
        {
            int[] types;
            var type = Enum.Parse(typeof(ItemType), e.Attribute("type")?.Value ?? "Weapon");
            switch (type)
            {
                case ItemType.Weapon:
                    types = WeaponT; break;
                case ItemType.Ability:
                    types = AbilityT; break;
                case ItemType.Armor:
                    types = ArmorT; break;
                case ItemType.Ring:
                    types = RingT; break;
                case ItemType.Potion:
                    types = PotionT; break;
                default:
                    throw new NotSupportedException(type.ToString());
            }

            var items = XmlData.Items
                .Where(item => Array.IndexOf(types, item.Value.SlotType) != -1)
                .Where(item => item.Value.Tier == (int.Parse(e.Attribute("tier").Value)))
                .Select(item => item.Value)
                .ToArray();

            foreach (var item in items)
                LootDefs.Add(new LootDef(
                    item,
                    e.ParseFloat("@probability", 1) / items.Length,
                    e.ParseInt("@numRequired"),
                    e.ParseInt("@threshold")));
        }
        
        public TierLoot(byte tier, ItemType type, double probability = 1, int numRequired = 0, double threshold = 0)
        {
            int[] types;
            switch (type)
            {
                case ItemType.Weapon:
                    types = WeaponT; break;
                case ItemType.Ability:
                    types = AbilityT; break;
                case ItemType.Armor:
                    types = ArmorT; break;
                case ItemType.Ring:
                    types = RingT; break;
                case ItemType.Potion:
                    types = PotionT; break;
                default:
                    throw new NotSupportedException(type.ToString());
            }

            var items = XmlData.Items
                .Where(item => Array.IndexOf(types, item.Value.SlotType) != -1)
                .Where(item => item.Value.Tier == tier)
                .Select(item => item.Value)
                .ToArray();

            foreach (var item in items)
                LootDefs.Add(new LootDef(
                    item,
                    probability / items.Length,
                    numRequired,
                    threshold));
        }
    }

    public class LootTemplates : MobDrops
    {
        public static MobDrops[] MountainDrop()
        {
            return new MobDrops[]
            {
                new TierLoot(6, ItemType.Weapon, .1),
                new TierLoot(7, ItemType.Weapon, .1),
                new TierLoot(8, ItemType.Weapon, .1),
                new TierLoot(7, ItemType.Armor, .1),
                new TierLoot(8, ItemType.Armor, .1),
                new TierLoot(9, ItemType.Armor, .1),
                new TierLoot(3, ItemType.Ability, .1),
                new TierLoot(4, ItemType.Ability, .1),
                new TierLoot(3, ItemType.Ring, .1),
                new TierLoot(4, ItemType.Ring, .1),
                new ItemLoot("Accessory Tablet", .03)
            };
        }
        public static MobDrops[] BasicDrop()
        {
            return new MobDrops[]
            {
                new TierLoot(10, ItemType.Weapon, .07),
                new TierLoot(11, ItemType.Weapon, .07),
                new TierLoot(4, ItemType.Ability, .07),
                new TierLoot(5, ItemType.Ability, .07),
                new TierLoot(11, ItemType.Armor, .07),
                new TierLoot(12, ItemType.Armor, .07),
                new TierLoot(4, ItemType.Ring, .07),
                new TierLoot(5, ItemType.Ring, .07),
                new ItemLoot("Shard of Evolution", 0.005),
                new ItemLoot("Accessory Tablet", .05)
            };
        }

        public static MobDrops[] StrongerDrop()
        {
            return new MobDrops[]
            {
                new TierLoot(11, ItemType.Weapon, .1),
                new TierLoot(12, ItemType.Weapon, .05),
                new TierLoot(5, ItemType.Ability, .1),
                new TierLoot(6, ItemType.Ability, .05),
                new TierLoot(12, ItemType.Armor, .1),
                new TierLoot(13, ItemType.Armor, .05),
                new TierLoot(5, ItemType.Ring, .1),
                new TierLoot(6, ItemType.Ring, .05),
                new ItemLoot("Shard of Evolution", 0.005),
                new ItemLoot("Accessory Tablet", .1)
            };
        }

        public static MobDrops[] OryxOneDrop()
        {
            return new MobDrops[]
            {
                new TierLoot(14, ItemType.Weapon, .25),
                new TierLoot(7, ItemType.Ability, .25),
                new TierLoot(15, ItemType.Armor, .25),
                new TierLoot(7, ItemType.Ring, .25),
                new ItemLoot("Shard of Evolution", 0.01),
                new ItemLoot("Accessory Tablet", .25),
                new ItemLoot("Potion of Defense", .75),
                new ItemLoot("Potion of Attack", .75),
                new ItemLoot("Potion of Speed", .75),
                new ItemLoot("Potion of Vitality", .75),
                new ItemLoot("Potion of Wisdom", .75),
                new ItemLoot("Potion of Dexterity", .75),
                new ItemLoot("Potion of Life", .5),
                new ItemLoot("Potion of Mana", .5),
                new ItemLoot("Potion Tablet", .8)
            };
        }

        public static MobDrops[] MiniDrop()
        {
            return new MobDrops[]
            {
                new TierLoot(14, ItemType.Weapon, .1),
                new TierLoot(7, ItemType.Ability, .1),
                new TierLoot(15, ItemType.Armor, .1),
                new TierLoot(7, ItemType.Ring, .1),
                new ItemLoot("Shard of Evolution", 0.005),
                new ItemLoot("Accessory Tablet", .125),
                new ItemLoot("Potion of Defense", .37),
                new ItemLoot("Potion of Attack", .37),
                new ItemLoot("Potion of Speed", .37),
                new ItemLoot("Potion of Vitality", .37),
                new ItemLoot("Potion of Wisdom", .37),
                new ItemLoot("Potion of Dexterity", .37),
                new ItemLoot("Potion of Life", .25),
                new ItemLoot("Potion of Mana", .25),
                new ItemLoot("Potion Tablet", .4)
            };
        }

        public static MobDrops[] BasicPots()
        {
            return new MobDrops[]
            {
                new ItemLoot("Potion of Defense", .16),
                new ItemLoot("Potion of Attack", .16),
                new ItemLoot("Potion of Speed", .16),
                new ItemLoot("Potion of Vitality", .16),
                new ItemLoot("Potion of Wisdom", .16),
                new ItemLoot("Potion of Dexterity", .16),
                new ItemLoot("Potion Tablet", .30),
            };
        }

        public static MobDrops[] StrongerPots()
        {
            return new MobDrops[]
            {
                new ItemLoot("Potion of Defense", .2),
                new ItemLoot("Potion of Attack", .2),
                new ItemLoot("Potion of Speed", .2),
                new ItemLoot("Potion of Vitality", .2),
                new ItemLoot("Potion of Wisdom", .2),
                new ItemLoot("Potion of Dexterity", .2),
                new ItemLoot("Potion of Life", .2),
                new ItemLoot("Potion of Mana", .2),
                new ItemLoot("Potion Tablet", .3),
            };
        }
    }

    public class Threshold : MobDrops
    {
        public Threshold(XElement e, IMobDrop[] children)
        {
            foreach (var child in children)
            {
                if (child is MobDrops md)
                {
                    md.Populate(LootDefs, new LootDef(null, -1, -1, e.ParseFloat("@threshold")));
                }
            }
        }
        
        public Threshold(double threshold, params MobDrops[] children)
        {
            foreach (var i in children)
                i.Populate(LootDefs, new LootDef(null, -1, -1, threshold));
        }
    }
}
