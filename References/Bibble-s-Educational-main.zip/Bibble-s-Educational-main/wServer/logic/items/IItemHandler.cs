﻿using System;
using System.Collections.Generic;
using System.Linq;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.items
{
    interface IItemHandler
    {

        void OnAbilityUse(RealmTime? time, Player player, Position position);

        void OnHitEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile);

        void OnHitByEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile);

    }
}
