﻿using System;
using System.Collections.Generic;
using wServer.logic.items.handlers;

namespace wServer.logic.items
{
    class ItemHandlerFactory
    {
        public static Dictionary<string, IItemHandler> Handler = new Dictionary<string, IItemHandler>();

        static ItemHandlerFactory()
        {
            Handler.Add("Twilight Curse", new TwilightCurse());
            Handler.Add("Fire Spin", new FireSpin());
            Handler.Add("Jerry", new Jerry());
            Handler.Add("HornedHelm", new HornedHelmet());
        }

    }
}
