﻿using common.resources;
using System;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.items.handlers
{
    class TwilightCurse : IItemHandler
    {

        private static Random Random = new Random();

        public void OnAbilityUse(RealmTime? time, Player player, Position target)
        {
        }

        public void OnHitByEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
            if(Random.NextDouble() < 0.1)
            {
                player.MP -= player.MP / 10;
                player.ApplyConditionEffect(
                    new ConditionEffect()
                    {
                        Effect = ConditionEffectIndex.Curse,
                        DurationMS = 5000,
                    }
                );

                player.BroadcastSync(new Notification()
                {
                    ObjectId = player.Id,
                    Color = new ARGB(0x800080),
                    Message = "Twilight Curse..."
                }, p => player.DistSqr(p) < 10);
            }
        }

        public void OnHitEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
            if (hit == null) return;
            if (player.WeaponRNG(0.02, player))
            {
                hit.ApplyConditionEffect(
                    new ConditionEffect()
                    {
                        Effect = ConditionEffectIndex.Curse,
                        DurationMS = 2000,
                    }
                );
                player.BroadcastSync(new Notification()
                {
                    ObjectId = hit.Id,
                    Color = new ARGB(0x800080),
                    Message = "Twilight Curse..."
                }, p => player.DistSqr(p) < 10);
            }
        }
    }
}
