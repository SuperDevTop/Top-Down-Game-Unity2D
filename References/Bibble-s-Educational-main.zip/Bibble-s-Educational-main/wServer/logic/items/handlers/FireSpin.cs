﻿using common.resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.items.handlers
{
    class FireSpin : IItemHandler
    {

        private static Random Random = new Random();

        public void OnAbilityUse(RealmTime? time, Player player, Position position)
        {
        }

        public void OnHitByEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
        }

        public void OnHitEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
            if(Random.NextDouble() < 0.3)
            {

                player.Client.SendPacket(new ShowEffect()
                {
                    EffectType = EffectType.AreaBlast,
                    Color = new ARGB(0xffff),
                    TargetObjectId = hit.Id,
                    Pos1 = new Position() { X = 3 }
                });

                player.Owner.AOE(hit.Position, 3, false,
                    enemy =>
                    {
                        (enemy as Enemy).Damage(player, time.Value, 500, false, new ConditionEffect() { Effect = ConditionEffectIndex.Slowed, DurationMS = 750 });
                    });
            }
        }
    }
}
