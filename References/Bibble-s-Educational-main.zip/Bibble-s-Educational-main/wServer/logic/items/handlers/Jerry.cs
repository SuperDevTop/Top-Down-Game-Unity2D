﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.items.handlers
{
    class Jerry : IItemHandler
    {

        private static Random Random = new Random();

        public void OnAbilityUse(RealmTime? time, Player player, Position position)
        {
        }

        public void OnHitByEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
        }

        public void OnHitEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
            if(Random.NextDouble() < 0.1)
            {

                player.Client.SendPacket(new ShowEffect()
                {
                    EffectType = EffectType.AreaBlast,
                    Color = new ARGB(0xffff00ff),
                    TargetObjectId = player.Id,
                    Pos1 = new Position() { X = 1 }
                });

                //CustomCXML.xml Jerry Ally Minion
                Entity minion = Entity.Resolve(player.Manager, 0x5407);
                minion.SetPlayerOwner(player);

                minion.Move(player.Position.X, player.Position.Y);
                player.Owner.EnterWorld(minion);

            }
        }
    }
}
