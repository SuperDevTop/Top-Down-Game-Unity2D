﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wServer.networking.packets.outgoing;
using wServer.realm;
using wServer.realm.entities;

namespace wServer.logic.items.handlers
{
    class HornedHelmet : IItemHandler
    {
        public void OnAbilityUse(RealmTime? time, Player player, Position position)
        {
        }

        public void OnHitByEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
        }

        private static Random Random = new Random();

        public void OnHitEnemy(RealmTime? time, Player player, Enemy hit, Projectile projectile)
        {
            if(player.WeaponRNG(0.03, player))
            {
                player.Owner.AOE(hit.Position, 5.0f, false, (e) => {
                    e.ApplyConditionEffect(new common.resources.ConditionEffect()
                    {
                        DurationMS = 5000,
                        Effect = common.resources.ConditionEffectIndex.Paralyzed
                    });
                });

                player.Client.SendPacket(new ShowEffect()
                {
                    EffectType = EffectType.AreaBlast,
                    Color = new ARGB(0xff000088),
                    TargetObjectId = hit.Id,
                    Pos1 = new Position() { X = 5 }
                });

                player.BroadcastSync(new Notification()
                {
                    ObjectId = hit.Id,
                    Color = new ARGB(0x000088),
                    Message = "Lunar Cripple!"
                }, p => player.DistSqr(p) < 10);

            }
        }
    }
}
