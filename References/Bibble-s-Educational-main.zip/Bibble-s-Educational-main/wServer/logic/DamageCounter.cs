﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using common;
using wServer.logic.behaviors;
using wServer.realm.entities;
using wServer.realm;
using wServer.realm.worlds;
using wServer.realm.worlds.logic;

namespace wServer.logic
{
    public class DamageCounter
    {
        Enemy enemy;
        public Enemy Host { get { return enemy; } }
        public Projectile LastProjectile { get; private set; }
        public Player LastHitter { get; private set; }

        public DamageCounter Corpse { get; set; }
        public DamageCounter Parent { get; set; }

        public WeakDictionary<Player, int> hitters = new WeakDictionary<Player, int>();
        public DamageCounter(Enemy enemy)
        {
            this.enemy = enemy;
        }

        public void HitBy(Player player, RealmTime time, Projectile projectile, int dmg)
        {
            int totalDmg;
            if (!hitters.TryGetValue(player, out totalDmg))
                totalDmg = 0;
            totalDmg += dmg;
            hitters[player] = totalDmg;

            LastProjectile = projectile;
            LastHitter = player;

            player.FameCounter.Hit(projectile, enemy);
        }

        public Tuple<Player, int>[] GetPlayerData()
        {
            if (Parent != null)
                return Parent.GetPlayerData();
            List<Tuple<Player, int>> dat = new List<Tuple<Player, int>>();
            foreach (var i in hitters)
            {
                if (i.Key.Owner == null) continue;
                dat.Add(new Tuple<Player, int>(i.Key, i.Value));
            }
            return dat.ToArray();
        }

        public void Death(RealmTime time)
        {
            if (Corpse != null)
            {
                Corpse.Parent = this;
                return;
            }

            var enemy = (Parent ?? this).enemy;

            if (enemy.Owner is Realm)
                (enemy.Owner as Realm).EnemyKilled(enemy, (Parent ?? this).LastHitter);
            if (enemy.Owner is Minis)
                (enemy.Owner as Minis).EnemyKilled(enemy, (Parent ?? this).LastHitter);

            if (enemy.Spawned || enemy.Owner is Arena || enemy.Owner is ArenaSolo)
                return;

            int lvlUps = 0;
            foreach (var player in enemy.Owner.Players.Values
                .Where(p => enemy.Dist(p) < 25))
            {
                if (player.HasConditionEffect(common.resources.ConditionEffects.Paused))
                    continue;

                var killer = (Parent ?? this).LastHitter == player;
                if (player.EnemyKilled(
                        enemy,
                        Experience(player),
                        killer) && !killer)
                    lvlUps++;
            }

            if ((Parent ?? this).LastHitter != null)
                (Parent ?? this).LastHitter.FameCounter.LevelUpAssist(lvlUps);
        }

        private int Experience(Player player)
        {
            if (enemy.GivesNoXp || enemy.ObjectDesc.ExpMultiplier == 0)
                return 0;
            
            Random random = new Random();
            float rng = (random.Next(1, 10) / 10f) + 1;

            int regular = enemy.ObjectDesc.MaxHP / 10;
            int objective = 400;
            int altObjective = player.ExperienceGoal / 2;
            int xpMult = player.XPBoostTime > 0 ? 1 : 0;
            int donorMult = player.Client.Account.Rank / 10 > 3 ? 3 : player.Client.Account.Rank / 10;

            int a = objective;
            if (enemy.ObjectDesc.Quest)
                a = altObjective;

            if (player.Level == 20)
            {
                if (enemy.ObjectDesc.Quest && enemy.MaximumHP > 100000)
                {
                    objective = 4000;
                    if (enemy.Owner is Realm || enemy.Owner is Nexus)
                        return objective * (int)rng;
                    return objective * ((1 + enemy.Owner.Difficulty) / 3);
                }
                return regular > objective ? objective : regular;
            }
            return regular > a ? a : regular * (xpMult + donorMult + 1);
        }

        public void TransferData(DamageCounter dc)
        {
            dc.LastProjectile = LastProjectile;
            dc.LastHitter = LastHitter;

            foreach (var plr in hitters.Keys)
            {
                int totalDmg;
                int totalExistingDmg;

                if (!hitters.TryGetValue(plr, out totalDmg))
                    totalDmg = 0;
                if (!dc.hitters.TryGetValue(plr, out totalExistingDmg))
                    totalExistingDmg = 0;

                dc.hitters[plr] = totalDmg + totalExistingDmg;
            }
        }
    }
}