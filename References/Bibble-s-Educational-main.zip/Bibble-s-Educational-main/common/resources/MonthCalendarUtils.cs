﻿using System;
using System.Collections.Generic;

namespace common.resources
{
    public class MonthCalendarUtils
    {
        public static DateTime StartDate = new DateTime(2019, 12, 1, 0, 0, 0, DateTimeKind.Utc);
        public static DateTime EndDate = new DateTime(2019, 12, 31, 23, 59, 59, DateTimeKind.Utc);
        public static bool DISABLE_CALENDAR = false;

        public static bool IsNextDay(DateTime dateTime) => dateTime != DateTime.Today;
        public static bool IsNextCalendar(DateTime dateTime) => dateTime < StartDate;

        public static List<FetchCalendarDay> MonthCalendarList = new List<FetchCalendarDay>()
        {
            new FetchCalendarDay //1
            {
                Item = 0xc6c,
                Quantity = 1
            },
            new FetchCalendarDay //2
            {
                Item = 0x1e2f,
                Quantity = 4
            },
            new FetchCalendarDay //3
            {
                Item = 0xd8c,
                Quantity = 1
            },
            new FetchCalendarDay //4
            {
                Item = 0x70b,
                Quantity = 3
            },
            new FetchCalendarDay //5
            {
                Item = 0xd8c,
                Quantity = 1
            },
            new FetchCalendarDay //6
            {
                Item = 0x1107,
                Quantity = 1
            },
            new FetchCalendarDay //7
            {
                Item = 0x1007,
                Quantity = 1
            },
            new FetchCalendarDay //8
            {
                Item = 0x236C,
                Quantity = 2
            },
            new FetchCalendarDay //9
            {
                Item = 0xd8c,
                Quantity = 2
            },
            new FetchCalendarDay //10
            {
                Item = 0xcf0,
                Quantity = 1
            },
            new FetchCalendarDay //11
            {
                Item = 0x2368,
                Quantity = 2
            },
            new FetchCalendarDay //12
            {
                Item = 0x236A,
                Quantity = 2
            },
            new FetchCalendarDay //13
            {
                Item = 0x2290,
                Quantity = 3
            },
            new FetchCalendarDay //14
            {
                Item = 0x236B,
                Quantity = 2
            },
            new FetchCalendarDay //15
            {
                Item = 0x2397,
                Quantity = 1
            },
            new FetchCalendarDay //16
            {
                Item = 0x236D,
                Quantity = 2
            },
            new FetchCalendarDay //17
            {
                Item = 0xaea,
                Quantity = 3
            },
            new FetchCalendarDay //18
            {
                Item = 0xd8c,
                Quantity = 3
            },
            new FetchCalendarDay //19
            {
                Item = 0x746c,
                Quantity = 2
            },
            new FetchCalendarDay //20
            {
                Item = 0xae9,
                Quantity = 3
            },
            new FetchCalendarDay //21
            {
                Item = 0xd8c,
                Quantity = 3
            },
            new FetchCalendarDay //22
            {
                Item = 0xa20,
                Quantity = 2
            },
            new FetchCalendarDay //23
            {
                Item = 0x1411,
                Quantity = 1
            },
            new FetchCalendarDay //24
            {
                Item = 0xd8e,
                Quantity = 1
            },
            new FetchCalendarDay //25
            {
                Item = 0xd8e,
                Quantity = 2
            },
            new FetchCalendarDay //26
            {
                Item = 0xd8e,
                Quantity = 3
            },
            new FetchCalendarDay //27
            {
                Item = 0x21a,
                Quantity = 1
            },
            new FetchCalendarDay //28
            {
                Item = 0x17dd,
                Quantity = 1
            },
            new FetchCalendarDay //29
            {
                Item = 0xd8c,
                Quantity = 4
            },
            new FetchCalendarDay //30
            {
                Item = 0x138d,
                Quantity = 5
            },
            new FetchCalendarDay //31
            {
                Item = 0x190,
                Quantity = 1
            }
        };

        public class FetchCalendarDay
        {
            public int Item = -1;
            public int Gold = 0;
            public int Quantity = 0;
        }
    }
}
