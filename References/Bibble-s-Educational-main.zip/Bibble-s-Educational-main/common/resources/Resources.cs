﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using log4net;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;

namespace common.resources
{
    public class Resources : IDisposable
    {
        static readonly ILog Log = LogManager.GetLogger(typeof(Resources));

        public string ResourcePath { get; private set; }
        public AppSettings Settings { get; private set; }
        public XmlData GameData { get; private set; }
        public WorldData Worlds { get; private set; }
        public ChangePassword ChangePass { get; private set; }
        public MysteryBoxes MysteryBoxes { get; private set; }
        public Packages Packages { get; private set; }
        public Regex[] FilterList { get; private set; }
        public IDictionary<string, byte[]> Languages { get; private set; }
        public IDictionary<string, byte[]> Textures { get; private set; }
		public IDictionary<string, byte[]> WebFiles { get; private set; }
        public Ranks[] RoleRanks { get; private set; }

        public Resources(string resourcePath, bool wServer = false)
        {
            ResourcePath = resourcePath;
            Settings = new AppSettings(resourcePath + "/data/init.xml");
            GameData = new XmlData(resourcePath);
            FilterList = File.ReadAllText(resourcePath + "/data/filterList.txt")
                .Split(new string[] { Environment.NewLine }, StringSplitOptions.None)
                .Select(l => new Regex(l, RegexOptions.IgnoreCase)).ToArray();

            if (!wServer)
            {
                ChangePass = new ChangePassword(resourcePath + "/data/changePassword");

                MysteryBoxes = new MysteryBoxes();
                MysteryBoxes.Load(resourcePath + "/data/mysteryBoxes.xml");

                Packages = new Packages();
                Packages.Load(resourcePath + "/data/packages.xml");

                languages(resourcePath + "/data/languages");
				webFiles(resourcePath + "/web");

                RoleRanks = Ranks.ReadFile(resourcePath + "/data/roles.json");
            }
            else
                Worlds = new WorldData(resourcePath + "/worlds", GameData);
        }
		
		private void webFiles(string dir)
        {
            Log.Info("Loading web data...");

            Dictionary<string, byte[]> webFiles;

            WebFiles =
                new ReadOnlyDictionary<string, byte[]>(
                    webFiles = new Dictionary<string, byte[]>());

            var files = Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories);
            foreach (var file in files)
            {
                var webPath = file.Substring(dir.Length, file.Length - dir.Length)
                    .Replace("\\", "/");

                webFiles[webPath] = File.ReadAllBytes(file);
            }
        }

        private void languages(string dir)
        {
            Log.Info("Loading: 'Languages'");

            Dictionary<string, byte[]> languages;

            Languages =
                new ReadOnlyDictionary<string, byte[]>(
                    languages = new Dictionary<string, byte[]>());

            var basePath = Path.Combine(Utils.GetAssemblyDirectory(), dir);
            foreach (string lang in new String[] { "en" })
            {
                var zipBytes = Utils.Deflate(
                    File.ReadAllBytes(Path.Combine(basePath, lang + ".txt")));

                languages.Add(lang, zipBytes);
            }
        }

        public void Dispose()
        {
            GameData.Dispose();
        }
    }
}
