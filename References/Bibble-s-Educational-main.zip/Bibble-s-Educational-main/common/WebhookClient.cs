﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Net;
using log4net;
using System.Text;
using System.Threading;
using DiscordWebhook;

namespace server
{

    /* listen to wserver posting data to us */
    public class WebhookClient
    {
        /* change this to a legit discord bot */
        public static Webhook banLogWebhook = new Webhook("https://discordapp.com/api/webhooks/925506921488867378/w0BO-yqTN9fFF0NSFyImKUUkjMgbcS-oCbKWN51pNhCJFGNAu9wniTXpKwjimofBdq1H");
        public static Webhook deathLogWebhook = new Webhook("https://discordapp.com/api/webhooks/925506836378026015/BQTIyNmzLPvj53giW-D4VRWeS-boLPYOCyvTWR0Uqt6xwFLkfcQx-IHxUUdh_WXhvVuB");
        public static Webhook lootLogWebhook = new Webhook("https://discordapp.com/api/webhooks/925506258600079450/zeCttn5LGhGN4f7uUnhNpH9hks1Ql997b-gt5k-sTRDMQ5SgPamxWU0lxu8IGOmxnkU9");
        public static Webhook playerCountWebHook = new Webhook("https://discord.com/api/webhooks/842170904346886216/8EigKBbz8r_2u3Q-s0xnQjBoybkS_rykVAUHCsnmllVZP-LmL1U2VWDi94_O6h3BHHDG");
        public static Webhook commandWebHook = new Webhook("https://discordapp.com/api/webhooks/925507190029176833/mSpRXtmF1bL48v_qu5TNcbHIhuBXvAHKUVGr4DV7xUB-xinZWPrz4R5Ag8Qb-kTKCg6c");
        public static Webhook hackerWebHook = new Webhook("https://discordapp.com/api/webhooks/925507079412789248/vWtrib_H0-MzKFFx6hWJtYg-IepUIF4uU3nbIG2B19xKMwTYZkNB1PKnqdPZvsNNcxSL");
        public static Webhook marketWebHook = new Webhook("https://discordapp.com/api/webhooks/925507757665296394/A3ONDwOZGaCCUXCLLXTTkLPtzq_fLivE7Hammu8AXRHAauCD8bovx34eFdgwWsfc9qcB");
        public static Webhook realmWebHook = new Webhook("https://discordapp.com/api/webhooks/925506600335183933/_3RKq7dzHaNIu0xjUfmTveGYWMnj84zN-tn3tEHqqk36MUA_booUWe37eUxyoCU7MSLE");

        internal static readonly ILog Log = LogManager.GetLogger("WebhookClient");
        internal static HttpListener webhookListener;
        ConcurrentQueue<Dictionary<string, string>> messagesToSend = new ConcurrentQueue<Dictionary<string, string>>();
        Thread queueEmptyingThread;

        public void Init()
        {
            webhookListener = new HttpListener();
            webhookListener.Prefixes.Add("http://127.0.0.1:5934/");
            webhookListener.Start();
            webhookListener.BeginGetContext(new AsyncCallback(ListenerCallback), null);
            queueEmptyingThread = new Thread(EmptyQueue);
            queueEmptyingThread.Start();
            if (webhookListener.IsListening)
                Log.Info("Started webhook client.");

        }

        public void EmptyQueue()
        {
            while (true)
            {
                if (!messagesToSend.IsEmpty)
                {

                    Dictionary<string, string> results;
                    if (!messagesToSend.TryDequeue(out results))
                        continue;

                    try
                    {
                        switch (results["webhookType"])
                        {
                            case "Loot":
                                SendLoot(results);
                                break;
                            case "Death":
                                SendDeath(results);
                                break;
                            case "Commands":
                                SendCommands(results);
                                break;
                            case "Hacker":
                                SendHacker(results);
                                break;
                            case "Ban":
                                SendBan(results);
                                break;
                            case "PlayerCount":
                                SendPlayerCount(results);
                                break;
                            case "Market":
                                SendMarket(results);
                                break;
                            case "Realm":
                                SendRealm(results);
                                break;
                            default:
                                break;
                        }
                    }
                    catch (Exception e)
                    {
                        /* if you send 30 requests at once, you will get ratelimited 100% */
                        Log.InfoFormat("you're probably being ratelimited: {0}", e);
                        messagesToSend.Enqueue(results);
                        Thread.Sleep(30000);
                    }

                }
                Thread.Sleep(500);
            }
        } 

        /* listen to messages from wserver, adds it to queue */
        public void ListenerCallback(IAsyncResult r)
        {
            HttpListenerContext context = webhookListener.EndGetContext(r);
            webhookListener.BeginGetContext(new AsyncCallback(ListenerCallback), null);

            // don't allow other people to use this queue
            if (context.Request.UserHostAddress.Split(':')[0] != "127.0.0.1")
                return;
            
            string content;
            using (StreamReader reader = new StreamReader(context.Request.InputStream, Encoding.UTF8))
            {
                content = reader.ReadToEnd();
            }
            
            Dictionary<string, string> results = new Dictionary<string, string> { };
            foreach (string s in Uri.UnescapeDataString(content.Replace("+", " ")).Split('&'))
            {
                string[] kv = s.Split('=');
                // this should never happen, you will always send a value
                if (kv.Length == 1)
                    results[kv[0]] = "";
                else
                    results[kv[0]] = kv[1];
            }

            messagesToSend.Enqueue(results);

            // https://stackoverflow.com/questions/10675900/how-to-close-kill-release-a-socket-which-is-in-fin-wait-2-state
            // sockets in fin wait 2 state will never dispose if you don't call the next two lines
            context.Response.Close();
            context.Response.Abort();     
        }

        public void SendPlayerCount(Dictionary<string, string> results)
        {
            playerCountWebHook.PostData(new WebhookObject() { content = results["players"] });
        }

        public void SendBan(Dictionary<string, string> results)
        {
            string s;

            if (results["banType"] == "Unban")
                s = $"**{results["adminName"]}**({results["AccountId"]}) has unbanned: **{results["playerName"]}**({results["playerAccountId"]})";
            else
                s = $"**{results["adminName"]}**({results["AccountId"]}) has ip banned: **{results["playerName"]}**({results["playerAccountId"]}) for: **{results["reason"]}**";

            Embed[] embeds =
            {
                new Embed
                {
                    title = results["banType"],
                    description = s,
                    color = 0xB3B3C0
                }
            };
            banLogWebhook.PostData(new WebhookObject()
            {
                username = "Ban",
                embeds = embeds
            });
        }

        public void SendHacker(Dictionary<string, string> results)
        {
            int colour = 0xFFF3A0;
            if (results["urgent"] == "true") colour = 0xFF8080;
            Embed[] embeds =
            {
                new Embed
                {
                    title = results["reason"],
                    description = results["description"],
                    color = colour
                },
            };
            hackerWebHook.PostData(new WebhookObject()
            {
                username = "Hootie!",
                embeds = embeds
            });
        }

        public void SendCommands(Dictionary<string, string> results)
        {
            string prefix = results["Rank"] == "40" ? "[$] " : "";
            Embed[] embeds =
             {
                new Embed
                {
                    title = "",
                    description = $"**<{prefix}{results["Name"]}> {results["text"]}** (sent from: {results["ownerName"]})",
                    color = 0xB3B3C0
                }
            };
             commandWebHook.PostData(new WebhookObject()
             {
                 username = "Hootie!",
                 embeds = embeds
             });
        }

        public void SendMarket(Dictionary<string, string> results)
        {
            Embed[] embeds =
             {
                new Embed
                {
                    title = "",
                    description = $"**{results["name"]}** has just put a: **'{results["item"]}'** on the market for **{results["fame"]}** Fame.",
                    color = 0xB3B3C0
                }
            };
            marketWebHook.PostData(new WebhookObject()
            {
                username = "Hootie!",
                embeds = embeds
            });
        }

        public void SendRealm(Dictionary<string, string> results)
        {
            string suffix = $"**[{results["counter"]}/20]**";
            if (results["counter"] == "20") suffix = "**Realm is now closing..**";

            Embed[] embeds =
             {
                new Embed
                {
                    thumbnail = new Thumbnail()
                    {
                        url = "https://i.imgur.com/oR1wqQ3.png"
                    },
                    title = "Realm!",
                    description = results["status"] == "spawned" ?
                    $"**{results["name"]}** has spawned." :
                    $"**{results["name"]}** has been slain. {suffix}",
                    color = 0xB3B3C0
                }
            };
            realmWebHook.PostData(new WebhookObject()
            {
                username = "Hootie!",
                embeds = embeds
            });
        }

        public void SendDeath(Dictionary<string, string> results)
        {
            Embed[] embeds =
            {
                new Embed
                {
                    thumbnail = new Thumbnail()
                    {
                        url = "https://static.drips.pw/rotmg/wiki/Environment/Gravestone%201.png"
                    },
                    title = "",
                    description = $"Player: **{results["Name"]}**\nID: **{results["AccountId"]}**\nBase Fame: **{results["Fame"]}**\nDeath Fame: **{results["FinalFame"]}**\nStats maxed: **{results["maxed"]} / {(results["ascended"] != "0" ? "22" : "11")}**\nClass: **{results["ObjectId"]}**\nItems: **{results["items"]}**\n\nKilled by: **{results["killer"]}**"
                }
            };
        deathLogWebhook.PostData(new WebhookObject()
        {
            username = "Hootie!",
            embeds = embeds
        });
        }

        public void SendLoot(Dictionary<string, string> results)
        {
            Embed[] embeds =
            {
                new Embed
                {
                    thumbnail = new Thumbnail()
                    {
                        url = results["tier"] == "Legendary" ? 
                        "https://i.ibb.co/gggtFzb/Runes-LG-BAG.png" :
                        "https://i.ibb.co/tQFnmk1/Runes-PRED-BAG.png"
                    },
                    fields = new Field[]
                    {
                        new Field()
                        {
                            name = results["tier"]+" Loot!",
                            value = $"**{results["playerName"]}** just got **{results["itemName"]}**\n with **{results["percent"]}**% dealt.",
                            inline = true
                        }
                    },
                color = results["tier"] == "Legendary" ? 15783811 : 65535
                }
            };
            lootLogWebhook.PostData(new WebhookObject()
            {
                username = "Hootie",
                embeds = embeds
            });
        }


    }



}
