﻿using System;
using System.Collections.Specialized;
using Anna.Request;
using common;
using log4net;
using SendGrid.Helpers.Mail;

namespace server.account
{
    class forgotPassword : RequestHandler
    {
        private static readonly ILog PassLog = LogManager.GetLogger("PassLog");

        public override void HandleRequest(RequestContext context, NameValueCollection query)
        {
            Write(context, "<Success />");
        }
    }
}
