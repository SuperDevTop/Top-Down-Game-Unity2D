﻿using System;
using System.Threading;
using System.IO;
using System.Collections.Generic;
using Anna;
using log4net;
using log4net.Config;
using System.Globalization;
using System.Linq;
using System.Reactive.Linq;
using System.Web;
using Anna.Request;
using common;
using common.resources;

namespace server
{

    public class TokenBucket
    {
        public double maximumBucketSize;
        public double currentBucketSize;
        /* refill x tokens per second */
        public double refillRate;
        public int lastRefillTime;

        public TokenBucket(double r)
        {
            /* only allow 15 requests */
            maximumBucketSize = 15;
            refillRate = r;
            currentBucketSize = maximumBucketSize;
            /* keep in mind time is in seconds. */
            lastRefillTime = DateTime.Now.ToUnixTimestamp();
        }

        public Boolean processRequest(int tokens)
        {
            refill();
            /* allow tokenbucket to go extremely negative if people are straight ddosing. punish them */
            currentBucketSize -= tokens;
            if (currentBucketSize > tokens)
            {
                return true;
            }
            return false;
        }

        private void refill()
        {
            int now = DateTime.Now.ToUnixTimestamp();
            double tokensToAdd = (now - lastRefillTime) * refillRate;
            currentBucketSize = Math.Min(currentBucketSize + tokensToAdd, maximumBucketSize);
            lastRefillTime = now;
        }
    }

    class Program
    {
        internal static readonly ILog Log = LogManager.GetLogger("Server");
        private static readonly ILog limiterLog = LogManager.GetLogger("RateLimiter");
        internal static readonly ManualResetEvent Shutdown = new ManualResetEvent(false);
        internal static ServerConfig Config;
        internal static Resources Resources;
        internal static Database Database;
        internal static ISManager ISManager;
        internal static ChatManager ChatManager;
        internal static ISControl ISControl;
        internal static LegendSweeper LegendSweeper;

        internal static string[] headers = { "User-Agent", "Host" };
        internal static Dictionary<string, double> rateLimitRefillRates = new Dictionary<string, double>
        {
            {"/account/register", 0.0001},
            {"/account/changePassword", 0.0001},
            {"/account/forgotPassword", 0.0001},
            {"/account/purchaseCharSlot", 0.001},
            {"/account/rank", 0.001},
            {"/account/registerDiscord", 0.001},
            {"/account/setName", 0.00001},
            {"/account/unregisterDiscord", 0.001},
            {"/account/verify", 0.01},
            {"/account/verifyage", 0.0001},
            {"/char/delete", 0.001},
            {"/char/list", 0.1},
            {"/char/purchaseClassUnlock", 0.0001}
        };
        internal static Dictionary<string, Dictionary<string, TokenBucket>> rateLimiters = new Dictionary<string, Dictionary<string, TokenBucket>> { };
        public static WebhookClient client;


        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += LogUnhandledException;

            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Thread.CurrentThread.Name = "Entry";

            /* initialize tokenbuckets for each vulnerable endpoint */
            foreach (var i in rateLimitRefillRates)
            {
                rateLimiters[i.Key] = new Dictionary<string, TokenBucket> { };
            }

            /* initialize webhookclient */
            client = new WebhookClient();
            client.Init();


            Config = args.Length > 0 ?
                ServerConfig.ReadFile(args[0]) :
                ServerConfig.ReadFile("server.json");

            Environment.SetEnvironmentVariable("ServerLogFolder", Config.serverSettings.logFolder);
            GlobalContext.Properties["ServerName"] = Config.serverInfo.name;
            GlobalContext.Properties["ServerType"] = Config.serverInfo.type.ToString();

            XmlConfigurator.ConfigureAndWatch(new FileInfo(Config.serverSettings.log4netConfig));

            using (Resources = new Resources("../common/resources/"))
            using (Database = new Database(
                    Config.dbInfo.host,
                    Config.dbInfo.port,
                    Config.dbInfo.auth,
                    Config.dbInfo.index,
                    Resources))
            {
                RequestHandlers.Initialize(Resources);

                Config.serverInfo.instanceId = Guid.NewGuid().ToString();
                ISManager = new ISManager(Database, Config);
                ISManager.Run();
                ChatManager = new ChatManager(ISManager);
                ISControl = new ISControl(ISManager);
                LegendSweeper = new LegendSweeper(Database);
                LegendSweeper.Run();

                Console.CancelKeyPress += delegate
                {
                    Shutdown.Set();
                };

                var port = Config.serverInfo.port;
                using (var server = new HttpServer($"http://{Config.serverInfo.bindAddress}:{port}/"))
                {
                    foreach (var uri in RequestHandlers.Get.Keys)
                        server.GET(uri).Subscribe(Response);

                    foreach (var uri in RequestHandlers.Post.Keys)
                        server.POST(uri).Subscribe(Response);

                    Log.Info("Listening at port " + port + "...");
                    Shutdown.WaitOne();
                }

                Log.Info("Terminating...");
                ISManager.Dispose();
            }
        }

        public static void Stop()
        {
            Shutdown.Set();
        }

        private static void Response(RequestContext rContext)
        {
            try
            {
                /*Log.InfoFormat("Dispatching '{0}'@{1}",
                    rContext.Request.Url.LocalPath,
                    rContext.Request.ClientIP());*/

                if (rContext.Request.HttpMethod.Equals("GET"))
                {
                    var query = HttpUtility.ParseQueryString(rContext.Request.Url.Query);
                    RequestHandlers.Get[rContext.Request.Url.LocalPath].HandleRequest(rContext, query);
                    return;
                }

                /* first line of defense: rate limiting */

                foreach (var i in rateLimiters)
                {
                    if (i.Key == rContext.Request.Url.LocalPath)
                    {
                        /* new ip making a request to a specific endpoint */
                        if (!rateLimiters[i.Key].ContainsKey(rContext.Request.ClientIP()))
                        {
                            rateLimiters[i.Key][rContext.Request.ClientIP()] = new TokenBucket(rateLimitRefillRates[i.Key]);
                        }

                        /* check if needs to be rate limited */
                        Boolean result = rateLimiters[i.Key][rContext.Request.ClientIP()].processRequest(1);
                        if (!result)
                        {
                            rContext.Respond("<Error>Bad Login</Error>", 200);
                            limiterLog.InfoFormat("IP {0} was ratelimited with {1} tokens.", rContext.Request.ClientIP(), rateLimiters[i.Key][rContext.Request.ClientIP()].currentBucketSize);
                            return;
                        }
                    }
                }
                /* second line of defense: header validation */
                bool allow = true;
                foreach (var header in headers)
                {
                    if (!rContext.Request.Headers.ContainsKey(header))
                    {
                        limiterLog.InfoFormat("header {0} was missing", header);
                        allow = false;
                    }
                }

                if (!allow)
                {
                    rContext.Respond("<Error>Bad Login</Error>", 200);
                    limiterLog.InfoFormat("IP {0} sent a malformed header.", rContext.Request.ClientIP());
                    return;
                }

                /*  <appender name="ConsoleAppender" type="log4net.Appender.ConsoleAppender">
                        <layout type="log4net.Layout.PatternLayout">
                          <conversionPattern value="%d{HH:mm:ss,fff} %-5level %-15.15logger{1} %m%n" />
                        </layout>
                      </appender> */

                GetBody(rContext.Request, 4096).Subscribe(body =>
                {
                    try
                    {

                        /* last line of defense: request field validation
                         * mf really using a prod config */
                        var query = HttpUtility.ParseQueryString(body);
                        string value = query["clientToken"];
                        string ignore = query["ignore"];
                        if (value != null || ignore == null)
                        {
                            rContext.Respond("<Error>Bad Login</Error>", 200);
                            limiterLog.InfoFormat("IP {0} sent malformed request fields.", rContext.Request.ClientIP());
                            return;
                        }
                        RequestHandlers.Post[rContext.Request.Url.LocalPath]
                            .HandleRequest(rContext, query);
                    }
                    catch (Exception e)
                    {
                        OnError(e, rContext);
                    }
                });
            }
            catch (Exception e)
            {
                OnError(e, rContext);
            }
        }

        private static void OnError(Exception e, RequestContext rContext)
        {
            Log.Error($"{e.Message}\r\n{e.StackTrace}");

            try
            {
                rContext.Respond("<Error>Internal server error</Error>", 500);
            }
            catch
            {
            }
        }

        private static IObservable<string> GetBody(Request r, int maxContentLength = 50000)
        {
            int bufferSize = maxContentLength;
            if (r.Headers.ContainsKey("Content-Length"))
                bufferSize = Math.Min(maxContentLength, int.Parse(r.Headers["Content-Length"].First()));

            var buffer = new byte[bufferSize];
            return Observable.FromAsyncPattern<byte[], int, int, int>(r.InputStream.BeginRead, r.InputStream.EndRead)(buffer, 0, bufferSize)
                .Select(bytesRead => r.ContentEncoding.GetString(buffer, 0, bytesRead));
        }

        private static void LogUnhandledException(object sender, UnhandledExceptionEventArgs args)
        {
            Log.Fatal((Exception)args.ExceptionObject);
        }
    }
}
