﻿using common.resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using terrain;
using TiledCS;

namespace MapConverter
{
    class Program
    {

        static Dictionary<int, ushort> BuildDictionaryFromTiles(TiledMapTileset mset, TiledTileset tset)
        {
            Dictionary<int, ushort> _dic = new Dictionary<int, ushort>();
            foreach(var tile in tset.Tiles)
            {
                if(!_dic.ContainsKey(tile.id + mset.firstgid))
                    _dic.Add(tile.id + mset.firstgid, (ushort)tile.id);
            }
            return _dic;
        }

        static void Main(string[] args)
        {
            var GameData = new XmlData("../../../common/resources/xmls");

            Console.WriteLine("input map name (with .tmx)");
            string userinput = Console.ReadLine();
            TiledMap map = new TiledMap($"tiled/{userinput}");

            var floorLayer = map.Layers.First(l => l.name == "Ground");
            var floorTileSet = map.Tilesets.First(a => a.source.Equals("Ground.tsx"));

            var wallLayer = map.Layers.First(l => l.name == "Object");
            var wallTileSet = map.Tilesets.First(a => a.source.Equals("Wall.tsx"));

            var charaTileSet = map.Tilesets.First(a => a.source.Equals("Character.tsx"));

            TiledTileset tsetFloor = new TiledTileset("tiled/Ground.tsx");
            TiledTileset tsetWall = new TiledTileset("tiled/Wall.tsx");
            TiledTileset tsetCharacter = new TiledTileset("tiled/Character.tsx");

            var floorD = BuildDictionaryFromTiles(floorTileSet, tsetFloor);
            var wallD = BuildDictionaryFromTiles(wallTileSet, tsetWall);
            var charaD = BuildDictionaryFromTiles(charaTileSet, tsetCharacter);

            var allObjectDicts = new List<Dictionary<int, ushort>>();
            allObjectDicts.Add(charaD);
            allObjectDicts.Add(wallD);

            var objectD = allObjectDicts.SelectMany(dict => dict)
                         .ToDictionary(pair => pair.Key, pair => pair.Value);

            TerrainTile[,] tileMap = new TerrainTile[map.Width, map.Height];
            for(int i = 0; i < map.Width; i++)
            {
                for(int j = 0; j < map.Height; j++)
                {
                    int gid = floorLayer.data[j + i * map.Width];
                    int gidWall = wallLayer.data[j + i * map.Width];

                    var obj = gidWall == 0 ? null : GameData.ObjectDescs[objectD[gidWall]];

                    tileMap[i, j] = new TerrainTile()
                    {
                        TileId = floorD[gid],
                        TileObj = obj == null ? null : obj.ObjectId,
                        Name = obj == null ? null : obj.DisplayId
                    };
                }
            }

            Console.WriteLine("Press A for wmap and B for jw");

            string input = Console.ReadLine();
            
            if(input.Equals("A"))
            {
                WorldMapExporter.Export(tileMap, "output.wmap");
            } else
            {
                File.WriteAllText("output.jw", JsonMapExporter.Export(GameData, tileMap));
            }
        }
    }
}
