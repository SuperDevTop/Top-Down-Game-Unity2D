<tileset columns="0" name="reference" tilecount="0" tiledversion="1.4.3" tileheight="8" tilewidth="8" version="1.4">
 <grid height="1" orientation="orthogonal" width="1" />
</tileset>