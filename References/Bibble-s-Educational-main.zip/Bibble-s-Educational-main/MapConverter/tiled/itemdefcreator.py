import xml.etree.ElementTree as ET
import glob, os
import cv2

chance = input("Input item chance")
tagToSort = input("Enter tag to include items")
fileTextToWrite = ""

for file in glob.glob("*.xml"):
    #print(file)
    root = ET.parse(file).getroot()
    for objectXML in root:
        classObj = objectXML.find('Class')
        if classObj == None: 
            continue
        if classObj != None and classObj.text == "Equipment":
            if True:
                localFile = None
                index = 0
                if not 'type' in objectXML.attrib or not 'id' in objectXML.attrib: continue
                stringId = objectXML.attrib['id']
                byteId = objectXML.attrib['type']
                
                if objectXML.find(tagToSort) != None:
                    fileTextToWrite += "new ItemLoot(\"{}\", {}),\n".format(stringId, chance)
                    pass
    
with open("output.txt", "w") as f:
    f.write(fileTextToWrite)
