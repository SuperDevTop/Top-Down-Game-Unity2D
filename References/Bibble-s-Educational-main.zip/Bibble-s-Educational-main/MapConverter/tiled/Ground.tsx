<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Ground" tilewidth="8" tileheight="8" tilecount="242" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="4">
  <properties>
   <property name="Id" value="Grey Open"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x04_Grey Open.png"/>
 </tile>
 <tile id="5">
  <properties>
   <property name="Id" value="Grey Closed"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x05_Grey Closed.png"/>
 </tile>
 <tile id="6">
  <properties>
   <property name="Id" value="Grey Quad"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x06_Grey Quad.png"/>
 </tile>
 <tile id="19">
  <properties>
   <property name="Id" value="Grey Pathway Shadow"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x13_Grey Pathway Shadow.png"/>
 </tile>
 <tile id="20">
  <properties>
   <property name="Id" value="Brown Open"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x14_Brown Open.png"/>
 </tile>
 <tile id="21">
  <properties>
   <property name="Id" value="Brown Closed"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x15_Brown Closed.png"/>
 </tile>
 <tile id="22">
  <properties>
   <property name="Id" value="Brown Quad"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x16_Brown Quad.png"/>
 </tile>
 <tile id="27">
  <properties>
   <property name="Id" value="Wood Plank Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1b_Wood Plank Floor.png"/>
 </tile>
 <tile id="30">
  <properties>
   <property name="Id" value="Brown Closed Broken 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1e_Brown Closed Broken 1.png"/>
 </tile>
 <tile id="31">
  <properties>
   <property name="Id" value="Brown Closed Broken 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1f_Brown Closed Broken 2.png"/>
 </tile>
 <tile id="36">
  <properties>
   <property name="Id" value="Blue Open"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x24_Blue Open.png"/>
 </tile>
 <tile id="37">
  <properties>
   <property name="Id" value="Blue Closed"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x25_Blue Closed.png"/>
 </tile>
 <tile id="38">
  <properties>
   <property name="Id" value="Blue Quad"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x26_Blue Quad.png"/>
 </tile>
 <tile id="46">
  <properties>
   <property name="Id" value="OceanFloor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x2e_OceanFloor.png"/>
 </tile>
 <tile id="48">
  <properties>
   <property name="Id" value="Spider Dirt Hole"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x30_Spider Dirt Hole.png"/>
 </tile>
 <tile id="51">
  <properties>
   <property name="Id" value="Purple Stone Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x33_Purple Stone Dark.png"/>
 </tile>
 <tile id="52">
  <properties>
   <property name="Id" value="Red Open"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x34_Red Open.png"/>
 </tile>
 <tile id="53">
  <properties>
   <property name="Id" value="Red Closed"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x35_Red Closed.png"/>
 </tile>
 <tile id="54">
  <properties>
   <property name="Id" value="Red Quad"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x36_Red Quad.png"/>
 </tile>
 <tile id="58">
  <properties>
   <property name="Id" value="White Floor 1 Fast Walk"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x3a_White Floor 1 Fast Walk.png"/>
 </tile>
 <tile id="59">
  <properties>
   <property name="Id" value="Cemetery Grass Yellow"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x3b_Cemetery Grass Yellow.png"/>
 </tile>
 <tile id="61">
  <properties>
   <property name="Id" value="Cemetery Stone Path No Walk"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x3d_Cemetery Stone Path No Walk.png"/>
 </tile>
 <tile id="62">
  <properties>
   <property name="Id" value="Zombie Grass"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x3e_Zombie Grass.png"/>
 </tile>
 <tile id="63">
  <properties>
   <property name="Id" value="Zombie Dirt"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x3f_Zombie Dirt.png"/>
 </tile>
 <tile id="64">
  <properties>
   <property name="Id" value="Purple Lines"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x40_Purple Lines.png"/>
 </tile>
 <tile id="65">
  <properties>
   <property name="Id" value="Blue BigSmall Squares"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x41_Blue BigSmall Squares.png"/>
 </tile>
 <tile id="66">
  <properties>
   <property name="Id" value="Green Lines"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x42_Green Lines.png"/>
 </tile>
 <tile id="67">
  <properties>
   <property name="Id" value="Green BigSmall Squares"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x43_Green BigSmall Squares.png"/>
 </tile>
 <tile id="75">
  <properties>
   <property name="Id" value="Cemetery Grass Flowers"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x4b_Cemetery Grass Flowers.png"/>
 </tile>
 <tile id="80">
  <properties>
   <property name="Id" value="Grey Quad2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x50_Grey Quad2.png"/>
 </tile>
 <tile id="81">
  <properties>
   <property name="Id" value="Grey Squares"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x51_Grey Squares.png"/>
 </tile>
 <tile id="82">
  <properties>
   <property name="Id" value="Brown Quad2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x52_Brown Quad2.png"/>
 </tile>
 <tile id="83">
  <properties>
   <property name="Id" value="Brown Squares"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x53_Brown Squares.png"/>
 </tile>
 <tile id="84">
  <properties>
   <property name="Id" value="Purple Quad2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x54_Purple Quad2.png"/>
 </tile>
 <tile id="85">
  <properties>
   <property name="Id" value="Purple Squares"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x55_Purple Squares.png"/>
 </tile>
 <tile id="97">
  <properties>
   <property name="Id" value="Grey Circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x61_Grey Circle.png"/>
 </tile>
 <tile id="98">
  <properties>
   <property name="Id" value="Undergrowth"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x62_Undergrowth.png"/>
 </tile>
 <tile id="99">
  <properties>
   <property name="Id" value="Green Circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x63_Green Circle.png"/>
 </tile>
 <tile id="100">
  <properties>
   <property name="Id" value="Scorch"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x64_Scorch.png"/>
 </tile>
 <tile id="102">
  <properties>
   <property name="Id" value="Checker Board"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x66_Checker Board.png"/>
 </tile>
 <tile id="103">
  <properties>
   <property name="Id" value="Grey Checker Board"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x67_Grey Checker Board.png"/>
 </tile>
 <tile id="105">
  <properties>
   <property name="Id" value="Red Checker Board"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x69_Red Checker Board.png"/>
 </tile>
 <tile id="107">
  <properties>
   <property name="Id" value="Ice"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x6b_Ice.png"/>
 </tile>
 <tile id="110">
  <properties>
   <property name="Id" value="Cemetery Stone Path"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x6e_Cemetery Stone Path.png"/>
 </tile>
 <tile id="112">
  <properties>
   <property name="Id" value="Lava"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x70_Lava.png"/>
 </tile>
 <tile id="114">
  <properties>
   <property name="Id" value="Water"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x72_Water.png"/>
 </tile>
 <tile id="115">
  <properties>
   <property name="Id" value="Shallow Water"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x73_Shallow Water.png"/>
 </tile>
 <tile id="116">
  <properties>
   <property name="Id" value="White Floor 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x74_White Floor 1.png"/>
 </tile>
 <tile id="117">
  <properties>
   <property name="Id" value="White Floor 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x75_White Floor 2.png"/>
 </tile>
 <tile id="118">
  <properties>
   <property name="Id" value="White Floor 3"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x76_White Floor 3.png"/>
 </tile>
 <tile id="119">
  <properties>
   <property name="Id" value="White Floor 4"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x77_White Floor 4.png"/>
 </tile>
 <tile id="120">
  <properties>
   <property name="Id" value="White Floor 5"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x78_White Floor 5.png"/>
 </tile>
 <tile id="121">
  <properties>
   <property name="Id" value="Grey Pathway"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x79_Grey Pathway.png"/>
 </tile>
 <tile id="122">
  <properties>
   <property name="Id" value="Pool"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x7a_Pool.png"/>
 </tile>
 <tile id="123">
  <properties>
   <property name="Id" value="Deep Pool"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x7b_Deep Pool.png"/>
 </tile>
 <tile id="128">
  <properties>
   <property name="Id" value="Snow Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x80_Snow Dark.png"/>
 </tile>
 <tile id="129">
  <properties>
   <property name="Id" value="Snow White"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x81_Snow White.png"/>
 </tile>
 <tile id="130">
  <properties>
   <property name="Id" value="Lab Bad Vat No Slow"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x82_Lab Bad Vat No Slow.png"/>
 </tile>
 <tile id="133">
  <properties>
   <property name="Id" value="Lab Floor Power"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x85_Lab Floor Power.png"/>
 </tile>
 <tile id="135">
  <properties>
   <property name="Id" value="GhostWater Slows"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x87_GhostWater Slows.png"/>
 </tile>
 <tile id="139">
  <properties>
   <property name="Id" value="Ice no Blend"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x8b_Ice no Blend.png"/>
 </tile>
 <tile id="140">
  <properties>
   <property name="Id" value="Ice no Walk"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x8c_Ice no Walk.png"/>
 </tile>
 <tile id="145">
  <properties>
   <property name="Id" value="Trap Flame Hole"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x91_Trap Flame Hole.png"/>
 </tile>
 <tile id="146">
  <properties>
   <property name="Id" value="Tunnel Hole M"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x92_Tunnel Hole M.png"/>
 </tile>
 <tile id="147">
  <properties>
   <property name="Id" value="Tunnel Ground M"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x93_Tunnel Ground M.png"/>
 </tile>
 <tile id="148">
  <properties>
   <property name="Id" value="Track End"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x94_Track End.png"/>
 </tile>
 <tile id="149">
  <properties>
   <property name="Id" value="Retro Water"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x95_Retro Water.png"/>
 </tile>
 <tile id="150">
  <properties>
   <property name="Id" value="Retro Dirt"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x96_Retro Dirt.png"/>
 </tile>
 <tile id="160">
  <properties>
   <property name="Id" value="White Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa0_White Alpha Square.png"/>
 </tile>
 <tile id="161">
  <properties>
   <property name="Id" value="Purple Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa1_Purple Alpha Square.png"/>
 </tile>
 <tile id="162">
  <properties>
   <property name="Id" value="Red Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa2_Red Alpha Square.png"/>
 </tile>
 <tile id="163">
  <properties>
   <property name="Id" value="Blue Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa3_Blue Alpha Square.png"/>
 </tile>
 <tile id="164">
  <properties>
   <property name="Id" value="Green Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa4_Green Alpha Square.png"/>
 </tile>
 <tile id="165">
  <properties>
   <property name="Id" value="Yellow Alpha Square"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa5_Yellow Alpha Square.png"/>
 </tile>
 <tile id="168">
  <properties>
   <property name="Id" value="Liquid Evil"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa8_Liquid Evil.png"/>
 </tile>
 <tile id="169">
  <properties>
   <property name="Id" value="Lab Bad Vat Rug"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xa9_Lab Bad Vat Rug.png"/>
 </tile>
 <tile id="170">
  <properties>
   <property name="Id" value="Lab Floor Power Nowalk"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaa_Lab Floor Power Nowalk.png"/>
 </tile>
 <tile id="171">
  <properties>
   <property name="Id" value="Track W End"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab_Track W End.png"/>
 </tile>
 <tile id="172">
  <properties>
   <property name="Id" value="Track N End"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xac_Track N End.png"/>
 </tile>
 <tile id="181">
  <properties>
   <property name="Id" value="Beach Towel 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb5_Beach Towel 2.png"/>
 </tile>
 <tile id="182">
  <properties>
   <property name="Id" value="Bridge Light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb6_Bridge Light.png"/>
 </tile>
 <tile id="183">
  <properties>
   <property name="Id" value="Lab Floor NO WALK"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb7_Lab Floor NO WALK.png"/>
 </tile>
 <tile id="184">
  <properties>
   <property name="Id" value="Ice Slide"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb8_Ice Slide.png"/>
 </tile>
 <tile id="185">
  <properties>
   <property name="Id" value="Snow"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb9_Snow.png"/>
 </tile>
 <tile id="197">
  <properties>
   <property name="Id" value="Jungle Temple Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xc5_Jungle Temple Floor.png"/>
 </tile>
 <tile id="198">
  <properties>
   <property name="Id" value="Jungle Temple Floor 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xc6_Jungle Temple Floor 2.png"/>
 </tile>
 <tile id="199">
  <properties>
   <property name="Id" value="Stone Slab Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xc7_Stone Slab Floor.png"/>
 </tile>
 <tile id="200">
  <properties>
   <property name="Id" value="Grey Quad Shadows"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xc8_Grey Quad Shadows.png"/>
 </tile>
 <tile id="202">
  <properties>
   <property name="Id" value="Tutorial Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xca_Tutorial Floor.png"/>
 </tile>
 <tile id="208">
  <properties>
   <property name="Id" value="Road"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xd0_Road.png"/>
 </tile>
 <tile id="209">
  <properties>
   <property name="Id" value="Lab Broken Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xd1_Lab Broken Floor.png"/>
 </tile>
 <tile id="210">
  <properties>
   <property name="Id" value="Lab Grate Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xd2_Lab Grate Floor.png"/>
 </tile>
 <tile id="211">
  <properties>
   <property name="Id" value="Lab Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xd3_Lab Floor.png"/>
 </tile>
 <tile id="212">
  <properties>
   <property name="Id" value="Grey Bloody"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xd4_Grey Bloody.png"/>
 </tile>
 <tile id="224">
  <properties>
   <property name="Id" value="Sandstone Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe0_Sandstone Tile.png"/>
 </tile>
 <tile id="225">
  <properties>
   <property name="Id" value="Cracked Sandstone Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe1_Cracked Sandstone Tile.png"/>
 </tile>
 <tile id="226">
  <properties>
   <property name="Id" value="Sand Covered Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe2_Sand Covered Tile.png"/>
 </tile>
 <tile id="227">
  <properties>
   <property name="Id" value="Missing Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe3_Missing Tile.png"/>
 </tile>
 <tile id="228">
  <properties>
   <property name="Id" value="Gold Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe4_Gold Tile.png"/>
 </tile>
 <tile id="229">
  <properties>
   <property name="Id" value="Dream Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe5_Dream Tile.png"/>
 </tile>
 <tile id="233">
  <properties>
   <property name="Id" value="Light Moss"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xe9_Light Moss.png"/>
 </tile>
 <tile id="239">
  <properties>
   <property name="Id" value="Guild Rug Green"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xef_Guild Rug Green.png"/>
 </tile>
 <tile id="240">
  <properties>
   <property name="Id" value="Dirt Hole"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xf0_Dirt Hole.png"/>
 </tile>
 <tile id="242">
  <properties>
   <property name="Id" value="Scorch Blend"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xf2_Scorch Blend.png"/>
 </tile>
 <tile id="243">
  <properties>
   <property name="Id" value="Oryx Room"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xf3_Oryx Room.png"/>
 </tile>
 <tile id="244">
  <properties>
   <property name="Id" value="Lava Blend"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xf4_Lava Blend.png"/>
 </tile>
 <tile id="250">
  <properties>
   <property name="Id" value="GhostWater"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfa_GhostWater.png"/>
 </tile>
 <tile id="1418">
  <properties>
   <property name="Id" value="Encore EB TL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x58a_Encore EB TL.png"/>
 </tile>
 <tile id="1419">
  <properties>
   <property name="Id" value="Encore EB TR"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x58b_Encore EB TR.png"/>
 </tile>
 <tile id="1420">
  <properties>
   <property name="Id" value="Encore EB BR"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x58c_Encore EB BR.png"/>
 </tile>
 <tile id="1421">
  <properties>
   <property name="Id" value="Encore EB BL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x58d_Encore EB BL.png"/>
 </tile>
 <tile id="4048">
  <properties>
   <property name="Id" value="Sakura Petals Pile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x0fd0_Sakura Petals Pile.png"/>
 </tile>
 <tile id="4049">
  <properties>
   <property name="Id" value="Rock NoBP"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd1_Rock NoBP.png"/>
 </tile>
 <tile id="4051">
  <properties>
   <property name="Id" value="Onsen Water"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd3_Onsen Water.png"/>
 </tile>
 <tile id="4052">
  <properties>
   <property name="Id" value="Onsen Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd4_Onsen Floor.png"/>
 </tile>
 <tile id="4053">
  <properties>
   <property name="Id" value="Hanami Grass 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd5_Hanami Grass 1.png"/>
 </tile>
 <tile id="4054">
  <properties>
   <property name="Id" value="Hanami Grass 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd6_Hanami Grass 2.png"/>
 </tile>
 <tile id="4055">
  <properties>
   <property name="Id" value="Onsen Water Test"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd7_Onsen Water Test.png"/>
 </tile>
 <tile id="4056">
  <properties>
   <property name="Id" value="Hanami Grass 3"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd8_Hanami Grass 3.png"/>
 </tile>
 <tile id="4057">
  <properties>
   <property name="Id" value="Onsen Water Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfd9_Onsen Water Dark.png"/>
 </tile>
 <tile id="4058">
  <properties>
   <property name="Id" value="Onsen Water 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfda_Onsen Water 2.png"/>
 </tile>
 <tile id="4059">
  <properties>
   <property name="Id" value="Hanami Grass 1 Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfdb_Hanami Grass 1 Dark.png"/>
 </tile>
 <tile id="4060">
  <properties>
   <property name="Id" value="Hanami Grass 2 Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfdc_Hanami Grass 2 Dark.png"/>
 </tile>
 <tile id="4061">
  <properties>
   <property name="Id" value="Hanami Grass 3 Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfdd_Hanami Grass 3 Dark.png"/>
 </tile>
 <tile id="4062">
  <properties>
   <property name="Id" value="Hanami Grass 1 Light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfde_Hanami Grass 1 Light.png"/>
 </tile>
 <tile id="4063">
  <properties>
   <property name="Id" value="Hanami Grass 2 Light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfdf_Hanami Grass 2 Light.png"/>
 </tile>
 <tile id="4064">
  <properties>
   <property name="Id" value="Hanami Grass 3 Light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe0_Hanami Grass 3 Light.png"/>
 </tile>
 <tile id="4065">
  <properties>
   <property name="Id" value="Light Grass Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe1_Light Grass Dark.png"/>
 </tile>
 <tile id="4066">
  <properties>
   <property name="Id" value="New Grass Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe2_New Grass Dark.png"/>
 </tile>
 <tile id="4067">
  <properties>
   <property name="Id" value="Sakura Petals Pile Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe3_Sakura Petals Pile Dark.png"/>
 </tile>
 <tile id="4070">
  <properties>
   <property name="Id" value="Rock Steam Top 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe6_Rock Steam Top 1.png"/>
 </tile>
 <tile id="4071">
  <properties>
   <property name="Id" value="Rock Steam Top 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe7_Rock Steam Top 2.png"/>
 </tile>
 <tile id="4072">
  <properties>
   <property name="Id" value="Onsen Floor Steam Top 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe8_Onsen Floor Steam Top 1.png"/>
 </tile>
 <tile id="4073">
  <properties>
   <property name="Id" value="Onsen Floor Steam Top 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfe9_Onsen Floor Steam Top 2.png"/>
 </tile>
 <tile id="4074">
  <properties>
   <property name="Id" value="Onsen Water Steam Top 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfea_Onsen Water Steam Top 1.png"/>
 </tile>
 <tile id="4075">
  <properties>
   <property name="Id" value="Onsen Water Steam Top 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfeb_Onsen Water Steam Top 2.png"/>
 </tile>
 <tile id="4076">
  <properties>
   <property name="Id" value="Onsen Water 2 Steam Top 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfec_Onsen Water 2 Steam Top 1.png"/>
 </tile>
 <tile id="4077">
  <properties>
   <property name="Id" value="Onsen Water 2 Steam Top 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfed_Onsen Water 2 Steam Top 2.png"/>
 </tile>
 <tile id="4078">
  <properties>
   <property name="Id" value="Onsen Water Dark Steam Top 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfee_Onsen Water Dark Steam Top 1.png"/>
 </tile>
 <tile id="4079">
  <properties>
   <property name="Id" value="Onsen Water Dark Steam Top 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xfef_Onsen Water Dark Steam Top 2.png"/>
 </tile>
 <tile id="5744">
  <properties>
   <property name="Id" value="Patty Grass 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1670_Patty Grass 1.png"/>
 </tile>
 <tile id="5745">
  <properties>
   <property name="Id" value="Patty Grass 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1671_Patty Grass 2.png"/>
 </tile>
 <tile id="5746">
  <properties>
   <property name="Id" value="Patty Grass 3"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1672_Patty Grass 3.png"/>
 </tile>
 <tile id="5747">
  <properties>
   <property name="Id" value="Patty Rainbow Road 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1673_Patty Rainbow Road 1.png"/>
 </tile>
 <tile id="5748">
  <properties>
   <property name="Id" value="Patty Rainbow Road 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1674_Patty Rainbow Road 2.png"/>
 </tile>
 <tile id="5749">
  <properties>
   <property name="Id" value="Patty Rainbow Road 3"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1675_Patty Rainbow Road 3.png"/>
 </tile>
 <tile id="5750">
  <properties>
   <property name="Id" value="Patty Rainbow Road 4"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1676_Patty Rainbow Road 4.png"/>
 </tile>
 <tile id="5751">
  <properties>
   <property name="Id" value="Patty Rainbow Road Rotated 1"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1677_Patty Rainbow Road Rotated 1.png"/>
 </tile>
 <tile id="5752">
  <properties>
   <property name="Id" value="Patty Rainbow Road Rotated 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1678_Patty Rainbow Road Rotated 2.png"/>
 </tile>
 <tile id="5753">
  <properties>
   <property name="Id" value="Patty Rainbow Road Rotated 3"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1679_Patty Rainbow Road Rotated 3.png"/>
 </tile>
 <tile id="5754">
  <properties>
   <property name="Id" value="Patty Rainbow Road Rotated 4"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x167a_Patty Rainbow Road Rotated 4.png"/>
 </tile>
 <tile id="5755">
  <properties>
   <property name="Id" value="Patty Grass 3 No Walk"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x167b_Patty Grass 3 No Walk.png"/>
 </tile>
 <tile id="5888">
  <properties>
   <property name="Id" value="DotCS Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1700_DotCS Mountain.png"/>
 </tile>
 <tile id="5889">
  <properties>
   <property name="Id" value="DotCS Top Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1701_DotCS Top Barrier Mountain.png"/>
 </tile>
 <tile id="5890">
  <properties>
   <property name="Id" value="DotCS Bottom Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1702_DotCS Bottom Barrier Mountain.png"/>
 </tile>
 <tile id="5891">
  <properties>
   <property name="Id" value="DotCS Mountain Stairs"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1703_DotCS Mountain Stairs.png"/>
 </tile>
 <tile id="5892">
  <properties>
   <property name="Id" value="DotCS Left Barrier Mountain Stairs"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1704_DotCS Left Barrier Mountain Stairs.png"/>
 </tile>
 <tile id="5893">
  <properties>
   <property name="Id" value="DotCS Right Barrier Mountain Stairs"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1705_DotCS Right Barrier Mountain Stairs.png"/>
 </tile>
 <tile id="5894">
  <properties>
   <property name="Id" value="DotCS Mountain Ridge Edge"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1706_DotCS Mountain Ridge Edge.png"/>
 </tile>
 <tile id="5900">
  <properties>
   <property name="Id" value="DotCS Left Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x170c_DotCS Left Barrier Mountain.png"/>
 </tile>
 <tile id="5901">
  <properties>
   <property name="Id" value="DotCS Right Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x170d_DotCS Right Barrier Mountain.png"/>
 </tile>
 <tile id="5902">
  <properties>
   <property name="Id" value="DotCS Edge TL Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x170e_DotCS Edge TL Barrier Mountain.png"/>
 </tile>
 <tile id="5903">
  <properties>
   <property name="Id" value="DotCS Edge TR Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x170f_DotCS Edge TR Barrier Mountain.png"/>
 </tile>
 <tile id="5904">
  <properties>
   <property name="Id" value="DotCS Edge BL Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1710_DotCS Edge BL Barrier Mountain.png"/>
 </tile>
 <tile id="5905">
  <properties>
   <property name="Id" value="DotCS Edge BR Barrier Mountain"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1711_DotCS Edge BR Barrier Mountain.png"/>
 </tile>
 <tile id="5906">
  <properties>
   <property name="Id" value="DotCS Youkai Brick Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1712_DotCS Youkai Brick Floor.png"/>
 </tile>
 <tile id="5915">
  <properties>
   <property name="Id" value="DotCS Bamboo Earth"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x171b_DotCS Bamboo Earth.png"/>
 </tile>
 <tile id="5916">
  <properties>
   <property name="Id" value="DotCS Bumpy Cloud"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x171c_DotCS Bumpy Cloud.png"/>
 </tile>
 <tile id="5917">
  <properties>
   <property name="Id" value="DotCS Edge Cloud"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x171d_DotCS Edge Cloud.png"/>
 </tile>
 <tile id="5918">
  <properties>
   <property name="Id" value="DotCS Cloud"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x171e_DotCS Cloud.png"/>
 </tile>
 <tile id="5919">
  <properties>
   <property name="Id" value="DotCS Fire Aura"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x171f_DotCS Fire Aura.png"/>
 </tile>
 <tile id="5921">
  <properties>
   <property name="Id" value="DotCS Wood Aura"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1721_DotCS Wood Aura.png"/>
 </tile>
 <tile id="5922">
  <properties>
   <property name="Id" value="DotCS Wind Aura"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1722_DotCS Wind Aura.png"/>
 </tile>
 <tile id="5924">
  <properties>
   <property name="Id" value="DotCS Chaos Aura"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1724_DotCS Chaos Aura.png"/>
 </tile>
 <tile id="5925">
  <properties>
   <property name="Id" value="DotCS Light Aura"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1725_DotCS Light Aura.png"/>
 </tile>
 <tile id="5927">
  <properties>
   <property name="Id" value="DotCS Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1727_DotCS Mountain Night.png"/>
 </tile>
 <tile id="5928">
  <properties>
   <property name="Id" value="DotCS Top Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1728_DotCS Top Barrier Mountain Night.png"/>
 </tile>
 <tile id="5929">
  <properties>
   <property name="Id" value="DotCS Bottom Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1729_DotCS Bottom Barrier Mountain Night.png"/>
 </tile>
 <tile id="5930">
  <properties>
   <property name="Id" value="DotCS Mountain Stairs Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x172a_DotCS Mountain Stairs Night.png"/>
 </tile>
 <tile id="5931">
  <properties>
   <property name="Id" value="DotCS Left Barrier Mountain Stairs Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x172b_DotCS Left Barrier Mountain Stairs Night.png"/>
 </tile>
 <tile id="5932">
  <properties>
   <property name="Id" value="DotCS Right Barrier Mountain Stairs Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x172c_DotCS Right Barrier Mountain Stairs Night.png"/>
 </tile>
 <tile id="5937">
  <properties>
   <property name="Id" value="DotCS BL Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1731_DotCS BL Barrier Mountain Night.png"/>
 </tile>
 <tile id="5938">
  <properties>
   <property name="Id" value="DotCS BR Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1732_DotCS BR Barrier Mountain Night.png"/>
 </tile>
 <tile id="5939">
  <properties>
   <property name="Id" value="DotCS Edge TL Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1733_DotCS Edge TL Barrier Mountain Night.png"/>
 </tile>
 <tile id="5940">
  <properties>
   <property name="Id" value="DotCS Edge TR Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1734_DotCS Edge TR Barrier Mountain Night.png"/>
 </tile>
 <tile id="5941">
  <properties>
   <property name="Id" value="DotCS Edge BL Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1735_DotCS Edge BL Barrier Mountain Night.png"/>
 </tile>
 <tile id="5942">
  <properties>
   <property name="Id" value="DotCS Edge BR Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1736_DotCS Edge BR Barrier Mountain Night.png"/>
 </tile>
 <tile id="5943">
  <properties>
   <property name="Id" value="DotCS Youkai Brick Floor Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1737_DotCS Youkai Brick Floor Night.png"/>
 </tile>
 <tile id="5952">
  <properties>
   <property name="Id" value="DotCS Bamboo Earth Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1740_DotCS Bamboo Earth Night.png"/>
 </tile>
 <tile id="5954">
  <properties>
   <property name="Id" value="DotCS Left Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1742_DotCS Left Barrier Mountain Night.png"/>
 </tile>
 <tile id="5955">
  <properties>
   <property name="Id" value="DotCS Right Barrier Mountain Night"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1743_DotCS Right Barrier Mountain Night.png"/>
 </tile>
 <tile id="5956">
  <properties>
   <property name="Id" value="DotCS Bone Tiles"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x1744_DotCS Bone Tiles.png"/>
 </tile>
 <tile id="8864">
  <properties>
   <property name="Id" value="Ice Bomb Slippery"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x22a0_Ice Bomb Slippery.png"/>
 </tile>
 <tile id="28601">
  <properties>
   <property name="Id" value="Urushi Landmark A"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x6fb9_Urushi Landmark A.png"/>
 </tile>
 <tile id="30001">
  <properties>
   <property name="Id" value="Lost Halls Floor5"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x7531_Lost Halls Floor5.png"/>
 </tile>
 <tile id="31025">
  <properties>
   <property name="Id" value="Lost Halls Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0x7931_Lost Halls Floor.png"/>
 </tile>
 <tile id="43720">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner BL dirty"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaac8_Zen Sand Beige Corner BL dirty.png"/>
 </tile>
 <tile id="43721">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner BL clean"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaac9_Zen Sand Beige Corner BL clean.png"/>
 </tile>
 <tile id="43722">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner BR clean"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaaca_Zen Sand Beige Corner BR clean.png"/>
 </tile>
 <tile id="43723">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner TR clean"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaacb_Zen Sand Beige Corner TR clean.png"/>
 </tile>
 <tile id="43724">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner BR dirty"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaacc_Zen Sand Beige Corner BR dirty.png"/>
 </tile>
 <tile id="43725">
  <properties>
   <property name="Id" value="Zen Sand Beige Horizontal Top dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaacd_Zen Sand Beige Horizontal Top dark.png"/>
 </tile>
 <tile id="43726">
  <properties>
   <property name="Id" value="Zen Sand Beige Horizontal Bot dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaace_Zen Sand Beige Horizontal Bot dark.png"/>
 </tile>
 <tile id="43727">
  <properties>
   <property name="Id" value="Zen Sand Beige no line"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaacf_Zen Sand Beige no line.png"/>
 </tile>
 <tile id="43728">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner TL clean"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad0_Zen Sand Beige Corner TL clean.png"/>
 </tile>
 <tile id="43729">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner TL dirty"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad1_Zen Sand Beige Corner TL dirty.png"/>
 </tile>
 <tile id="43730">
  <properties>
   <property name="Id" value="Zen Sand Beige Corner TR dirty"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad2_Zen Sand Beige Corner TR dirty.png"/>
 </tile>
 <tile id="43731">
  <properties>
   <property name="Id" value="Zen Sand Beige vertical left dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad3_Zen Sand Beige vertical left dark.png"/>
 </tile>
 <tile id="43732">
  <properties>
   <property name="Id" value="Zen Sand Beige vertical right dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad4_Zen Sand Beige vertical right dark.png"/>
 </tile>
 <tile id="43733">
  <properties>
   <property name="Id" value="Zen Sand Beige horizontal top dark V2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad5_Zen Sand Beige horizontal top dark V2.png"/>
 </tile>
 <tile id="43734">
  <properties>
   <property name="Id" value="Zen Sand Beige TL circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad6_Zen Sand Beige TL circle.png"/>
 </tile>
 <tile id="43735">
  <properties>
   <property name="Id" value="Zen Sand Beige TM circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad7_Zen Sand Beige TM circle.png"/>
 </tile>
 <tile id="43736">
  <properties>
   <property name="Id" value="Zen Sand Beige TR circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad8_Zen Sand Beige TR circle.png"/>
 </tile>
 <tile id="43737">
  <properties>
   <property name="Id" value="Zen Sand Beige inner circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaad9_Zen Sand Beige inner circle.png"/>
 </tile>
 <tile id="43738">
  <properties>
   <property name="Id" value="Zen Sand Beige MR circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaada_Zen Sand Beige MR circle.png"/>
 </tile>
 <tile id="43739">
  <properties>
   <property name="Id" value="Zen Sand Beige BL circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaadb_Zen Sand Beige BL circle.png"/>
 </tile>
 <tile id="43740">
  <properties>
   <property name="Id" value="Zen Sand Beige BM circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaadc_Zen Sand Beige BM circle.png"/>
 </tile>
 <tile id="43741">
  <properties>
   <property name="Id" value="Zen Sand Beige BR circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaadd_Zen Sand Beige BR circle.png"/>
 </tile>
 <tile id="43743">
  <properties>
   <property name="Id" value="Zen Sand Beige ML circle"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaadf_Zen Sand Beige ML circle.png"/>
 </tile>
 <tile id="43746">
  <properties>
   <property name="Id" value="Engawa V TdL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae2_Engawa V TdL.png"/>
 </tile>
 <tile id="43747">
  <properties>
   <property name="Id" value="Engawa V BdL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae3_Engawa V BdL.png"/>
 </tile>
 <tile id="43748">
  <properties>
   <property name="Id" value="Engawa TL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae4_Engawa TL.png"/>
 </tile>
 <tile id="43749">
  <properties>
   <property name="Id" value="Engawa TR"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae5_Engawa TR.png"/>
 </tile>
 <tile id="43750">
  <properties>
   <property name="Id" value="Engawa LdL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae6_Engawa LdL.png"/>
 </tile>
 <tile id="43751">
  <properties>
   <property name="Id" value="Engawa RdL"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae7_Engawa RdL.png"/>
 </tile>
 <tile id="43752">
  <properties>
   <property name="Id" value="Jyari dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae8_Jyari dark.png"/>
 </tile>
 <tile id="43753">
  <properties>
   <property name="Id" value="Jyari light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xaae9_Jyari light.png"/>
 </tile>
 <tile id="43781">
  <properties>
   <property name="Id" value="Japanese Rock"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab05_Japanese Rock.png"/>
 </tile>
 <tile id="43782">
  <properties>
   <property name="Id" value="Japanese Rock Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab06_Japanese Rock Dark.png"/>
 </tile>
 <tile id="43783">
  <properties>
   <property name="Id" value="Japanese Urushi Floor Light"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab07_Japanese Urushi Floor Light.png"/>
 </tile>
 <tile id="43784">
  <properties>
   <property name="Id" value="Japanese Urushi Floor"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab08_Japanese Urushi Floor.png"/>
 </tile>
 <tile id="43785">
  <properties>
   <property name="Id" value="Japanese Pebbles Black No Edge"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab09_Japanese Pebbles Black No Edge.png"/>
 </tile>
 <tile id="43786">
  <properties>
   <property name="Id" value="Japanese Pebbles Black"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab0a_Japanese Pebbles Black.png"/>
 </tile>
 <tile id="43787">
  <properties>
   <property name="Id" value="Japanese Pond"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab0b_Japanese Pond.png"/>
 </tile>
 <tile id="43788">
  <properties>
   <property name="Id" value="Japanese Pond Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab0c_Japanese Pond Dark.png"/>
 </tile>
 <tile id="43796">
  <properties>
   <property name="Id" value="Japanese Urushi Floor Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab14_Japanese Urushi Floor Dark.png"/>
 </tile>
 <tile id="43797">
  <properties>
   <property name="Id" value="Japanese Rock Blue"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab15_Japanese Rock Blue.png"/>
 </tile>
 <tile id="43798">
  <properties>
   <property name="Id" value="Japanese Pond 2"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab16_Japanese Pond 2.png"/>
 </tile>
 <tile id="43799">
  <properties>
   <property name="Id" value="Japanese Pond 2 Dark"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab17_Japanese Pond 2 Dark.png"/>
 </tile>
 <tile id="43823">
  <properties>
   <property name="Id" value="Jyari light with Edge"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab2f_Jyari light with Edge.png"/>
 </tile>
 <tile id="43824">
  <properties>
   <property name="Id" value="Jyari dark with Edge"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xab30_Jyari dark with Edge.png"/>
 </tile>
 <tile id="45084">
  <properties>
   <property name="Id" value="LH Gem Tile"/>
  </properties>
  <image width="8" height="8" source="../Ground/0xb01c_LH Gem Tile.png"/>
 </tile>
 <wangsets>
  <wangset name="HallwaySet" type="mixed" tile="-1">
   <wangcolor name="Floor" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="Wall" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="67" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
