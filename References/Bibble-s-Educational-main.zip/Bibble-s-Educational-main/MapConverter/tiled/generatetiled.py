import xml.etree.ElementTree as ET
import glob, os
import ntpath

typeF = input("Input game class: ")

os.chdir("../" + typeF)

tree = ET.parse("../tiled/reference.tsx")
root = tree.getroot()

c = 0

for file in glob.glob("*.png"):
    baseName = ntpath.basename(file)
    baseNameNoTag = os.path.splitext(ntpath.basename(file))[0]
    splitName = baseNameNoTag.split('_')
    fId = int(splitName[0], 16)
    imageObject = ET.Element('image')
    imageObject.set('width', '8')
    imageObject.set('height', '8')
    imageObject.set('source', "../" + typeF + "/" + ntpath.basename(file))
    tiledObject = ET.Element('tile')
    
    stringProperty = ET.Element('properties')
    innerS = ET.Element('property')
    innerS.attrib['name']="Id"
    innerS.attrib['value']=splitName[1]
    stringProperty.append(innerS)
    
    tiledObject.set('id', str(fId))
    tiledObject.append(stringProperty)
    tiledObject.append(imageObject)
    root.append(tiledObject)
    c += 1

tree.write("../tiled/output.tsx")  
print(c)