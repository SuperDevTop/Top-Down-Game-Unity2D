import xml.etree.ElementTree as ET
import glob, os
import cv2

os.chdir("../resources")
for file in glob.glob("*.dat"):
    #print(file)
    root = ET.parse(file).getroot()
    for objectXML in root:
        classObj = objectXML.find('Class')
        if classObj == None: 
            classObj = ET.Element('Class')
            classObj.text = "Ground"
        if classObj != None:
            if True:
                localFile = None
                index = 0
                if not 'type' in objectXML.attrib: continue
                stringId = objectXML.attrib['id'] if 'id' in objectXML.attrib else ""
                imgId = objectXML.attrib['type']
                try:
                    fileO = objectXML.find('Texture')
                    if fileO is None: 
                        fileO = objectXML.find('AnimatedTexture')
                        index = int(fileO.find('Index').text)
                        index = index << 4
                    else:
                        index = int(fileO.find('Index').text, 16)
                    localFile = fileO.find('File').text
                except Exception as FirstError:
                    print(FirstError)
                    try:
                        fileO = objectXML.find('RandomTexture').find('Texture')
                        localFile = fileO.find('File').text
                        index = int(fileO.find('Index').text, 16)
                    except Exception as ERROR:
                        print(ERROR)
                        print("Failed to find even a random texture" + str(objectXML.attrib))
                   
                
                if not localFile is None:
                    
                    localFile = localFile.replace("new", "2")
                
                    mult = 8
                    
                    if '8x8' in localFile:
                        mult = 8
                    elif '16x16' in localFile or 'Big' in localFile:
                        mult = 16
                    elif '64x64' in localFile:
                        mult = 64
                    elif '32x32' in localFile:
                        mult = 32
                    elif '48x48' in localFile:
                        mult = 48
                        
                    if mult != 8:
                        print(mult)
                        print(localFile)
                    
                    offsetX = index & 0x0f
                    offsetY = index >> 4
                    
                    offsetX *= mult
                    offsetY *= mult
                    
                    imageData = None
                    imageData = cv2.imread("../resources/EmbeddedAssets_" + localFile + "Embed_.png")
                    
                    if imageData is None:
                        imageData = cv2.imread("../resources/EmbeddedAssets_" + localFile + ".png")
                    
                    if not imageData is None and imageData.size != 0:
                        #print("../resources/EmbeddedAssets_" + localFile + "_.png")
                        cropped = imageData[offsetY:offsetY+mult, offsetX:offsetX+mult]
                        
                        dirToMake = "../" + classObj.text
                        if not os.path.isdir(dirToMake):
                            os.mkdir(dirToMake)
                        try:
                            if mult != 8:
                                cropped = cv2.resize(cropped, ( 8, 8 ))
                            cv2.imwrite("../" + classObj.text + "/"+ imgId + "_" + stringId + ".png", cropped)
                        except:
                            pass
                    
                    pass